#include "redis.h"

void dictSetHash(dict *d, robj *key, robj *field, robj *value)
{
    dictEntry *de;
    robj *o;

    redisAssert(key->encoding == REDIS_ENCODING_RAW);
    de = dictFind(d, key->ptr);
    if (de)
        o = dictGetEntryVal(de);
    else
        o = NULL;

    if (o == NULL) {
        o = createHashObject();
        /* no ziplist encoding to avoid complexity */
        convertToRealHash(o);
        dictAdd(d, sdsdup(key->ptr), o);
    }
    if (dictReplace(o->ptr, field, value)) {
        /* insert */
        incrRefCount(field);
    } else {
        /* update */
        ;
    }
    incrRefCount(value);

    return;
}

int dictGetHashValue(dict *d, robj *key, robj *field, long long *value)
{
    dictEntry *de;
    robj *o, *vobj;
    long long v;

    redisAssert(key->encoding == REDIS_ENCODING_RAW);
    de = dictFind(d, key->ptr);
    if (!de) {
        return REDIS_ERR;
    }
    o = dictGetEntryVal(de);

    de = dictFind(o->ptr, field);
    if (!de) {
        return REDIS_ERR;
    }

    vobj = dictGetEntryVal(de);
    if (getLongLongFromObject(vobj, &v) != REDIS_OK) {
        return REDIS_ERR;
    }

    if (value)
        *value = v;
    return REDIS_OK;
}

int dictDelHashField(dict *d, robj *key, robj *field)
{
    dictEntry *de;
    robj *o;
    int ret;

    redisAssert(key->encoding == REDIS_ENCODING_RAW);
    de = dictFind(d, key->ptr);
    if (!de) {
        return 0;
    }
    o = dictGetEntryVal(de);
    ret = dictDelete((dict*)o->ptr, field);
    if (dictSize((dict*)o->ptr) == 0)
        dictDelete(d, key->ptr);

    return (ret == DICT_OK) ? 1 : 0;
}

static int dictDelHashKey(dict *d, robj *key)
{
    dictEntry *de;

    redisAssert(key->encoding == REDIS_ENCODING_RAW);
    de = dictFind(d, key->ptr);
    if (!de) {
        return 0;
    }
    dictDelete(d, key->ptr);
    dictResize(d);
    return 1;
}

int db2CheckPermission(redisDb2 *db2, int permission) {
    int j;
    schema *sche = db2->db->sche;
    for (j = 0; j < sche->ncolumns; ++j) {
            if(permission && !(sche->columns[j]->option & permission))
        return REDIS_ERR_PERMISSION;
    }

    return REDIS_OK;
}

int db2Set(redisDb2 *db2, void *key, int klen, sds name, long long value)
{
    robj *keyobj, *fieldobj, *valueobj;
    int ret;
    long long limit, v;

    if (value < 0)
        return REDIS_ERR_VALUE_UNDERFLOW;

    ret = cdbGetColumnLimit(db2->db, name, &limit, COLUMN_OPTION_WRITABLE);
    if (ret != REDIS_OK) {
        if(ret == REDIS_ERR_PERMISSION)
            return REDIS_ERR_PERMISSION;
        else
            return REDIS_ERR_NO_SCHEMA;
    }

    v = value & LONG_MAX;
    /* TODO: check name != NULL */
    keyobj = createStringObject(key, klen);
    fieldobj = createStringObject(name, sdslen(name));
    valueobj = createStringObjectFromLongLong(v);

    if (value >= limit) {
        ret = cdbReplace(db2->db, key, klen, name, limit);
        if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
            dictSetHash(db2->aux, keyobj, fieldobj, valueobj);
            server->db2->aux_stat.setCount++;
        } else if (ret == REDIS_OK) {
            dictSetHash(db2->extends, keyobj, fieldobj, valueobj);
        } else if (ret == REDIS_ERR_TABLE_FULL) {
            decrRefCount(keyobj);
            decrRefCount(fieldobj);
            decrRefCount(valueobj);
            return REDIS_ERR_TABLE_FULL;
        } else if (ret == REDIS_ERR_KEY_OUTOFRANGE) {
            decrRefCount(keyobj);
            decrRefCount(fieldobj);
            decrRefCount(valueobj);
            return REDIS_ERR_KEY_OUTOFRANGE;
        } else {
            /* should not reach here */
            decrRefCount(keyobj);
            decrRefCount(fieldobj);
            decrRefCount(valueobj);
            return REDIS_ERR;
        }

        decrRefCount(keyobj);
        decrRefCount(fieldobj);
        decrRefCount(valueobj);
        return REDIS_OK;
    }

    dictDelHashField(db2->extends, keyobj, fieldobj);
    ret = cdbReplace(db2->db, key, klen, name, v);
    if (ret == REDIS_OK) {
        ;// skip
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        server->db2->aux_stat.setCount++;
        dictSetHash(db2->aux, keyobj, fieldobj, valueobj);
    } else {
        decrRefCount(keyobj);
        decrRefCount(fieldobj);
        decrRefCount(valueobj);
        return ret;
    }

    decrRefCount(keyobj);
    decrRefCount(fieldobj);
    decrRefCount(valueobj);
    return REDIS_OK;
}

int db2GetAll(redisDb2 *db2, void *key, int klen, sds *result)
{
    int ret, j;
    long long v;
    sds tmp = sdsempty();

    for (j = 0; j < CDB_COLUMNS(db2->db); ++j) {
        sds name = CDB_COLUMN(db2->db, j);
        ret = db2Get(db2, key, klen, name, &v, 0);
        if (ret != REDIS_OK)
            continue;
        tmp = sdscatprintf(tmp, "%s:%lld", name, v);
        if (j != CDB_COLUMNS(db2->db)-1)
            tmp = sdscat(tmp, ",");
    }
    *result = tmp;
    return REDIS_OK;
}


int db2Get(redisDb2 *db2, void *key, int klen, sds name, long long *val, int is_from_write)
{
    int ret;
    long long v, limit;

    ret = cdbGetColumnLimit(db2->db, name, &limit, is_from_write ? 0 : COLUMN_OPTION_READABLE);

    if (ret != REDIS_OK) {
        if(ret == REDIS_ERR_PERMISSION)
            return REDIS_ERR_PERMISSION;
        else
            return REDIS_ERR_NO_SCHEMA;
    }

    ret = cdbGet(db2->db, key, klen, name, &v, is_from_write);
    if (ret == REDIS_OK) {
        if (v == limit) {
            robj *keyobj, *fieldobj;
            keyobj = createStringObject(key, klen);
            /* TODO: check name != NULL */
            fieldobj = createStringObject(name, sdslen(name));
            redisAssert(dictGetHashValue(db2->extends, keyobj, fieldobj, &v) == REDIS_OK);
            decrRefCount(keyobj);
            decrRefCount(fieldobj);
        }

        if (val)
            *val = v;
        return REDIS_OK;
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        robj *keyobj, *fieldobj;
        if(!is_from_write)
            server->db2->aux_stat.getCount++;

        keyobj = createStringObject(key, klen);
        /* TODO: check name != NULL */
        fieldobj = createStringObject(name, sdslen(name));
        ret = dictGetHashValue(db2->aux, keyobj, fieldobj, &v);
        
        decrRefCount(keyobj);
        decrRefCount(fieldobj);

        if (ret != REDIS_OK) {
            /* not found */
            if(!is_from_write)
                server->db2->aux_stat.missCount++;
            return REDIS_ERR_NOT_FOUND;
        }

        if (val)
            *val = v;
        return REDIS_OK;
    } else if (ret == REDIS_ERR_NOT_FOUND) {
        return REDIS_ERR_NOT_FOUND;
    } else if (ret == REDIS_ERR_KEY_OUTOFRANGE) {
        return REDIS_ERR_KEY_OUTOFRANGE;
    } else {
        return REDIS_ERR;
    }
}

int db2Delete(redisDb2 *db2, char *key, int klen)
{
    int ret;
    robj *keyobj = createStringObject(key, klen);

    ret = db2CheckPermission(db2, COLUMN_OPTION_WRITABLE);
    if(ret == REDIS_ERR_PERMISSION)
        return REDIS_ERR_PERMISSION;

    ret = dictDelHashKey(db2->aux, keyobj);
    if (!ret) {
        ret = cdbDelete(db2->db, key, klen);
        dictDelHashKey(db2->extends, keyobj);
        ret = ret ? REDIS_OK : REDIS_ERR_NOT_FOUND;
    } else {
        server->db2->aux_stat.setCount++;
        ret = REDIS_OK;
    }
    decrRefCount(keyobj);
    return ret;
}

int db2DeleteColumn(redisDb2 *db2, char *key, int klen, sds name)
{
    int ret;
    long long limit, v;

    ret = cdbGetColumnLimit(db2->db, name, &limit, COLUMN_OPTION_WRITABLE);
    if (ret != REDIS_OK) {
        if(ret == REDIS_ERR_PERMISSION)
            return REDIS_ERR_PERMISSION;
        else
            return REDIS_ERR_NO_SCHEMA;
    }

    ret = cdbGet(db2->db, key, klen, name, &v, 1);
    if (ret == REDIS_OK) {
        /* exists */
        if (v == limit) {
            robj *keyobj, *fieldobj;
            keyobj = createStringObject(key, klen);
            /* TODO: check name != NULL */
            fieldobj = createStringObject(name, sdslen(name));
            dictDelHashField(db2->extends, keyobj, fieldobj);
            decrRefCount(keyobj);
            decrRefCount(fieldobj);
        }
        redisAssert(cdbReplace(db2->db, key, klen, name, 0) == REDIS_OK);
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        robj *keyobj, *fieldobj;
        keyobj = createStringObject(key, klen);
        /* TODO: check name != NULL */
        fieldobj = createStringObject(name, sdslen(name));
        ret = dictDelHashField(db2->aux, keyobj, fieldobj);
        server->db2->aux_stat.setCount++;
        decrRefCount(keyobj);
        decrRefCount(fieldobj);
    }

    return ret;
}

long long emptyDb2() {
    long long removed = 0;

    removed += CDB_USED(server->db2->db);
    cdbEmpty(server->db2->db);
    removed += dictSize(server->db2->extends);
    dictEmpty(server->db2->index);
    dictEmpty(server->db2->cold_buffer);
    dictEmpty(server->db2->extends);
    removed += dictSize(server->db2->aux);
    dictEmpty(server->db2->aux);
    memset(&(server->db2->aux_stat), 0, sizeof(server->db2->aux_stat));
    return removed;
}

/* Return a random key, in form of a Redis object.
 * If there are no keys, NULL is returned.
 * If we've tried too many times without getting a valid key, NULL is returned. */
robj *db2RandomKey(redisDb2 *db2) {
    int maxtries = 2;
    int ntables = db2->db->base->current + 1;
    long table_size = server->table_size;
    long slot, lkey;
    robj *keyobj;

    /* TODO: support string type key */
    if (!server->sort || server->key_type == REDIS_KEY_TYPE_STRING)
        return NULL;

    srandom(random() & time(NULL));
    while(maxtries--) {
        slot = random();
        int n = abs(slot % ntables);
        table *t = db2->db->base->tables[n];
        slot = labs(slot % table_size);
        if (tableIsEmpty(t, slot) || tableIsDeleted(t, slot))
            continue;

        char *entry = t->ht + slot*t->entry_size;
        if (server->key_type == REDIS_KEY_TYPE_INT)
            lkey = *(int*)entry;
        else if (server->key_type == REDIS_KEY_TYPE_LONG)
            lkey = *(long*)entry;
        else
            return NULL;

        char buf[32];
        ll2string(buf, 32, lkey);
        keyobj = createStringObject(buf, strlen(buf));
        return keyobj;
    }

    return NULL;
}

