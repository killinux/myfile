#include "redis.h"
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

unsigned long nextPrime(unsigned long value);
// NOTE:the sequence MUST be the same as userStat in stat.h
static const char* userStatType[] = {"get", "set", "hit", "miss", "error", "full", "collission", NULL};

/*-----------------------------------------------------------------------------
 * Config file parsing
 *----------------------------------------------------------------------------*/

int yesnotoi(char *s) {
    if (!strcasecmp(s,"yes")) return 1;
    else if (!strcasecmp(s,"no")) return 0;
    else return -1;
}

void appendCronSaveParams(int minute, int hour, int mday, int month, int wday) {
    server->cronsaveparams = zrealloc(server->cronsaveparams,sizeof(struct cronparam)*(server->cronsaveparamslen+1));
    server->cronsaveparams[server->cronsaveparamslen].minute = minute;
    server->cronsaveparams[server->cronsaveparamslen].hour = hour;
    server->cronsaveparams[server->cronsaveparamslen].mday = mday;
    server->cronsaveparams[server->cronsaveparamslen].month = month;
    server->cronsaveparams[server->cronsaveparamslen].wday = wday;
    server->cronsaveparamslen++;
}

void resetCronSaveParams() {
    zfree(server->cronsaveparams);
    server->cronsaveparams = NULL;
    server->cronsaveparamslen = 0;
}

void appendCronBgrewriteParams(int minute, int hour, int mday, int month, int wday) {
    server->cronbgrewriteparams = zrealloc(server->cronbgrewriteparams,sizeof(struct cronparam)*(server->cronbgrewriteparamslen+1));
    server->cronbgrewriteparams[server->cronbgrewriteparamslen].minute = minute;
    server->cronbgrewriteparams[server->cronbgrewriteparamslen].hour = hour;
    server->cronbgrewriteparams[server->cronbgrewriteparamslen].mday = mday;
    server->cronbgrewriteparams[server->cronbgrewriteparamslen].month = month;
    server->cronbgrewriteparams[server->cronbgrewriteparamslen].wday = wday;
    server->cronbgrewriteparamslen++;
}

void resetCronBgrewriteParams() {
    zfree(server->cronbgrewriteparams);
    server->cronbgrewriteparams= NULL;
    server->cronbgrewriteparamslen = 0;
}

void appendServerSaveParams(time_t seconds, int changes) {
    server->saveparams = zrealloc(server->saveparams,sizeof(struct saveparam)*(server->saveparamslen+1));
    server->saveparams[server->saveparamslen].seconds = seconds;
    server->saveparams[server->saveparamslen].changes = changes;
    server->saveparamslen++;
}

void resetServerSaveParams() {
    zfree(server->saveparams);
    server->saveparams = NULL;
    server->saveparamslen = 0;
}

void loadRenamedCommand(char *filename) {
    FILE *fp;
    char buf[REDIS_CONFIGLINE_MAX+1];
    int linenum = 0;
    sds line = NULL;

    if (filename[0] == '-' && filename[1] == '\0') {
        return;
    } else {
        if ((fp = fopen(filename,"r")) == NULL) {
            redisLog(REDIS_WARNING, "Error open config file '%s': %s", filename, strerror(errno));
            return;
        }
    }

    while(fgets(buf,REDIS_CONFIGLINE_MAX+1,fp) != NULL) {
        sds *argv;
        int argc;

        linenum++;
        line = sdsnew(buf);
        line = sdstrim(line," \t\r\n");

        /* Skip comments and blank lines*/
        if (line[0] == '#' || line[0] == '\0') {
            sdsfree(line);
            continue;
        }

        /* Split into arguments */
        argv = sdssplitargs(line,&argc);
        sdsfree(line);
        sdstolower(argv[0]);

        /* Execute config directives */
        if (!strcasecmp(argv[0],"rename-command") && argc == 3) {
            struct redisCommand *cmd = lookupCommand(argv[1]);
            int retval;

            if (!cmd) {
                redisLog(REDIS_WARNING, "No such command '%s' in rename-command", argv[1]);
                continue;
            }

            /* If the target command name is the emtpy string we just
             * remove it from the command table. */
            retval = dictDelete(server->commands, argv[1]);
            redisAssert(retval == DICT_OK);

            /* Otherwise we re-add the command under a different name. */
            if (sdslen(argv[2]) != 0) {
                sds copy = sdsdup(argv[2]);
                retval = dictAdd(server->commands, copy, cmd);
                if (retval != DICT_OK) {
                    sdsfree(copy);
                    redisLog(REDIS_WARNING, "Target command %s name already exists", argv[2]);
                    continue;
                }
            }
        }
    }

    fclose(fp);
    return;
}

/* I agree, this is a very rudimental way to load a configuration...
   will improve later if the config gets more complex */
void loadServerConfig(char *filename) {
    FILE *fp;
    char buf[REDIS_CONFIGLINE_MAX+1], *err = NULL;
    int linenum = 0;
    sds line = NULL;
    int really_use_vm = 0;

    if (filename[0] == '-' && filename[1] == '\0')
        fp = stdin;
    else {
        if ((fp = fopen(filename,"r")) == NULL) {
            redisLog(REDIS_WARNING, "Fatal error, can't open config file '%s'", filename);
            exit(1);
        }
    }

    while(fgets(buf,REDIS_CONFIGLINE_MAX+1,fp) != NULL) {
        sds *argv;
        int argc, j;

        linenum++;
        line = sdsnew(buf);
        line = sdstrim(line," \t\r\n");

        /* Skip comments and blank lines*/
        if (line[0] == '#' || line[0] == '\0') {
            sdsfree(line);
            continue;
        }

        /* Split into arguments */
        argv = sdssplitargs(line,&argc);
        sdstolower(argv[0]);

        /* Execute config directives */
        if (!strcasecmp(argv[0],"timeout") && argc == 2) {
            server->maxidletime = atoi(argv[1]);
            if (server->maxidletime < 0) {
                err = "Invalid timeout value"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"port") && argc == 2) {
            server->port = atoi(argv[1]);
            if (server->port < 0 || server->port > 65535) {
                err = "Invalid port"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"bind") && argc == 2) {
            server->bindaddr = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"unixsocket") && argc == 2) {
            server->unixsocket = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"unixsocketperm") && argc == 2) {
            errno = 0;
            server->unixsocketperm = (mode_t)strtol(argv[1], NULL, 8);
            if (errno || server->unixsocketperm > 0777) {
                err = "Invalid socket file permissions"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"save") && argc == 3) {
            int seconds = atoi(argv[1]);
            int changes = atoi(argv[2]);
            if (seconds < 1 || changes < 0) {
                err = "Invalid save parameters"; goto loaderr;
            }
            appendServerSaveParams(seconds,changes);
        } else if (!strcasecmp(argv[0],"dir") && argc == 2) {
            if (chdir(argv[1]) == -1) {
                redisLog(REDIS_WARNING,"Can't chdir to '%s': %s",
                    argv[1], strerror(errno));
                exit(1);
            }
        } else if (!strcasecmp(argv[0],"loglevel") && argc == 2) {
            if (!strcasecmp(argv[1],"debug")) server->verbosity = REDIS_DEBUG;
            else if (!strcasecmp(argv[1],"verbose")) server->verbosity = REDIS_VERBOSE;
            else if (!strcasecmp(argv[1],"notice")) server->verbosity = REDIS_NOTICE;
            else if (!strcasecmp(argv[1],"warning")) server->verbosity = REDIS_WARNING;
            else {
                err = "Invalid log level. Must be one of debug, notice, warning";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"logfile") && argc == 2) {
            server->logfile = zstrdup(argv[1]);
            if (!strcasecmp(server->logfile,"stdout")) {
                zfree(server->logfile);
                server->logfile = NULL;
            }
            /* the test will be done after we switch to server->user in redismain(),
             * otherwise the logfile created here will have different user/group
             * information than expected. */
        } else if (!strcasecmp(argv[0],"syslog-enabled") && argc == 2) {
            if ((server->syslog_enabled = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"syslog-ident") && argc == 2) {
            if (server->syslog_ident) zfree(server->syslog_ident);
            server->syslog_ident = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"syslog-facility") && argc == 2) {
            struct {
                const char     *name;
                const int       value;
            } validSyslogFacilities[] = {
                {"user",    LOG_USER},
                {"local0",  LOG_LOCAL0},
                {"local1",  LOG_LOCAL1},
                {"local2",  LOG_LOCAL2},
                {"local3",  LOG_LOCAL3},
                {"local4",  LOG_LOCAL4},
                {"local5",  LOG_LOCAL5},
                {"local6",  LOG_LOCAL6},
                {"local7",  LOG_LOCAL7},
                {NULL, 0}
            };
            int i;

            for (i = 0; validSyslogFacilities[i].name; i++) {
                if (!strcasecmp(validSyslogFacilities[i].name, argv[1])) {
                    server->syslog_facility = validSyslogFacilities[i].value;
                    break;
                }
            }

            if (!validSyslogFacilities[i].name) {
                err = "Invalid log facility. Must be one of USER or between LOCAL0-LOCAL7";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"databases") && argc == 2) {
            server->dbnum = atoi(argv[1]);
            if (server->dbnum < 1) {
                err = "Invalid number of databases"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"include") && argc == 2) {
            loadServerConfig(argv[1]);
        } else if (!strcasecmp(argv[0],"maxclients") && argc == 2) {
            server->maxclients = atoi(argv[1]);
        } else if (!strcasecmp(argv[0],"maxmemory") && argc == 2) {
            server->maxmemory = memtoll(argv[1],NULL);
        } else if (!strcasecmp(argv[0],"maxmemory-policy") && argc == 2) {
            if (!strcasecmp(argv[1],"volatile-lru")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_LRU;
            } else if (!strcasecmp(argv[1],"volatile-random")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_RANDOM;
            } else if (!strcasecmp(argv[1],"volatile-ttl")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_TTL;
            } else if (!strcasecmp(argv[1],"allkeys-lru")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_ALLKEYS_LRU;
            } else if (!strcasecmp(argv[1],"allkeys-random")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_ALLKEYS_RANDOM;
            } else if (!strcasecmp(argv[1],"noeviction")) {
                server->maxmemory_policy = REDIS_MAXMEMORY_NO_EVICTION;
            } else {
                err = "Invalid maxmemory policy";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"maxmemory-samples") && argc == 2) {
            server->maxmemory_samples = atoi(argv[1]);
            if (server->maxmemory_samples <= 0) {
                err = "maxmemory-samples must be 1 or greater";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"slaveof") && argc == 3) {
            server->masterhost = sdsnew(argv[1]);
            server->masterport = atoi(argv[2]);
            server->replstate = REDIS_REPL_CONNECT;
        } else if (!strcasecmp(argv[0],"repl-ping-slave-period") && argc == 2) {
            server->repl_ping_slave_period = atoi(argv[1]);
            if (server->repl_ping_slave_period <= 0) {
                err = "repl-ping-slave-period must be 1 or greater";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"repl-timeout") && argc == 2) {
            server->repl_timeout = atoi(argv[1]);
            if (server->repl_timeout <= 0) {
                err = "repl-timeout must be 1 or greater";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"masterauth") && argc == 2) {
        	server->masterauth = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"slave-serve-stale-data") && argc == 2) {
            if ((server->repl_serve_stale_data = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"glueoutputbuf")) {
            redisLog(REDIS_WARNING, "Deprecated configuration directive: \"%s\"", argv[0]);
        } else if (!strcasecmp(argv[0],"rdbcompression") && argc == 2) {
            if ((server->rdbcompression = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"activerehashing") && argc == 2) {
            if ((server->activerehashing = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"daemonize") && argc == 2) {
            if ((server->daemonize = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"appendonly") && argc == 2) {
            if ((server->appendonly = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"appendfilename") && argc == 2) {
            zfree(server->appendfilename);
            server->appendfilename = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"no-appendfsync-on-rewrite")
                   && argc == 2) {
            if ((server->no_appendfsync_on_rewrite= yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"appendfsync") && argc == 2) {
            if (!strcasecmp(argv[1],"no")) {
                server->appendfsync = APPENDFSYNC_NO;
            } else if (!strcasecmp(argv[1],"always")) {
                server->appendfsync = APPENDFSYNC_ALWAYS;
            } else if (!strcasecmp(argv[1],"everysec")) {
                server->appendfsync = APPENDFSYNC_EVERYSEC;
            } else {
                err = "argument must be 'no', 'always' or 'everysec'";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"auto-aof-rewrite-percentage") &&
                   argc == 2)
        {
            server->auto_aofrewrite_perc = atoi(argv[1]);
            if (server->auto_aofrewrite_perc < 0) {
                err = "Invalid negative percentage for AOF auto rewrite";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"auto-aof-rewrite-min-size") &&
                   argc == 2)
        {
            server->auto_aofrewrite_min_size = memtoll(argv[1],NULL);
        } else if (!strcasecmp(argv[0],"requirepass") && argc == 2) {
            server->requirepass = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"pidfile") && argc == 2) {
            zfree(server->pidfile);
            server->pidfile = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"dbfilename") && argc == 2) {
            zfree(server->dbfilename);
            server->dbfilename = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"vm-enabled") && argc == 2) {
            if ((server->vm_enabled = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"really-use-vm") && argc == 2) {
            if ((really_use_vm = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"vm-swap-file") && argc == 2) {
            zfree(server->vm_swap_file);
            server->vm_swap_file = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"vm-max-memory") && argc == 2) {
            server->vm_max_memory = memtoll(argv[1],NULL);
        } else if (!strcasecmp(argv[0],"vm-page-size") && argc == 2) {
            server->vm_page_size = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"vm-pages") && argc == 2) {
            server->vm_pages = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"vm-max-threads") && argc == 2) {
            server->vm_max_threads = strtoll(argv[1], NULL, 10);
        } else if (!strcasecmp(argv[0],"hash-max-zipmap-entries") && argc == 2) {
            server->hash_max_zipmap_entries = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"hash-max-zipmap-value") && argc == 2) {
            server->hash_max_zipmap_value = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"list-max-ziplist-entries") && argc == 2){
            server->list_max_ziplist_entries = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"list-max-ziplist-value") && argc == 2) {
            server->list_max_ziplist_value = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"set-max-intset-entries") && argc == 2) {
            server->set_max_intset_entries = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"zset-max-ziplist-entries") && argc == 2) {
            server->zset_max_ziplist_entries = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"zset-max-ziplist-value") && argc == 2) {
            server->zset_max_ziplist_value = memtoll(argv[1], NULL);
        } else if (!strcasecmp(argv[0],"rename-command") && argc == 3) {
            struct redisCommand *cmd = lookupCommand(argv[1]);
            int retval;

            if (!cmd) {
                err = "No such command in rename-command";
                goto loaderr;
            }

            /* If the target command name is the emtpy string we just
             * remove it from the command table. */
            retval = dictDelete(server->commands, argv[1]);
            redisAssert(retval == DICT_OK);

            /* Otherwise we re-add the command under a different name. */
            if (sdslen(argv[2]) != 0) {
                sds copy = sdsdup(argv[2]);

                retval = dictAdd(server->commands, copy, cmd);
                if (retval != DICT_OK) {
                    sdsfree(copy);
                    err = "Target command name already exists"; goto loaderr;
                }
            }
        } else if (!strcasecmp(argv[0],"slowlog-log-slower-than") &&
                   argc == 2)
        {
            server->slowlog_log_slower_than = strtoll(argv[1],NULL,10);
        } else if (!strcasecmp(argv[0],"slowlog-max-len") && argc == 2) {
            server->slowlog_max_len = strtoll(argv[1],NULL,10);
        } else if (!strcasecmp(argv[0],"max-open-files") && argc == 2) {
            server->max_open_files = strtoll(argv[1], NULL, 10);
            if (server->max_open_files < 1) {
                err = "Argument must greater than 0";
                goto loaderr;
            }
            struct rlimit limit;
            limit.rlim_cur = server->max_open_files;
            limit.rlim_max = server->max_open_files;
            if (setrlimit(RLIMIT_NOFILE, &limit) == -1) {
                err = strerror(errno);
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"user") && argc == 2) {
            server->user = zstrdup(argv[1]);
        } else if (!strcasecmp(argv[0],"slave-max-cached-memory") && argc == 2) {
            server->slave_max_memory = strtoll(argv[1], NULL, 10);
            if (server->slave_max_memory < 1) {
                err = "Argument must be greater than 0";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"slave-max-disconnected-seconds") && argc == 2) {
            server->slave_max_seconds = strtoll(argv[1], NULL, 10);
            if (server->slave_max_seconds < 1) {
                err = "Argument must be greater than 0";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"affinity") && argc == 2) {
            server->affinity = atoi(argv[1]);
            if (server->affinity < 0 || server->affinity > 1023) {
                err = "Argument must between 0 and 1024";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"libredis") && argc == 2) {
			;
        } else if (!strcasecmp(argv[0],"readonly") && argc == 2) {
            if ((server->readonly = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"aof-max-size") && argc == 2) {
            server->aof_max_size = atoll(argv[1]);
            if (server->aof_max_size < 0) {
                err = "aof_max_size must be greater than 0";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"aof-expire-seconds") && argc == 2) {
            server->aof_expire_seconds = atoll(argv[1]);
            if (server->aof_expire_seconds < 0) {
                err = "aof-expire-seconds must be greater or equal than 0";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"remove_unused_aof_after_bgsave") && argc == 2) {
            server->remove_unused_aof_after_bgsave = yesnotoi(argv[1]);
            if (server->remove_unused_aof_after_bgsave < 0) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"cronsave") && argc == 6) {
            int minute, hour, mday, month, wday;
            if (!strcmp(argv[1], "*")) {
                minute = -1;
            } else {
                minute = atoi(argv[1]);
                if (minute < 0 || minute > 59) {
                    err = "Invalid cronsave parameter";
                    goto loaderr;
                }
            }
            if (!strcmp(argv[2], "*")) {
                hour = -1;
            } else {
                hour = atoi(argv[2]);
                if (hour < 0 || hour > 23) {
                    err = "Invalid cronsave parameter";
                    goto loaderr;
                }
            }
            if (!strcmp(argv[3], "*")) {
                mday = -1;
            } else {
                mday = atoi(argv[3]);
                if (mday < 1 || mday > 31) {
                    err = "Invalid cronsave parameter";
                    goto loaderr;
                }
            }
            if (!strcmp(argv[4], "*")) {
                month = -1;
            } else {
                month = atoi(argv[4]);
                if (month < 1 || month > 12) {
                    err = "Invalid cronsave parameter";
                    goto loaderr;
                }
            }
            if (!strcmp(argv[5], "*")) {
                wday = -1;
            } else {
                wday = atoi(argv[5]);
                if (wday < 0 || wday > 7) {
                    err = "Invalid cronsave parameter";
                    goto loaderr;
                }
                if (wday == 7)
                    wday = 0;
            }
            appendCronSaveParams(minute, hour, mday, month, wday);
        } else if (!strcasecmp(argv[0],"key-size") && argc == 2) {
            server->key_size = strtoll(argv[1], NULL, 10);
        } else if (!strcasecmp(argv[0],"value-size") && argc == 2) {
            server->value_size = strtoll(argv[1], NULL, 10);
        } else if (!strcasecmp(argv[0],"table-size") && argc == 2) {
            server->table_size = strtoll(argv[1], NULL, 10);
            server->table_size = nextPrime(server->table_size);
        } else if (!strcasecmp(argv[0],"table-num") && argc == 2) {
            server->table_num = strtoll(argv[1], NULL, 10);
        } else if (!strcasecmp(argv[0],"key-type") && argc == 2) {
            if (!strcasecmp(argv[1],"long")) {
                server->key_type = REDIS_KEY_TYPE_LONG;
            //} else if (!strcasecmp(argv[1],"int")) {
            //    server->key_type = REDIS_KEY_TYPE_INT;
            //} else if (!strcasecmp(argv[1],"string")) {
            //    server->key_type = REDIS_KEY_TYPE_STRING;
            } else {
                err = "Invalid key-type, must be 'long'";
                //err = "Invalid key-type, must be one of: long, int or string";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"sortable") && argc == 2) {
            if ((server->sort = yesnotoi(argv[1])) == -1) {
                err = "argument must be 'yes' or 'no'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"encoding") && argc == 2) {
            if (!strcasecmp(argv[1],"hint")) {
                server->encoding = REDIS_ENCODING_HINT;
            } else {
                err = "argument must be 'hint'";
                goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"enable-schema") && argc == 2) {
            //if ((server->enable_schema = yesnotoi(argv[1])) == -1) {
            if ((server->enable_schema = yesnotoi(argv[1])) == -1 ||
                server->enable_schema == 0)
            {
                //err = "argument must be 'yes' or 'no'"; goto loaderr;
                err = "argument must be 'yes'"; goto loaderr;
            }
        } else if (!strcasecmp(argv[0],"rotate-threshold") && argc == 2) {
            server->rotate_threshold = strtoll(argv[1], NULL, 10);
            if (server->rotate_threshold < 0 || server->rotate_threshold > 100) {
                err = "argument rotate_threshold invalid";
                goto loaderr;
            }            
        } else if (!strcasecmp(argv[0],"expand-threshold") && argc == 2) {
            server->expand_threshold = strtoll(argv[1], NULL, 10);
            if (server->expand_threshold < 0 || server->expand_threshold > 100) {
                err = "argument expand_threshold invalid";
                goto loaderr;
            }             
        } else if (!strcasecmp(argv[0],"collision-threshold") && argc == 2) {
            server->collision_threshold = strtoll(argv[1], NULL, 10);
            if (server->collision_threshold < 0) {
                err = "argument collision_threshold can not less than 0";
                goto loaderr;
            }            
        } else if (!strcasecmp(argv[0],"max-diff") && argc == 2) {
            long long diff = strtoll(argv[1], NULL, 10);
            if (diff < 0) {
                err = "argument max-diff can not less than 0";
                goto loaderr;
            }            
            SET_MAX_DIFF(diff);
        } else {
            err = "Bad directive or wrong number of arguments"; goto loaderr;
        }
        for (j = 0; j < argc; j++)
            sdsfree(argv[j]);
        zfree(argv);
        sdsfree(line);
    }
    if (fp != stdin) fclose(fp);
    if (server->vm_enabled && !really_use_vm) goto vm_warning;
    return;

loaderr:
    fprintf(stderr, "\n*** FATAL CONFIG FILE ERROR ***\n");
    fprintf(stderr, "Reading the configuration file, at line %d\n", linenum);
    fprintf(stderr, ">>> '%s'\n", line);
    fprintf(stderr, "%s\n", err);
    exit(1);

vm_warning:
    fprintf(stderr, "\nARE YOU SURE YOU WANT TO USE VM?\n\n");
    fprintf(stderr, "Redis Virtual Memory is going to be deprecated soon,\n");
    fprintf(stderr, "we think you should NOT use it, but use Redis only if\n");
    fprintf(stderr, "your data is suitable for an in-memory database.\n");
    fprintf(stderr, "If you *really* want VM add this in the config file:\n");
    fprintf(stderr, "\n    really-use-vm yes\n\n");
    exit(1);
}

/*-----------------------------------------------------------------------------
 * CONFIG command for remote configuration
 *----------------------------------------------------------------------------*/

void configSetCommand(redisClient *c) {
    robj *o;
    long long ll;
    double d;
    redisAssert(c->argv[2]->encoding == REDIS_ENCODING_RAW);
    redisAssert(c->argv[3]->encoding == REDIS_ENCODING_RAW);
    o = c->argv[3];

    if (!strcasecmp(c->argv[2]->ptr,"dbfilename")) {
        zfree(server->dbfilename);
        server->dbfilename = zstrdup(o->ptr);
    } else if (!strcasecmp(c->argv[2]->ptr,"requirepass")) {
        zfree(server->requirepass);
        server->requirepass = ((char*)o->ptr)[0] ? zstrdup(o->ptr) : NULL;
    } else if (!strcasecmp(c->argv[2]->ptr,"masterauth")) {
        zfree(server->masterauth);
        server->masterauth = zstrdup(o->ptr);
    } else if (!strcasecmp(c->argv[2]->ptr,"maxmemory")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR ||
            ll < 0) goto badfmt;
        server->maxmemory = ll;
        if (server->maxmemory) freeMemoryIfNeeded();
    } else if (!strcasecmp(c->argv[2]->ptr,"maxmemory-policy")) {
        if (!strcasecmp(o->ptr,"volatile-lru")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_LRU;
        } else if (!strcasecmp(o->ptr,"volatile-random")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_RANDOM;
        } else if (!strcasecmp(o->ptr,"volatile-ttl")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_VOLATILE_TTL;
        } else if (!strcasecmp(o->ptr,"allkeys-lru")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_ALLKEYS_LRU;
        } else if (!strcasecmp(o->ptr,"allkeys-random")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_ALLKEYS_RANDOM;
        } else if (!strcasecmp(o->ptr,"noeviction")) {
            server->maxmemory_policy = REDIS_MAXMEMORY_NO_EVICTION;
        } else {
            goto badfmt;
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"maxmemory-samples")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR ||
            ll <= 0) goto badfmt;
        server->maxmemory_samples = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"timeout")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR ||
            ll < 0 || ll > LONG_MAX) goto badfmt;
        server->maxidletime = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"appendfsync")) {
        if (!strcasecmp(o->ptr,"no")) {
            server->appendfsync = APPENDFSYNC_NO;
        } else if (!strcasecmp(o->ptr,"everysec")) {
            server->appendfsync = APPENDFSYNC_EVERYSEC;
        } else if (!strcasecmp(o->ptr,"always")) {
            server->appendfsync = APPENDFSYNC_ALWAYS;
        } else {
            goto badfmt;
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"no-appendfsync-on-rewrite")) {
        int yn = yesnotoi(o->ptr);

        if (yn == -1) goto badfmt;
        server->no_appendfsync_on_rewrite = yn;
    } else if (!strcasecmp(c->argv[2]->ptr,"appendonly")) {
        int old = server->appendonly;
        int new = yesnotoi(o->ptr);

        if (new == -1) goto badfmt;
        if (old != new) {
            if (new == 0) {
                stopAppendOnly();
            } else {
                if (startAppendOnly() == REDIS_ERR) {
                    addReplyError(c,
                        "Unable to turn on AOF. Check server logs.");
                    return;
                }
            }
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"auto-aof-rewrite-percentage")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->auto_aofrewrite_perc = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"auto-aof-rewrite-min-size")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->auto_aofrewrite_min_size = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"save")) {
        int vlen, j;
        sds *v = sdssplitlen(o->ptr,sdslen(o->ptr)," ",1,&vlen);

        /* Perform sanity check before setting the new config:
         * - Even number of args
         * - Seconds >= 1, changes >= 0 */
        if (vlen & 1) {
            sdsfreesplitres(v,vlen);
            goto badfmt;
        }
        for (j = 0; j < vlen; j++) {
            char *eptr;
            long val;

            val = strtoll(v[j], &eptr, 10);
            if (eptr[0] != '\0' ||
                ((j & 1) == 0 && val < 1) ||
                ((j & 1) == 1 && val < 0)) {
                sdsfreesplitres(v,vlen);
                goto badfmt;
            }
        }
        /* Finally set the new config */
        resetServerSaveParams();
        for (j = 0; j < vlen; j += 2) {
            time_t seconds;
            int changes;

            seconds = strtoll(v[j],NULL,10);
            changes = strtoll(v[j+1],NULL,10);
            appendServerSaveParams(seconds, changes);
        }
        sdsfreesplitres(v,vlen);
    } else if (!strcasecmp(c->argv[2]->ptr,"slave-serve-stale-data")) {
        int yn = yesnotoi(o->ptr);

        if (yn == -1) goto badfmt;
        server->repl_serve_stale_data = yn;
    } else if (!strcasecmp(c->argv[2]->ptr,"dir")) {
        if (chdir((char*)o->ptr) == -1) {
            addReplyErrorFormat(c,"Changing directory: %s", strerror(errno));
            return;
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"hash-max-zipmap-entries")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->hash_max_zipmap_entries = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"hash-max-zipmap-value")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->hash_max_zipmap_value = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"list-max-ziplist-entries")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->list_max_ziplist_entries = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"list-max-ziplist-value")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->list_max_ziplist_value = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"set-max-intset-entries")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->set_max_intset_entries = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"zset-max-ziplist-entries")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->zset_max_ziplist_entries = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"zset-max-ziplist-value")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->zset_max_ziplist_value = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"slowlog-log-slower-than")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR) goto badfmt;
        server->slowlog_log_slower_than = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"slowlog-max-len")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->slowlog_max_len = (unsigned)ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"loglevel")) {
        if (!strcasecmp(o->ptr,"warning")) {
            server->verbosity = REDIS_WARNING;
        } else if (!strcasecmp(o->ptr,"notice")) {
            server->verbosity = REDIS_NOTICE;
        } else if (!strcasecmp(o->ptr,"verbose")) {
            server->verbosity = REDIS_VERBOSE;
        } else if (!strcasecmp(o->ptr,"debug")) {
            server->verbosity = REDIS_DEBUG;
        } else {
            goto badfmt;
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"max-open-files")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 1) goto badfmt;
        if (server->max_open_files > ll) {
            addReplyErrorFormat(c, "Cannot reduce max-open-files below %ld", server->max_open_files);
            return;
        }
        struct rlimit limit;
        limit.rlim_cur = ll;
        limit.rlim_max = ll;
        if (setrlimit(RLIMIT_NOFILE, &limit) == -1) {
            redisLog(REDIS_WARNING, "Error changing max-open-files: %s", strerror(errno));
            addReplyErrorFormat(c, "Error changing max-open-files %s", strerror(errno));
            return;
        }
        server->max_open_files = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"libredis")) {
        struct stat st;
        if (stat((char*)c->argv[3]->ptr, &st) != 0) {
            redisLog(REDIS_WARNING, "Error stat %s: %s", (char*)c->argv[3]->ptr, strerror(errno));
            addReplyErrorFormat(c, "stat %s error, skip...", (char*)c->argv[3]->ptr);
            return;
        }

        if ((strlen(c->argv[3]->ptr) == strlen(server->libredis)) &&
            strcmp(c->argv[3]->ptr, server->libredis) == 0)
        {
            redisLog(REDIS_WARNING, "Config reload library %s skiped: "
                "library already loaded", server->libredis);
            addReplyErrorFormat(c, "%s already loaded, skip...", (char*)c->argv[3]->ptr);
            return;
        }
        server->thread_quit = 1; 
        flushAppendOnlyFile(1);
        server->el->stop = 1; 
        if (server->newlib) zfree(server->newlib);
        server->newlib = zstrdup(o->ptr);
        addReply(c,shared.ok);
        redisLog(REDIS_WARNING, "Config reload library %s triggered by user", server->newlib);
        return;
    } else if (!strcasecmp(c->argv[2]->ptr,"syncio-timeout-milliseconds")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->syncio_timeout_ms = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"readonly")) {
        int yn = yesnotoi(o->ptr);

        if (yn == -1) goto badfmt;
        server->readonly = yn;
        sds ci = getClientInfoString(c);
        redisLog(REDIS_WARNING, "Set readonly mode to %d by user %s", yn, ci);
        sdsfree(ci);
    } else if (!strcasecmp(c->argv[2]->ptr,"aof-max-size")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->aof_max_size = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"aof-expire-seconds")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->aof_expire_seconds = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"remove_unused_aof_after_bgsave")) {
        int yn = yesnotoi(o->ptr);

        if (yn == -1) goto badfmt;
        server->remove_unused_aof_after_bgsave = yn;
    } else if (!strcasecmp(c->argv[2]->ptr,"rotate-threshold")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        if (ll < 0 || ll > 100) {
            redisLog(REDIS_WARNING, "argument rotate_threshold invalid:%ld", ll);
            goto badfmt;
        }            
        server->rotate_threshold = ll;
        arrayConfig conf = {server->rotate_threshold, server->expand_threshold, server->collision_threshold};
        cdbSetConfig(server->db2->db, conf);
    } else if (!strcasecmp(c->argv[2]->ptr,"expand-threshold")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        if (ll < 0 || ll > 100) {
            redisLog(REDIS_WARNING, "argument expand_threshold invalid:%ld", ll);
            goto badfmt;
        }              
        server->expand_threshold = ll;
        arrayConfig conf = {server->rotate_threshold, server->expand_threshold, server->collision_threshold};
        cdbSetConfig(server->db2->db, conf);
    } else if (!strcasecmp(c->argv[2]->ptr,"max-diff")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        if (ll < 0) {
            redisLog(REDIS_WARNING, "argument max-diff invalid:%ld", ll);
            goto badfmt;
        }
        SET_MAX_DIFF(ll);
     } else if (!strcasecmp(c->argv[2]->ptr,"table_max_id")) {
        if(c->argc < 5) goto badfmt;
        long long table_id = 0;
        long long max_id = 0;
        if (getLongLongFromObject(c->argv[3],&table_id) == REDIS_ERR || table_id < 0) goto badfmt;
        if (getLongLongFromObject(c->argv[4],&max_id) == REDIS_ERR || max_id < 0) goto badfmt;
       
        array *l = server->db2->db->base;
        if(l->current >= table_id) {
            redisLog(REDIS_WARNING, "Change table %d max id from %ld to %ld",
                table_id, l->tables[table_id]->max, max_id); 
            l->tables[table_id]->max = max_id;
            server->dirty++;
        } else {
            addReplyErrorFormat(c, "table %lld does not exists", table_id);
            return;
        }
     } else if (!strcasecmp(c->argv[2]->ptr,"table_min_id")) {
        if(c->argc < 5) goto badfmt;
        long long table_id = 0;
        long long min_id = 0;
        if (getLongLongFromObject(c->argv[3],&table_id) == REDIS_ERR || table_id < 0) goto badfmt;
        if (getLongLongFromObject(c->argv[4],&min_id) == REDIS_ERR || min_id < 0) goto badfmt;
       
        array *l = server->db2->db->base;
        if(l->current >= table_id) {
            redisLog(REDIS_WARNING, "Change table %d min id from %ld to %ld",
                table_id, l->tables[table_id]->min, min_id); 
            l->tables[table_id]->min = min_id;
            server->dirty++;
        } else {
            addReplyErrorFormat(c, "table %lld does not exists", table_id);
            return;
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"position")) {
        if(c->argc < 5) goto badfmt;
        long long fileid = 0;
        long long offset = 0;
        if (getLongLongFromObject(c->argv[3],&fileid) == REDIS_ERR || fileid < 0) goto badfmt;
        if (getLongLongFromObject(c->argv[4],&offset) == REDIS_ERR || offset < 0) goto badfmt;
        redisLog(REDIS_WARNING, "Change position from %ld-%ld to %ld-%ld",
                server->curr_aof_file_id, server->appendonly_current_size, fileid, offset);
        
        server->curr_aof_file_id = fileid;
        server->appendonly_current_size = offset;
        
        bioSeekAofFile(server->appendonly_current_size);
    } else if (!strcasecmp(c->argv[2]->ptr,"cronsave")) {
        int j, vlen;
        sds *v = sdssplitlen(o->ptr,sdslen(o->ptr)," ",1,&vlen);

        if (vlen == 0) {
            resetCronSaveParams();
            addReply(c,shared.ok);
            return;
        }

        if (vlen % 5) goto badfmt;
        int cnt = vlen / 5;

        int minute, hour, mday, month, wday;
        for (j = 0; j < cnt; j++) {
            if (!strcmp(v[j*5+0], "*")) {
                minute = -1;
            } else {
                minute = atoi(v[j*5+0]);
                if (minute < 0 || minute > 59) {
                    goto badfmt;
                }
            }
            if (!strcmp(v[j*5+1], "*")) {
                hour = -1;
            } else {
                hour = atoi(v[j*5+1]);
                if (hour < 0 || hour > 23) {
                    goto badfmt;
                }
            }
            if (!strcmp(v[j*5+2], "*")) {
                mday = -1;
            } else {
                mday = atoi(v[j*5+2]);
                if (mday < 1 || mday > 31) {
                    goto badfmt;
                }
            }
            if (!strcmp(v[j*5+3], "*")) {
                month = -1;
            } else {
                month = atoi(v[j*5+3]);
                if (month < 1 || month > 12) {
                    goto badfmt;
                }
            }
            if (!strcmp(v[j*5+4], "*")) {
                wday = -1;
            } else {
                wday = atoi(v[j*5+4]);
                if (wday < 0 || wday > 7) {
                    goto badfmt;
                }
                if (wday == 7)
                    wday = 0;
            }
            if (j == 0)
                resetCronSaveParams();
            appendCronSaveParams(minute, hour, mday, month, wday);
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"maxclients")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        server->maxclients = ll;
    } else if (!strcasecmp(c->argv[2]->ptr,"relax")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        SET_READ_COUNT_RELAX(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"server-numa")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        SET_READ_COUNT_SERVER_NUMA(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"server-numb")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR || ll < 0) goto badfmt;
        SET_READ_COUNT_SERVER_NUMB(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"read-count-param1")) {
        if (getDoubleFromObject(o,&d) == REDIS_ERR) goto badfmt;
        ll = 100*d;
        if (ll < 0) goto badfmt;
        SET_READ_COUNT_PARAM1(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"read-count-param2")) {
        if (getDoubleFromObject(o,&d) == REDIS_ERR) goto badfmt;
        ll = 100*d;
        if (ll < 0) goto badfmt;
        SET_READ_COUNT_PARAM2(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"read-count-param3")) {
        if (getDoubleFromObject(o,&d) == REDIS_ERR) goto badfmt;
        ll = 100*d;
        if (ll < 0) goto badfmt;
        SET_READ_COUNT_PARAM3(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"read-count-param4")) {
        if (getDoubleFromObject(o,&d) == REDIS_ERR) goto badfmt;
        ll = 100*d;
        if (ll < 0) goto badfmt;
        SET_READ_COUNT_PARAM4(ll);
        server->dirty++;
    } else if (!strcasecmp(c->argv[2]->ptr,"read-count-param5")) {
        if (getLongLongFromObject(o,&ll) == REDIS_ERR) goto badfmt;
        if (ll <= 0) goto badfmt;
        SET_READ_COUNT_PARAM5(ll);
        server->dirty++;
    } else {
        addReplyErrorFormat(c,"Unsupported CONFIG parameter: %s",
            (char*)c->argv[2]->ptr);
        return;
    }
    addReply(c,shared.ok);
    return;

badfmt: /* Bad format errors */
    addReplyErrorFormat(c,"Invalid argument '%s' for CONFIG SET '%s'",
            (char*)o->ptr,
            (char*)c->argv[2]->ptr);
}

char *getConf(char *buf, int len) {
    FILE *fp;
    int maxtrys = 8192;
    char ch;

    if (buf == NULL || len <= 0)
        return NULL;

    if ((fp= fopen("/proc/self/cmdline", "r")) == NULL) {
        redisLog(REDIS_WARNING, "Error open /proc/self/cmdline: %s", strerror(errno));
        return NULL;
    }
   
    while (!feof(fp) && maxtrys--) {
        if (fread(&ch, 1, 1, fp) != 1) {
            redisLog(REDIS_WARNING, "Error read /proc/self/cmdline: %s", strerror(errno));
            fclose(fp);
            return NULL;
        }
        if (ch == '\0')
            break;
    }

    if (maxtrys <= 0) {
        redisLog(REDIS_WARNING, "Error parsing /proc/self/cmdline, content too long");
        fclose(fp);
        return NULL;
    }
    
    if (fgets(buf, len, fp) == NULL) {
        redisLog(REDIS_WARNING, "Error read /proc/self/cmdline: %s", strerror(errno));
        fclose(fp);
        return NULL;
    }
    fclose(fp);    

    return buf;
}

sds appendCronConfig(sds buf, int t) {
    if (t == -1)
        return sdscat(buf, "*");
    else
        return sdscatprintf(buf, "%d", t);
}

void configGetCommand(redisClient *c) {
    robj *o = c->argv[2];
    void *replylen = addDeferredMultiBulkLength(c);
    char *pattern = o->ptr;
    char buf[128];
    int matches = 0;
    redisAssert(o->encoding == REDIS_ENCODING_RAW);

    if (stringmatch(pattern,"dir",0)) {
        char buf[1024];

        if (getcwd(buf,sizeof(buf)) == NULL)
            buf[0] = '\0';

        addReplyBulkCString(c,"dir");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"config-file",0)) {
        addReplyBulkCString(c,"config-file");
        char buf[8192] = {0};
        char *tmp1 = getConf(buf, 8192);
        char *tmp2 = realpath(buf, NULL);
        if (tmp1 == NULL || tmp2 == NULL) {
            addReplyBulkCString(c, "null");
            redisLog(REDIS_WARNING, "Error getting path for config: %s", strerror(errno));
        } else {
            addReplyBulkCString(c, tmp2);
            free(tmp2);
        }
        matches++;
    }
    if (stringmatch(pattern,"dbfilename",0)) {
        addReplyBulkCString(c,"dbfilename");
        addReplyBulkCString(c,server->dbfilename);
        matches++;
    }
    if (stringmatch(pattern,"requirepass",0)) {
        addReplyBulkCString(c,"requirepass");
        addReplyBulkCString(c,server->requirepass);
        matches++;
    }
    if (stringmatch(pattern,"masterauth",0)) {
        addReplyBulkCString(c,"masterauth");
        addReplyBulkCString(c,server->masterauth);
        matches++;
    }
    if (stringmatch(pattern,"maxmemory",0)) {
        ll2string(buf,sizeof(buf),server->maxmemory);
        addReplyBulkCString(c,"maxmemory");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"maxmemory-policy",0)) {
        char *s;

        switch(server->maxmemory_policy) {
        case REDIS_MAXMEMORY_VOLATILE_LRU: s = "volatile-lru"; break;
        case REDIS_MAXMEMORY_VOLATILE_TTL: s = "volatile-ttl"; break;
        case REDIS_MAXMEMORY_VOLATILE_RANDOM: s = "volatile-random"; break;
        case REDIS_MAXMEMORY_ALLKEYS_LRU: s = "allkeys-lru"; break;
        case REDIS_MAXMEMORY_ALLKEYS_RANDOM: s = "allkeys-random"; break;
        case REDIS_MAXMEMORY_NO_EVICTION: s = "noeviction"; break;
        default: s = "unknown"; break; /* too harmless to panic */
        }
        addReplyBulkCString(c,"maxmemory-policy");
        addReplyBulkCString(c,s);
        matches++;
    }
    if (stringmatch(pattern,"maxmemory-samples",0)) {
        ll2string(buf,sizeof(buf),server->maxmemory_samples);
        addReplyBulkCString(c,"maxmemory-samples");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"timeout",0)) {
        ll2string(buf,sizeof(buf),server->maxidletime);
        addReplyBulkCString(c,"timeout");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"appendonly",0)) {
        addReplyBulkCString(c,"appendonly");
        addReplyBulkCString(c,server->appendonly ? "yes" : "no");
        matches++;
    }
    if (stringmatch(pattern,"no-appendfsync-on-rewrite",0)) {
        addReplyBulkCString(c,"no-appendfsync-on-rewrite");
        addReplyBulkCString(c,server->no_appendfsync_on_rewrite ? "yes" : "no");
        matches++;
    }
    if (stringmatch(pattern,"position",0)) {
        sds buf = sdsempty();
        buf = sdscatprintf(buf,"%d-%ld",
                server->curr_aof_file_id, server->appendonly_current_size);
        addReplyBulkCString(c,"position");
        addReplyBulkCString(c,buf);
        sdsfree(buf);
        matches++;
    }
    if (stringmatch(pattern,"appendfsync",0)) {
        char *policy;

        switch(server->appendfsync) {
        case APPENDFSYNC_NO: policy = "no"; break;
        case APPENDFSYNC_EVERYSEC: policy = "everysec"; break;
        case APPENDFSYNC_ALWAYS: policy = "always"; break;
        default: policy = "unknown"; break; /* too harmless to panic */
        }
        addReplyBulkCString(c,"appendfsync");
        addReplyBulkCString(c,policy);
        matches++;
    }
    if (stringmatch(pattern,"save",0)) {
        sds buf = sdsempty();
        int j;

        for (j = 0; j < server->saveparamslen; j++) {
            buf = sdscatprintf(buf,"%ld %d",
                    server->saveparams[j].seconds,
                    server->saveparams[j].changes);
            if (j != server->saveparamslen-1)
                buf = sdscatlen(buf," ",1);
        }
        addReplyBulkCString(c,"save");
        addReplyBulkCString(c,buf);
        sdsfree(buf);
        matches++;
    }
    if (stringmatch(pattern,"auto-aof-rewrite-percentage",0)) {
        addReplyBulkCString(c,"auto-aof-rewrite-percentage");
        addReplyBulkLongLong(c,server->auto_aofrewrite_perc);
        matches++;
    }
    if (stringmatch(pattern,"auto-aof-rewrite-min-size",0)) {
        addReplyBulkCString(c,"auto-aof-rewrite-min-size");
        addReplyBulkLongLong(c,server->auto_aofrewrite_min_size);
        matches++;
    }
    if (stringmatch(pattern,"slave-serve-stale-data",0)) {
        addReplyBulkCString(c,"slave-serve-stale-data");
        addReplyBulkCString(c,server->repl_serve_stale_data ? "yes" : "no");
        matches++;
    }
    if (stringmatch(pattern,"hash-max-zipmap-entries",0)) {
        addReplyBulkCString(c,"hash-max-zipmap-entries");
        addReplyBulkLongLong(c,server->hash_max_zipmap_entries);
        matches++;
    }
    if (stringmatch(pattern,"hash-max-zipmap-value",0)) {
        addReplyBulkCString(c,"hash-max-zipmap-value");
        addReplyBulkLongLong(c,server->hash_max_zipmap_value);
        matches++;
    }
    if (stringmatch(pattern,"list-max-ziplist-entries",0)) {
        addReplyBulkCString(c,"list-max-ziplist-entries");
        addReplyBulkLongLong(c,server->list_max_ziplist_entries);
        matches++;
    }
    if (stringmatch(pattern,"list-max-ziplist-value",0)) {
        addReplyBulkCString(c,"list-max-ziplist-value");
        addReplyBulkLongLong(c,server->list_max_ziplist_value);
        matches++;
    }
    if (stringmatch(pattern,"set-max-intset-entries",0)) {
        addReplyBulkCString(c,"set-max-intset-entries");
        addReplyBulkLongLong(c,server->set_max_intset_entries);
        matches++;
    }
    if (stringmatch(pattern,"zset-max-ziplist-entries",0)) {
        addReplyBulkCString(c,"zset-max-ziplist-entries");
        addReplyBulkLongLong(c,server->zset_max_ziplist_entries);
        matches++;
    }
    if (stringmatch(pattern,"zset-max-ziplist-value",0)) {
        addReplyBulkCString(c,"zset-max-ziplist-value");
        addReplyBulkLongLong(c,server->zset_max_ziplist_value);
        matches++;
    }
    if (stringmatch(pattern,"slowlog-log-slower-than",0)) {
        addReplyBulkCString(c,"slowlog-log-slower-than");
        addReplyBulkLongLong(c,server->slowlog_log_slower_than);
        matches++;
    }
    if (stringmatch(pattern,"slowlog-max-len",0)) {
        addReplyBulkCString(c,"slowlog-max-len");
        addReplyBulkLongLong(c,server->slowlog_max_len);
        matches++;
    }
    if (stringmatch(pattern,"rotate-threshold",0)) {
        addReplyBulkCString(c,"rotate-threshold");
        addReplyBulkLongLong(c,server->rotate_threshold);
        matches++;
    }    
    if (stringmatch(pattern,"expand-threshold",0)) {
        addReplyBulkCString(c,"expand-threshold");
        addReplyBulkLongLong(c,server->expand_threshold);
        matches++;
    }  
    if (stringmatch(pattern,"collision-threshold",0)) {
        addReplyBulkCString(c,"collision-threshold");
        addReplyBulkLongLong(c,server->collision_threshold);
        matches++;
    }  
    if (stringmatch(pattern,"loglevel",0)) {
        char *s;

        switch(server->verbosity) {
        case REDIS_WARNING: s = "warning"; break;
        case REDIS_VERBOSE: s = "verbose"; break;
        case REDIS_NOTICE: s = "notice"; break;
        case REDIS_DEBUG: s = "debug"; break;
        default: s = "unknown"; break; /* too harmless to panic */
        }
        addReplyBulkCString(c,"loglevel");
        addReplyBulkCString(c,s);
        matches++;
    }
    if (stringmatch(pattern,"libredis",0)) {
        addReplyBulkCString(c,"libredis");
        addReplyBulkCString(c,server->libredis);
        matches++;
    }
    if (stringmatch(pattern,"max-open-files",0)) {
        addReplyBulkCString(c,"max-open-files");
        addReplyBulkLongLong(c,server->max_open_files);
        matches++;
    }
    if (stringmatch(pattern,"slave-max-cached-memory",0)) {
        addReplyBulkCString(c,"slave-max-cached-memory");
        addReplyBulkLongLong(c,server->slave_max_memory);
        matches++;
    }
    if (stringmatch(pattern,"slave-max-disconnected-seconds",0)) {
        addReplyBulkCString(c,"slave-max-disconnected-seconds");
        addReplyBulkLongLong(c,server->slave_max_seconds);
        matches++;
    }
    if (stringmatch(pattern,"readonly",0)) {
        addReplyBulkCString(c,"readonly");
        addReplyBulkCString(c,server->readonly ? "yes" : "no");
        matches++;
    }
    if (stringmatch(pattern,"aof-max-size",0)) {
        addReplyBulkCString(c,"aof-max-size");
        addReplyBulkLongLong(c,server->aof_max_size);
        matches++;
    }
    if (stringmatch(pattern,"aof-expire-seconds",0)) {
        addReplyBulkCString(c,"aof-expire-seconds");
        addReplyBulkLongLong(c,server->aof_expire_seconds);
        matches++;
    }
    if (stringmatch(pattern,"max-diff",0)) {
        addReplyBulkCString(c,"max-diff");
        addReplyBulkLongLong(c, GET_MAX_DIFF());
        matches++;
    }
    if (stringmatch(pattern,"remove_unused_aof_after_bgsave",0)) {
        addReplyBulkCString(c,"remove_unused_aof_after_bgsave");
        addReplyBulkCString(c,server->remove_unused_aof_after_bgsave? "yes" : "no");
        matches++;
    }
    if (stringmatch(pattern,"maxclients",0)) {
        ll2string(buf,sizeof(buf),server->maxclients);
        addReplyBulkCString(c,"maxclients");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"relax",0)) {
        ll2string(buf,sizeof(buf),server->reserved_long[READ_COUNT_RELAX]);
        addReplyBulkCString(c,"relax");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"server-numa",0)) {
        ll2string(buf,sizeof(buf),server->reserved_long[READ_COUNT_SERVER_NUMA]);
        addReplyBulkCString(c,"server-numa");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"server-numb",0)) {
        ll2string(buf,sizeof(buf),server->reserved_long[READ_COUNT_SERVER_NUMB]);
        addReplyBulkCString(c,"server-numb");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"read-count-param1",0)) {
        d2string(buf,sizeof(buf),1.0*server->reserved_long[READ_COUNT_PARAM1]/100);
        addReplyBulkCString(c,"read-count-param1");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"read-count-param2",0)) {
        d2string(buf,sizeof(buf),1.0*server->reserved_long[READ_COUNT_PARAM2]/100);
        addReplyBulkCString(c,"read-count-param2");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"read-count-param3",0)) {
        d2string(buf,sizeof(buf),1.0*server->reserved_long[READ_COUNT_PARAM3]/100);
        addReplyBulkCString(c,"read-count-param3");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"read-count-param4",0)) {
        d2string(buf,sizeof(buf),1.0*server->reserved_long[READ_COUNT_PARAM4]/100);
        addReplyBulkCString(c,"read-count-param4");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"read-count-param5",0)) {
        ll2string(buf,sizeof(buf),server->reserved_long[READ_COUNT_PARAM5]);
        addReplyBulkCString(c,"read-count-param5");
        addReplyBulkCString(c,buf);
        matches++;
    }
    if (stringmatch(pattern,"cronsave",0)) {
        sds buf = sdsempty();
        int j;

        for (j = 0; j < server->cronsaveparamslen; j++) {
            buf = sdscatprintf(buf,"%d %d %d %d %d",
                    server->cronsaveparams[j].minute,
                    server->cronsaveparams[j].hour,
                    server->cronsaveparams[j].mday,
                    server->cronsaveparams[j].month,
                    server->cronsaveparams[j].wday);
            if (j != server->cronsaveparamslen-1)
                buf = sdscatlen(buf," | ",3);
        }
        addReplyBulkCString(c,"cronsave");
        addReplyBulkCString(c,buf);
        sdsfree(buf);
        matches++;
    }
    if (stringmatch(pattern,"columns",0)) {
        sds buf = sdsempty();
        int j;

        addReplyBulkCString(c,"columns");
        cdb *db = server->db2->db;
        for (j = 0; j < CDB_COLUMNS(db); j++) {
            static const char *option_str[] = {"-", "r", "w", "rw"};
            buf = sdscatprintf(buf, "%d:%s,%d,%s", j, CDB_COLUMN(db, j),
                    CDB_COLUMN_SIZE(db, j), option_str[db->sche->columns[j]->option & 3]);
            if (j != CDB_COLUMNS(db)-1)
                buf = sdscatlen(buf,"; ",2);
        }
        
        addReplyBulkCString(c,buf);
        sdsfree(buf);
        matches++;
    }
    if(!matches) {
        addReplyBulkCString(c, pattern);
        addReplyBulkCString(c, "");
        matches++;
    }
    setDeferredMultiBulkLength(c,replylen,matches*2);
}

void configColumnCommand(redisClient *c) {
    robj *o;
    long long ll;
    int ret;
    redisAssert(c->argv[2]->encoding == REDIS_ENCODING_RAW);
    redisAssert(c->argv[3]->encoding == REDIS_ENCODING_RAW);
    redisAssert(c->argv[4]->encoding == REDIS_ENCODING_RAW);
    o = c->argv[3];

    if (!strcasecmp(c->argv[2]->ptr,"add")) {
        if (getLongLongFromObject(c->argv[4], &ll) == REDIS_ERR || ll <= 0) {
            addReplyErrorFormat(c, "Invalid column length, must > 0");
        } else {
            ret = cdbAddColumn(server->db2->db, c->argv[3]->ptr, ll);
            if (ret == REDIS_OK) {
                server->dirty++;
                addReply(c, shared.ok);
            } else {
                addReplyErrorFormat(c,"Add column '%s' failed", (char*)c->argv[3]->ptr);
            }
        }
    } else if (!strcasecmp(c->argv[2]->ptr,"enable") || !strcasecmp(c->argv[2]->ptr,"disable")) {
        int option = 0;
        int is_enable = !strcasecmp(c->argv[2]->ptr,"enable");
        if(!strcasecmp(c->argv[4]->ptr,"read")) {
            option |= COLUMN_OPTION_READABLE;
        } else if(!strcasecmp(c->argv[4]->ptr,"write")) {
            option |= COLUMN_OPTION_WRITABLE;
        } else if(!strcasecmp(c->argv[4]->ptr,"readwrite")) {
            option |= COLUMN_OPTION_READABLE | COLUMN_OPTION_WRITABLE;
        } else {
            goto badfmt;
        }

        ret = cdbSetColumnOption(server->db2->db, c->argv[3]->ptr, option, is_enable);
        if (ret == REDIS_OK) {
            addReply(c, shared.ok);
        } else {
            addReply(c, shared.err);
        }        
    } else {
        addReplyErrorFormat(c,"Invalid argument '%s' for CONFIG COLUMN", (char*)c->argv[2]->ptr);
    }
    return;

badfmt: /* Bad format errors */
    addReplyErrorFormat(c,"Invalid argument '%s' for CONFIG COLUMN '%s'",
            (char*)o->ptr,
            (char*)c->argv[2]->ptr);
}

int statCommonInfo(char *category, char *index, userStat *stat, redisClient *c, int reset){
    int matches = 0;

    char **p = (char **)userStatType;
    uint64_t *statItem = (uint64_t*)stat;
    long long count = stat->getCount - stat->missCount;
    stat->hitCount = count < 0 ? 0 : count;

    while(*p) {
        if(reset){
            *statItem = 0;
        } else {
            addReplyBulkCStringFormat(c, "%s_%s_%s:%d", category, index, *p, *statItem);
            matches++;
        }    
        ++statItem;
        ++p;
    }
      
    return matches;
}

int statArrayInfo(redisClient *c, int reset) {
    array *l = server->db2->db->base;
    int matches = statCommonInfo("array", "0", &(l->stat), c, reset);
 
    if(!reset){
        addReplyBulkCStringFormat(c, "array_0_total:%lld", l->size);
        addReplyBulkCStringFormat(c, "array_0_used:%lld", l->used);
        matches += 2;       
    }
    
    return matches;
}

int statTableInfo(table *t, redisClient *c, int reset) {
    if(t == NULL)
        return 0;

    char indexBuf[10];
    int tableIndex = t->index;
    snprintf(indexBuf, 10, "%d", tableIndex);
    int matches = statCommonInfo("table", indexBuf, &(t->stat), c, reset);

    if(!reset){
        addReplyBulkCStringFormat(c, "table_%d_total:%lld", tableIndex, t->size);
        addReplyBulkCStringFormat(c, "table_%d_used:%lld", tableIndex, t->used);
        addReplyBulkCStringFormat(c, "table_%d_max:%lld", tableIndex, t->max);
        addReplyBulkCStringFormat(c, "table_%d_min:%lld", tableIndex, t->min);
        addReplyBulkCStringFormat(c, "table_%d_rmin:%lld", tableIndex, t->rmin);
        addReplyBulkCStringFormat(c, "table_%d_deleted:%lld", tableIndex, t->deleted);
        matches += 6;       
    }

    return matches;
}

int statColumnInfo(column *col, redisClient *c, int reset) {
    int matches = statCommonInfo("column", col->name, &(col->stat), c, reset);

    if(!reset){
        // use array's size as column's size            
        addReplyBulkCStringFormat(c, "column_%s_total:%d", col->name, server->db2->db->base->size);
        addReplyBulkCStringFormat(c, "column_%s_used:%lld", col->name, col->used);
        addReplyBulkCStringFormat(c, "column_%s_max:%lld", col->name, col->max);
        matches += 3;     
    }

    return matches;
}

int statAuxInfo(redisClient *c, int reset) {
    int matches = statCommonInfo("aux", "0", &(server->db2->aux_stat), c, reset);
 
    if(!reset){
        addReplyBulkCStringFormat(c, "aux_0_total:%d", dictSize(server->db2->aux));
        addReplyBulkCStringFormat(c, "aux_0_used:%d", dictSize(server->db2->aux));
        matches += 2;       
    }
    
    return matches;
}

void configStatCommand(redisClient *c) {
    int matches = 0;
    void *replylen = addDeferredMultiBulkLength(c);

    redisAssert(c->argv[2]->encoding == REDIS_ENCODING_RAW);
    redisAssert(c->argv[3]->encoding == REDIS_ENCODING_RAW);

    char *sub_cmd = c->argv[2]->ptr;
    int reset_cmd = !strcasecmp(sub_cmd,"reset");
    char *pattern = c->argv[3]->ptr;
    if (stringmatch(pattern,"array",0)) {
        matches += statArrayInfo(c, reset_cmd);
    }    
    if (stringmatch(pattern,"table",0)) {
        array *l = server->db2->db->base;
        int i;
        for(i=0;i<l->ntables;i++) { 
            matches += statTableInfo(l->tables[i], c, reset_cmd);
        }
    }    
    if (stringmatch(pattern,"column",0)) {
        int i;
        schema *sche = server->db2->db->sche;
        for (i = 0; i < sche->ncolumns; i++) {     
            matches += statColumnInfo(sche->columns[i], c, reset_cmd);
        }        
    }
    if (stringmatch(pattern,"aux",0)) {  
        matches += statAuxInfo(c, reset_cmd);
    }
    if(reset_cmd) {
        addReplyBulkCStringFormat(c, "OK");
        ++matches;
    }
    setDeferredMultiBulkLength(c, replylen, matches);
    return;
}

void configDumpCommand(redisClient *c) {
    FILE *fp;
    char *s, *conf_dir;
    char temp[1024], tmp_dir[8092], dump_dir[8092];
    sds buf = sdsempty();
    
    conf_dir = getConf(tmp_dir, 8092);
    if (conf_dir == NULL) {
        addReplyErrorFormat(c, "Error getting config file: %s", strerror(errno));
        sdsfree(buf);
        return;
    }

    if (c->argc == 2) {
        snprintf(dump_dir, 8092, "%s%d", conf_dir, (int)server->unixtime) ;
        if ((fp = fopen(dump_dir, "w")) == NULL) {
            redisLog(REDIS_WARNING, "can't open file '%s': %s", dump_dir, strerror(errno));
            addReplyErrorFormat(c,"can't open file '%s': %s", dump_dir, strerror(errno));
            sdsfree(buf);
            return ;
        }
    }
   
    buf = sdscatprintf(buf,
        "port %d\n"
        "logfile %s\n"
        "daemonize %s\n"
        "databases %d\n"
        "rdbcompression %s\n"
        "slowlog-log-slower-than %lld\n"
        "slowlog-max-len %zu\n"
        "max-open-files %ld\n"
        "aof-max-size %lld\n"
        "aof-expire-seconds %lld\n"
        "remove_unused_aof_after_bgsave %s\n"
        "timeout %d\n"
        "rotate-threshold %d\n"
        "readonly %s\n"
        "value-size %d\n"
        "table-num %ld\n"
        "table-size %ld\n"
        "key-size %d\n"
        "max-diff %ld\n"
        "sortable %s\n"
        "enable-schema %s\n"
        "appendonly %s\n"
        "vm-enabled %s\n"
        "collision-threshold %d\n"
        "expand-threshold %d\n"
        "slave-serve-stale-data %s\n"
        "auto-aof-rewrite-percentage 0\n"
        "auto-aof-rewrite-min-size 64mb\n"
        "no-appendfsync-on-rewrite %s\n"
        ,server->port,
        server->logfile != NULL ? server->logfile : "stdout",
        server->daemonize ? "yes" : "no",
        server->dbnum,
        server->rdbcompression ? "yes" : "no",
        server->slowlog_log_slower_than,
        server->slowlog_max_len,
        server->max_open_files,
        server->aof_max_size,
        server->aof_expire_seconds,
        server->remove_unused_aof_after_bgsave? "yes" : "no",
        server->maxidletime,
        server->rotate_threshold,
        server->readonly ? "yes" : "no",
        server->value_size,
        server->table_num,
        server->table_size,
        server->key_size,
        GET_MAX_DIFF(),
        server->sort ? "yes" : "no",
        server->enable_schema ? "yes" : "no",
        server->appendonly ? "yes" : "no",
        server->vm_enabled ? "yes" : "no",
        server->collision_threshold,
        server->expand_threshold,
        server->repl_serve_stale_data ? "yes" : "no",
        server->no_appendfsync_on_rewrite?"yes":"no"
    );

    if (server->key_type == 0)
        buf = sdscat(buf, "key-type long\n");
    else if (server->key_type == 1)
        buf = sdscat(buf, "key-type int\n");
    else if (server->key_type == 2)
        buf = sdscat(buf, "key-type string\n");

    if (server->encoding == 0) 
        buf = sdscat(buf, "encoding hint\n");
    
    if (getcwd(temp,sizeof(temp)) != NULL) 
        buf = sdscatprintf(buf, "dir %s\n", temp);

    if (server->user) 
        buf = sdscatprintf(buf, "user %s\n", server->user);
    
    if (server->pidfile != NULL) 
        buf = sdscatprintf(buf, "pidfile %s\n", server->pidfile);
    
    if (server->appendfilename != NULL)
        buf = sdscatprintf(buf, "appendfilename %s\n", server->appendfilename);

    if (server->dbfilename != NULL)
        buf = sdscatprintf(buf, "dbfilename %s\n", server->dbfilename); 
    
    if (server->libredis != NULL) 
        buf = sdscatprintf(buf, "libredis %s\n", server->libredis);
    
    switch(server->verbosity) { 
        case REDIS_WARNING: s = "warning"; break;
        case REDIS_NOTICE: s = "notice"; break;
        case REDIS_DEBUG: s = "debug"; break;
        default: s = "verbose"; break;
    }
    buf = sdscatprintf(buf, "loglevel %s\n", s);
    
    switch(server->appendfsync) {
        case APPENDFSYNC_NO: s = "no"; break;
        case APPENDFSYNC_ALWAYS: s = "always"; break;
        default: s = "everysec"; break;
    }
    buf = sdscatprintf(buf, "appendfsync %s\n", s);
   
     
    int j;
    for (j = 0; j < server->cronsaveparamslen; j++) {
        buf = sdscat(buf, "cronsave ");
        
        buf = appendCronConfig(buf, server->cronsaveparams[j].minute);
        buf = sdscat(buf, " ");
        buf = appendCronConfig(buf, server->cronsaveparams[j].hour);
        buf = sdscat(buf, " ");
        buf = appendCronConfig(buf, server->cronsaveparams[j].mday);
        buf = sdscat(buf, " ");
        buf = appendCronConfig(buf, server->cronsaveparams[j].month);
        buf = sdscat(buf, " ");
        buf = appendCronConfig(buf, server->cronsaveparams[j].wday);
        buf = sdscat(buf, "\n");
    }
    
    buf = sdscat(buf, 
        "rename-command flushall flushall2\n"
        "rename-command save save2\n"
        "rename-command debug debug2\n"
    );

    if (c->argc == 2) {
        if ((fwrite(buf, strlen(buf), 1, fp)) != 1) {
            sdsfree(buf);
            fclose(fp);
            remove(dump_dir);
            redisLog(REDIS_WARNING, "write file %s fail: %s", dump_dir, strerror(errno));
            addReplyErrorFormat(c, "write file %s fail: %s", dump_dir, strerror(errno));
            return ;
        }
        fclose(fp);
        if (rename(dump_dir,conf_dir) != 0) {
            remove(dump_dir);
            redisLog(REDIS_WARNING, "rename %s to %s fail: %s", dump_dir, conf_dir, strerror(errno));
            addReplyErrorFormat(c, "rename %s to %s fail: %s", dump_dir, conf_dir, strerror(errno));
        } else {
            char *tmp = realpath(conf_dir, NULL);
            if (tmp == NULL) {
                redisLog(REDIS_WARNING, "Error getting path for %s: %s", conf_dir, strerror(errno));
            } else {
                redisLog(REDIS_WARNING, "Dumping config to %s", tmp);
                free(tmp);
            }
            addReply(c,shared.ok);
        }
    }

    if (c->argc == 3) {
        remove(dump_dir);
        if (!strcasecmp(c->argv[2]->ptr,"stdout")) {
            addReplyStatus(c, buf);
        } else {
            redisLog(REDIS_WARNING, "CONFIG DUMP subcommand must be STDOUT");
            addReplyErrorFormat(c, "CONFIG DUMP subcommand must be STDOUT");
        }
        return;
    }

    sdsfree(buf);
    return ;
}

void configCommand(redisClient *c) {
    if (!strcasecmp(c->argv[1]->ptr,"set")) {
        if (c->argc < 4) goto badarity;
        logQuery(c);
        configSetCommand(c);
    } else if (!strcasecmp(c->argv[1]->ptr,"get")) {
        if (c->argc != 3) goto badarity;
        configGetCommand(c);
    } else if (!strcasecmp(c->argv[1]->ptr,"dump")) {
        if (c->argc != 2 && c->argc !=3) goto badarity;      
        logQuery(c);
        configDumpCommand(c);
    } else if (!strcasecmp(c->argv[1]->ptr,"resetstat")) {
        if (c->argc != 2) goto badarity;
        logQuery(c);
        server->stat_keyspace_hits = 0;
        server->stat_keyspace_misses = 0;
        server->stat_numcommands = 0;
        server->stat_numconnections = 0;
        server->stat_expiredkeys = 0;
        CLEAR_READ_STAT();
        CLEAR_WRITE_STAT();
        addReply(c,shared.ok);
    } else if (!strcasecmp(c->argv[1]->ptr,"resetrwstat")) {
        if (c->argc != 2) goto badarity;
        logQuery(c);
        CLEAR_READ_STAT();
        CLEAR_WRITE_STAT();
        addReply(c,shared.ok);
    } else if (!strcasecmp(c->argv[1]->ptr,"column")) {
        if (c->argc != 5) goto badarity;
        logQuery(c);
        configColumnCommand(c);
    } else if (!strcasecmp(c->argv[1]->ptr,"stat")) {
        if (c->argc != 4) goto badarity;
        configStatCommand(c);
    } else {
        addReplyError(c,
            "CONFIG subcommand must be one of GET, SET, RESETSTAT, RESETRWSTA, STAT and COLUMN");
    }
    return;

badarity:
    addReplyErrorFormat(c,"Wrong number of arguments for CONFIG %s",
        (char*) c->argv[1]->ptr);
}
