#ifndef __ARRAY_H
#define __ARRAY_H

#include <stdint.h>
#include "stat.h"
#include "schema.h"

/* Rotate to a new table when current is xx% full */
#define ARRAY_TABLE_DEFAULT_ROTATE_THRESHOLD 90
/* Expand current table when it's xx% full */
#define ARRAY_TABLE_DEFAULT_EXPAND_THRESHOLD 95
/* Goto the extend table when there's xx collisions */
#define ARRAY_TABLE_DEFAULT_COLLISION_THRESHOLD 1000
/* Goto aux when table is too full */
#define ARRAY_TABLE_DEFAULT_FULL_THRESHOLD 98

/* key can be int, long or string, use string for all values */
#define ARRAY_KEY_TYPE_INT 0
#define ARRAY_KEY_TYPE_LONG 1
#define ARRAY_KEY_TYPE_STRING 2

/* table entry structures */
#define STRUCT_INT_STRING(len) typedef struct { int key; char val[len]; } _is;
#define STRUCT_LONG_STRING(len) typedef struct { long key; char val[len]; } _ls;
#define STRUCT_STRING_STRING(len1, len2) typedef struct { char key[len1]; char val[len2]; } _ss;

#define STRUCT_DECLARE(len1, len2) \
        STRUCT_INT_STRING(len2); \
        STRUCT_LONG_STRING(len2); \
        STRUCT_STRING_STRING(len1, len2);

/* Unused arguments generate annoying warnings... */
#define ARRAY_NOTUSED(V) ((void) V)

typedef long (*getScore)(void *key, int len);

typedef struct table {
    char *ht;
    int index;
    void *l;
    int sort;
    int locked;     /* 1 if the table is preparing for rotate */
    long rmin;  /* real minimum key in this table */
    long min;
    long max;
    long size;
    long used;
    long deleted;
    int key_size;
    int value_size;
    int entry_size;
    getScore gs;
    userStat stat;
} table;

typedef struct array {
    table **tables;
    int ntables;    /* total number of tables to create */
    int current;    /* current table index for inserting new values */
    int locked;     /* there's a table in locked state */
    int sort;
    long min;
    long max;
    long size;    /* max number of keys to store in ARRAY */
    long used;
    long deleted;
    int rotate_threshold;   /* rotate to a new table when table->used/table->size >= threshold% */
    int expand_threshold;
    int collision_threshold;  /* TODO: hash collision threshold%, not implemented */
    long table_size;
    int key_size;
    int value_size;
    int entry_size;
    getScore gs;
    userStat stat;
} array;

typedef struct arrayConfig {
    int rotate_threshold;
    int expand_threshold;
    int collision_threshold;
} arrayConfig;

/* ------------------------------- Macros ------------------------------------*/
#define arraySize(l) (l->size)
#define arrayUsed(l) (l->used)
#define arrayDeleted(l) (l->deleted)
#define arrayEmptySlots(l) (l->size-l->used-l->deleted)
#define arrayKeySize(l) (l->key_size)
#define arrayValueSize(l) (l->value_size)
#define arrayTotalTables(l) (l->ntables)
#define arrayTableSize(l, index) ((index <= l->current)? l->tables[index]->size : 0)
#define arrayCurrentTable(l) (l->current)
#define arrayMin(l) (l->tables[0]->rmin)
#define arrayMax(l) (l->tables[l->current]->max)
#define arrayNeedsRotate(l) (l->locked)

array *arrayCreate(long table_num, long table_size, int key_size, int value_size, int sort, getScore gs);
void arraySetConfig(array *l, arrayConfig conf);
void arrayFree(array *l);
int arrayAdd(array *l, char *key, int key_len, char *val, int val_len);
int arrayReplace(array *l, char *key, int key_len, char *val, int val_len);
int arrayGet(array *l, char *key, int key_len, char **result, int is_from_write);
int arrayDel(array *l, char *key, int key_len);
void arrayEmpty(array *l);
int arrayExpandTable(array *l, int index, long size);
void arrayRotateTable(array *l);
int arraySave(FILE *fp, array *l);
array* arrayLoad(FILE *fp, schema* sche, getScore gs);
int getTableIdForKey(array *l, void *key, int len);
int tableIsEmpty(table *t, long index);
int tableIsDeleted(table *t, long index);

#endif /* __DICT_H */
