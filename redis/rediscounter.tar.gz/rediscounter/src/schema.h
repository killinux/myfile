#ifndef __SCHEMA_H__
#define __SCHEMA_H__

#include <stdint.h>
#include "sds.h"
#include "stat.h"

#define SCHEMA_ENCODING_BITS 2
#define SCHEMA_ENCODING_HINT 0
#define SCHEMA_ENCODING_BASE64 1

#define COLUMN_OPTION_READABLE     1
#define COLUMN_OPTION_WRITABLE     2

typedef struct column {
    sds name;
    int index;
    int bits;   /* length in bits */
    int offset; /* offset in value(in bits) */
    int option;
    uint64_t max;   /* max value of this column */
    uint64_t used;  /* for stat: used spaces, its total is the same as table's total*/
    userStat stat;
} column;

typedef struct schema {
    column **columns;
    int ncolumns;
    int bits;       /* length in bits */
    int used;       /* used bits */
    int encoding_enabled;   /* 0 if all values use hint based encoding, else 1 */
} schema;

schema *schemaCreate(int bytes, int enable_encoding);
void schemaFree(schema *schema);
int schemaAdd(schema *sche, sds name, int bits);
column *schemaSearch(schema *sche, sds name);
int schemaDelete(schema *sche, sds name);
int schemaSave(FILE *fp, schema *sche);
schema* schemaLoad(FILE *fp);

#define SCHEMA_SIZE(sche) (sche->bits)
#define SCHEMA_USED(sche) (sche->used)
#define SCHEMA_FREE(sche) (SCHEMA_SIZE(sche)-SCHEMA_USED(sche))
#define SCHEMA_COLUMNS(sche) (sche->ncolumns)
#define SCHEMA_COLUMN(sche, index) (sche->columns[j]->name)

#define COLOMN_READABLE(col) (col->option & COLUMN_OPTION_READABLE)
#define COLOMN_WRITABLE(col) (col->option & COLUMN_OPTION_WRITABLE)

#endif
