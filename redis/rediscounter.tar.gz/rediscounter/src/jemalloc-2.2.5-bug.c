#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "zmalloc.h"

void *worker(void *arg) {
    int j;
    char *p;

    while (1) {
        for (j=1; j<5000; ++j) {
            p = zmalloc(j);
            zfree(p);
        }
    }
    return NULL;
}

int main(int argc, char **argv) {
    int pid;
    int j;
    char *p;
    pthread_t tid;
    int n = 20;


    fprintf(stderr, "%s\n", ZMALLOC_LIB);
    if (argc > 1)
        n = atoi(argv[1]);

    for (j=0; j<10; ++j)
        pthread_create(&tid, NULL, worker, NULL);

    int i = 0;
    while (i++<n) {
        if ((pid = fork()) == 0) {
            /* child */
            fprintf(stderr, "child %d\n", i);
            int cnt;
            for (cnt=0; cnt<100; ++cnt) {
                for (j=1; j<5000; ++j) {
                    p = zmalloc(j);
                    zfree(p);
                }
            }
            exit(0);
        }
        usleep(10000);
    }

    sleep(1);
    while (n--) {
        fprintf(stderr, "%d children running...\n", n+1);
        pid = wait(NULL);
    }
    return 0;
}

