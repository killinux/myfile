#ifndef __REDIS_STAT_H
#define __REDIS_STAT_H
#include <stdio.h>
#include <inttypes.h>

typedef struct userStat {
    uint64_t getCount;
    uint64_t setCount;
	uint64_t hitCount;    
    uint64_t missCount;
    uint64_t errorCount;    
    uint64_t fullCount;
    uint64_t collisionCount;
    uint64_t used;    // only used for aux, extends
} userStat;

#endif
