#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <sys/types.h>  
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h> 

//#include "cdb.h"
#include "zmalloc.h"
#include "redis.h"
#include "array.h"

/* -------------------------- Utilities -------------------------- */
void setBit(char *buf, int offset, int on)
{
    int byte = offset >> 3;
    int bit = 7 - (offset & 0x7);
    int byteval = ((uint8_t*)buf)[byte];

    byteval &= ~(1 << bit);
    byteval |= ((on & 0x1) << bit);
    ((uint8_t*)buf)[byte] = byteval;
}

int getBit(char *buf, int offset)
{
    int v;
    int byte = offset >> 3;
    int bit = 7 - (offset & 0x7);
    int byteval = ((uint8_t*)buf)[byte];

    v = byteval & (1 << bit);
    return v ? 1 : 0;
}

void setValue(char *buf, int len, int offset, int bits, long long val)
{
    int totlen = len << 3;
    int j, on;
    long long v = val;

    assert(offset < totlen);
    assert(offset+bits <= totlen);

    for (j = offset+bits-1; j >= offset; --j) {
        on = v & 0x1;
        setBit(buf, j, on);
        v = v >> 1;
    }
}

long long getValue(char *buf, int len, int offset, int bits)
{
    long long val = 0;
    int j, first = 0;
    int v;

    if (offset >= (len << 3))
        return 0;

    for (j = offset; j < offset+bits; ++j) {
        v = getBit(buf, j);
        if (first)
            val <<= 1;
        if (v) {
            val |= 0x1;
            first = 1;
        }
    }

    return val;
}

/* ------------------------- CDB Operations ----------------------- */
cdb *cdbCreate(long table_num, long table_size, int key_size, int value_size,
    int sort, getScore gs, int enable_encoding)
{
    cdb *db = zmalloc(sizeof(*db));
    db->base = arrayCreate(table_num, table_size, key_size, value_size, sort, gs);
    db->sche = schemaCreate(value_size, enable_encoding);
    return db;
}

void cdbSetConfig(cdb *db, arrayConfig conf){
    arraySetConfig(db->base, conf);
}

void cdbFree(cdb *db)
{
    arrayFree(db->base);
    schemaFree(db->sche);
    zfree(db);
}

int cdbAddColumn(cdb *db, sds name, int bits)
{
    schema *sche = db->sche;
    if (schemaAdd(sche, name, bits) == REDIS_OK)
        return REDIS_OK;
    return REDIS_ERR;
}

int cdbSetColumnOption(cdb *db, sds name, int option, int is_enable) {
    schema *sche = db->sche;
    column *col = schemaSearch(sche, name);
    if(col == NULL)
        return REDIS_ERR;

    if(is_enable) {
        col->option |= option;
    } else {
        // change the bits in col->option to 0 where it's 1 in option
        col->option |= option;
        col->option ^= option;
    }

    return REDIS_OK;
}

#if 0
int cdbAdd(cdb *db, char *key, int klen, sds name, long long val)
{
    column *col;
    int vlen = arrayValueSize(db->base);
    char *ventry;
    char vbuf[vlen];
    int bits = vlen << 3, offset = 0;
    long long max;

    if (SCHEMA_COLUMNS(db->sche) == 0) {
        /* no-schema support(a single value) */
        if (name)
            return REDIS_ERR_NO_SCHEMA;
        if (bits == 64)
            max = ULONG_MAX;
        else
            max = (1UL << bits) - 1;
        if (val > max)
            return REDIS_ERR_VALUE_OVERFLOW;
        goto add;
    }

    col = schemaSearch(db->sche, name);
    if (col == NULL)
        return REDIS_ERR_NO_SCHEMA;

    if (val > (long long )col->max)
        return REDIS_ERR_VALUE_OVERFLOW;
    bits = col->bits;
    offset = col->offset;

add:
    ventry = arrayGet(db->base, key, klen, 1);
    if (ventry) {
        return REDIS_ERR_KEY_EXISTS;
    } else {
        memset(vbuf, 0, vlen);
        setValue(vbuf, vlen, offset, bits, val);
        if (arrayAdd(db->base, key, klen, vbuf, vlen) == REDIS_OK) {
            col->stat.setCount++;
            col->used++;
            return REDIS_OK;
        } else
            return REDIS_ERR;
    }
}
#endif

int cdbGet(cdb *db, char *key, int klen, sds name, long long *val, int is_from_write)
{
    column *col;
    char *ventry;
    int ret, offset = 0, bits = arrayValueSize(db->base) << 3;

    if (SCHEMA_COLUMNS(db->sche) == 0) {
        if (name)
            return REDIS_ERR_NO_SCHEMA;
        goto get;
    }

    col = schemaSearch(db->sche, name);
    if (col == NULL) 
        return REDIS_ERR_NO_SCHEMA;

    offset = col->offset;
    bits = col->bits;

get:
    if(!is_from_write)
        col->stat.getCount++;

    ret = arrayGet(db->base, key, klen, &ventry, is_from_write); 
    if (ret == REDIS_OK) {
        *val = getValue(ventry, arrayValueSize(db->base), offset, bits);
        return REDIS_OK;
    }

    switch(ret) {
        case REDIS_ERR_TOO_MANY_COLLISION:
            return ret;
        case REDIS_ERR_NOT_FOUND:
        case REDIS_ERR_KEY_OUTOFRANGE:
        default:
            if (!is_from_write)
                col->stat.missCount++;         
            return ret;
    }
}

int cdbReplace(cdb *db, char *key, int klen, sds name, long long val)
{
    column *col;
    int vlen = arrayValueSize(db->base);
    char *ventry;
    char vbuf[vlen];
    int ret, bits = vlen << 3, offset = 0;
    long long max;

    if (SCHEMA_COLUMNS(db->sche) == 0 || name == NULL) {
        /* no-schema support(a single value) */
        if (name)
            return REDIS_ERR_NO_SCHEMA;
        if (bits == 64)
            max = ULONG_MAX;
        else
            max = (1UL << bits) - 1;
        if (val > max)
            return REDIS_ERR_VALUE_OVERFLOW;
        goto replace;
    }

    col = schemaSearch(db->sche, name);
    if (col == NULL)
        return REDIS_ERR_NO_SCHEMA;

    if (val > (long long)col->max)
        return REDIS_ERR_VALUE_OVERFLOW;
    bits = col->bits;
    offset = col->offset;

replace:
    ret = arrayGet(db->base, key, klen, &ventry, 1);
    if (ret ==REDIS_OK) {
        int old_val = getValue(ventry, arrayValueSize(db->base), offset, bits); 
        if(old_val == 0) {
            // key exist but col is 0
            col->used++;
        }        
        setValue(ventry, vlen, offset, bits, val);
        
        // update setCount stat for column, table and array
        col->stat.setCount++;
        int tableId = getTableIdForKey(db->base, key, klen);
        if (tableId != -1)
            db->base->tables[tableId]->stat.setCount++;
        
        return REDIS_OK;
    } else if (ret == REDIS_ERR_NOT_FOUND) {
        memset(vbuf, 0, vlen);
        setValue(vbuf, vlen, offset, bits, val);
        ret = arrayAdd(db->base, key, klen, vbuf, vlen);
        if (ret == REDIS_OK) {
            col->stat.setCount++;
            col->used++;
            return REDIS_OK;
        } else if (ret == REDIS_ERR_KEY_RESERVED) {
            return REDIS_ERR_KEY_OUTOFRANGE;
        } else {
            return REDIS_ERR_TABLE_FULL;
        }
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        return ret;
    } else if (ret == REDIS_ERR_KEY_OUTOFRANGE) {
        return REDIS_ERR_KEY_OUTOFRANGE;
    } else {
        /* should never reach here */
        return REDIS_ERR;
    }
}

int cdbDelete(cdb *db, char *key, int klen)
{
    if (arrayDel(db->base, key, klen) == REDIS_OK)
        return 1;
    return 0;
}

int rdbSaveType(FILE *fp, unsigned char type); 
int rdbSaveLen(FILE *fp, uint32_t len);

int cdbSave(FILE* fp, cdb *db, int id)
{
    if(!fp || !db) 
    {
        return -1;
    }
    
    /* Write the SELECT DB opcode */
    if (rdbSaveType(fp,REDIS_SELECTDB) == -1) return -1;
    if (rdbSaveLen(fp,id) == -1) return -1;

    int ret = schemaSave(fp, db->sche);
    if(ret < 0) return ret;

    ret = arraySave(fp, db->base);
    if(ret < 0) return ret;

    return 0;
}

cdb* cdbLoad(FILE* fp, getScore gs)
{
    cdb *db = zmalloc(sizeof(*db));
    db->sche = schemaLoad(fp);
    db->base = arrayLoad(fp, db->sche, gs);

    if( !db->sche || !db->base)
    {
        if(db->sche) schemaFree(db->sche);
        if(db->base) arrayFree(db->base);
        return NULL;
    }
    return db;
}

int cdbGetColumnLimit(cdb *db, sds name, long long *limit, int permission)
{
    column *col;

    if (SCHEMA_COLUMNS(db->sche) == 0 || name == NULL)
        return REDIS_ERR;

    col = schemaSearch(db->sche, name);
    if (col == NULL)
        return REDIS_ERR;

    if(permission && !(col->option & permission))
        return REDIS_ERR_PERMISSION;

    if (limit)
        *limit = col->max;
    return REDIS_OK;
}

void cdbEmpty(cdb *db)
{
    arrayEmpty(db->base);
    return;
}

int cdbDumpTable(cdb *db, int index)
{
    table *t;
    t = db->base->tables[index];
    char name[255];
    int fd;

    /* Can't dump without locking the table */
    if (!db->base->locked || !t->locked) {
        redisLog(REDIS_WARNING, "Can't roate a table without locking it first");
        return 1;
    }

    snprintf(name, 255, "dump-%ld-%ld", (long)getpid(), time(NULL));
    redisLog(REDIS_NOTICE, "Table key range: min: %ld, max: %ld", t->min, t->max);
    fd = open(name, O_CREAT|O_WRONLY|O_TRUNC, 0644);
    if (fd == -1) {
        redisLog(REDIS_WARNING, "Error creating %s for dumping: %s",
            name, strerror(errno));
        return 1;
    }

    if (write(fd, t->ht, t->size*t->entry_size) != t->size*t->entry_size) {
        redisLog(REDIS_WARNING, "Error dumping table: %s", strerror(errno));
        close(fd);
        return 1;
    }

    close(fd);
    redisLog(REDIS_NOTICE, "Dumping table 0 to %s", name);
    return 0;
}

int cdbRotateBackground(void)
{
    pid_t childpid;
    long long start;

    if (server->bgrotatechildpid != -1)
        return REDIS_ERR;
    start = ustime();
    if ((childpid = fork()) == 0) {
        /* Child */
        if (server->ipfd > 0) close(server->ipfd);
        if (server->sofd > 0) close(server->sofd);
        redisLog(REDIS_NOTICE, "Dumping table 0 on disk");
        redisLog(REDIS_NOTICE, "Table stats: size %ld, used %ld, deleted %ld",
            arraySize(server->db2->db->base->tables[0]),
            arrayUsed(server->db2->db->base->tables[0]),
            arrayDeleted(server->db2->db->base->tables[0]));
        if (cdbDumpTable(server->db2->db, 0) == 0) {
            _exit(0);
        } else {
            _exit(1);
        }
    } else {
        /* Parent */
        server->stat_fork_time = ustime()-start;
        if (childpid == -1) {
            redisLog(REDIS_WARNING,
                "Can't rotate table in background: fork: %s", strerror(errno));
            return REDIS_ERR;
        }
        redisLog(REDIS_NOTICE,
            "Background table rotate started by pid %d",childpid);
        server->bgrotatechildpid = childpid;
        return REDIS_OK;
    }
    return REDIS_OK; /* unreached */
}

void backgroundRotateDoneHandler(int statloc)
{
    int exitcode = WEXITSTATUS(statloc);
    int bysignal = WIFSIGNALED(statloc);

    if (!bysignal && exitcode == 0) {
        redisLog(REDIS_NOTICE,
            "Background rotate table terminated with success");
        arrayRotateTable(server->db2->db->base);
    } else if (!bysignal && exitcode != 0) {
        redisLog(REDIS_WARNING, "Background rotate table error: %d", exitcode);
    } else {
        redisLog(REDIS_WARNING,
            "Background rotate table terminated by signal %d", WTERMSIG(statloc));
        /* TODO: remove temp files */
    }
    server->bgrotatechildpid = -1;
}



#ifdef CDB_TEST
long getScoreFromLong(void *key, int len) {
    return *(long*)key;
}

void testCdbAdd() {
    long j = 1, ret;

    cdb *db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 1);

    fprintf(stderr, "Testing ADD-WITHOUT-SCHEMA: ");
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("test"), 1) == REDIS_ERR_NO_SCHEMA);
    for (j = 1; j < 10000; ++j) {
        assert(cdbAdd(db, (void*)&j, 8, NULL, j) == REDIS_OK);
        assert(cdbGet(db, (void*)&j, 8, NULL, &ret, 0) == REDIS_OK && ret == j);
    }
    cdbFree(db);
    fprintf(stderr, "pass\n");

    db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 0);
    fprintf(stderr, "Testing ADD-RESERVED-KEY: ");
    j = 0;
    assert(cdbAddColumn(db, sdsnew("test"), 7) == REDIS_OK);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("test"), 1) == REDIS_ERR);
    memset(&j, 'F', 8);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("test"), 1) == REDIS_ERR);
    fprintf(stderr, "pass\n");

    j = 1;
    fprintf(stderr, "Testing ADD-COLUMN: ");
    assert(cdbAddColumn(db, sdsnew("foo"), 7) == REDIS_OK);
    assert(cdbAddColumn(db, sdsnew("bar"), 9) == REDIS_OK);
    assert(cdbAddColumn(db, sdsnew("foobar"), 113) == REDIS_ERR);
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing ADD: ");
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foobar"), 1) == REDIS_ERR_NO_SCHEMA);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 1<<7) == REDIS_ERR_VALUE_OVERFLOW);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 0) == REDIS_OK);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 0) == REDIS_ERR_KEY_EXISTS);
    j++;
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 1) == REDIS_OK);
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 1) == REDIS_ERR_KEY_EXISTS);
    j++;
    assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), 1<<7-1) == REDIS_OK);
    fprintf(stderr, "pass\n");

    cdbFree(db);
}

void testCdbGet() {
    long j = 1, ret;

    cdb *db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 1);
    assert(cdbAddColumn(db, sdsnew("foo"), 62) == REDIS_OK);

    fprintf(stderr, "Testing GET: ");
    assert(cdbGet(db, (void*)&j, 8, sdsnew("bar"), &ret, 0) == REDIS_ERR_NO_SCHEMA);
    assert(cdbGet(db, (void*)&j, 8, sdsnew("foo"), &ret, 0) == REDIS_ERR);
    for (j = 1; j < (1L<<62); ++j) {
        assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), j) == REDIS_OK);
        assert(cdbGet(db, (void*)&j, 8, sdsnew("foo"), &ret, 0) == REDIS_OK && ret == j);
        if (j > 100000)
            break;
    }
    fprintf(stderr, "pass\n");

    cdbFree(db);
}

void testCdbReplace() {
    long j = 1, ret;

    fprintf(stderr, "Testing REPLACE without schema: ");
    cdb *db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 0);
    assert(cdbReplace(db, (void*)&j, 8, sdsnew("foo"), j) == REDIS_ERR_NO_SCHEMA);
    assert(cdbReplace(db, (void*)&j, 8, NULL, j) == REDIS_OK);
    cdbFree(db);
    fprintf(stderr, "pass\n");

    db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 1);
    assert(cdbAddColumn(db, sdsnew("foo"), 62) == REDIS_OK);

    fprintf(stderr, "Testing REPLACE: ");
    for (j = 1; j < (1L<<62); ++j) {
        assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), j) == REDIS_OK);
        assert(cdbGet(db, (void*)&j, 8, sdsnew("foo"), &ret) == REDIS_OK && ret == j);
        assert(cdbReplace(db, (void*)&j, 8, sdsnew("foo"), j+1) == REDIS_OK);
        assert(cdbGet(db, (void*)&j, 8, sdsnew("foo"), &ret) == REDIS_OK && ret == j+1);
        if (j > 100000)
            break;
    }
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing REPLACE-WITH-RESERVED-KEY: ");
    j = 0;
    assert(cdbReplace(db, (void*)&j, 8, sdsnew("foo"), j+1) == REDIS_ERR);
    memset(&j, 'F', 8);
    assert(cdbReplace(db, (void*)&j, 8, sdsnew("foo"), 0) == REDIS_ERR);
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing REPLACE-VALUE-OVERFLOW: ");
    j = 1;
    assert(cdbReplace(db, (void*)&j, 8, sdsnew("foo"), 1L<<62) == REDIS_ERR_VALUE_OVERFLOW);
    fprintf(stderr, "pass\n");

    cdbFree(db);
}

void testCdbDel() {
    long j = 1, ret;

    cdb *db = cdbCreate(1000, 10, 8, 8, 1, getScoreFromLong, 0);
    assert(cdbAddColumn(db, sdsnew("foo"), 62) == REDIS_OK);

    fprintf(stderr, "Testing DEL: ");
    j = 0;
    assert(cdbDelete(db, (void*)&j, 8) == 0);
    j = 1;
    assert(cdbDelete(db, (void*)&j, 8) == 0);
    for (j = 1; j < (1L<<62); ++j) {
        assert(cdbAdd(db, (void*)&j, 8, sdsnew("foo"), j) == REDIS_OK);
        assert(cdbDelete(db, (void*)&j, 8) == 1);
        assert(cdbDelete(db, (void*)&j, 8) == 0);
        if (j > 100000)
            break;
    }
    fprintf(stderr, "pass\n");

    cdbFree(db);
}

int main(int argc, char **argv) {
    char buf[16];
    int offset;
    int bits;
    long val;
    long cnt, num;
    long max;
    long sum = 0;

    testCdbAdd();
    testCdbGet();
    testCdbReplace();
    testCdbDel();

    /* max number of values to test for a given offset-bits pair */
    if (argc > 1)
        num = strtol(argv[1], NULL, 10);
    else
        num = 1000;

    fprintf(stderr, "Testing bit ops: ");

    for (offset = 0; offset < 16*8; offset+=1) {
        for (bits = 1; bits < 32 && offset+bits<16*8; bits+=1) {
            max = 1L << bits;
            cnt = 0;
            for (val = 0; val < max; val+=1) {
                sum++;
                val = labs(val);
                memset(buf, 0, 16);
                setValue(buf, 16, offset, bits, val);
                assert(getValue(buf, 16, offset, bits) == val);
                if (cnt++ == num)
                    break;
            }
        }
    }

    fprintf(stderr, "pass\n");
    fprintf(stderr, "Total tested values: %ld\n", sum);

    return 0;
}

#endif

