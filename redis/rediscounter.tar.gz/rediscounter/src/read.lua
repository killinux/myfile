local updates = function (mid, expect, relax)
    local time = redis.call('time')
    local ms = time[2]
    local incrby = 0
    local r1 = 0
    local r2 = 0
    if relax > 1 then
        r1 = ms % relax
        if r1 == 1 then
            r2 = ms % 2
            if r2 == 1 then
                incrby = expect*relax + 1
            else
                incrby = expect*relax
            end
        end
    else
        if expect == 1 then
            r1 = ms % 10
            if r1 > 0 then
                incrby = 1
            else
                incrby = 2
            end
        elseif expect == 2 then
            r1 = ms % 10
            if r1 > 3 then
                incrby = 2
            else
                incrby = 3
            end
        elseif expect == 3 then
            r1 = ms % 10
            if r1 == 0 then
                incrby = 1
            elseif r1 == 1 then
                incrby = 2
            elseif r1 < 4 then
                incrby = 3
            elseif r1 < 7 then
                incrby = 4
            else
                incrby = 5
            end
        elseif expect == 4 then
            r1 = ms % 10
            if r1 == 0 then
                incrby = 2
            elseif r1 == 1 then
                incrby = 3
            elseif r1 < 4 then
                incrby = 4
            elseif r1 < 6 then
                incrby = 5
            elseif r1 < 8 then
                incrby = 6
            else
                incrby = 7
            end
        elseif expect == 5 then
            r1 = ms % 10
            if r1 == 0 then
                incrby = 3
            elseif r1 == 1 then
                incrby = 4
            elseif r1 < 4 then
                incrby = 5
            elseif r1 < 6 then
                incrby = 6
            elseif r1 < 8 then
                incrby = 7
            elseif r1 == 8 then
                incrby = 8
            else
                incrby = 9
            end
        end
    return redis.call('incrby', mid, incrby)
    end
end

local j = 1
local reply = {}
for j = 1, #KEYS do
    local value = tonumber(redis.call('get', KEYS[j]))
    local v
    if value == nil or value < 100 then
        v = updates(KEYS[j], 1, 1)
    elseif value > 10000 then
        v = updates(KEYS[j], 1, 1000)
    else
        v = updates(KEYS[j], 1, 4)
    end
    reply[j] = v
end
return reply

