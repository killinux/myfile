#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <limits.h>
#include <math.h>

#include "schema.h"
#include "zmalloc.h"
#include "redis.h"

extern struct redisServer *server;

size_t fwrite_check(const void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fread_check(void *ptr, size_t size, size_t nmemb, FILE *stream);

schema *schemaCreate(int bytes, int enable_encoding)
{
    schema *sche = zmalloc(sizeof(*sche));
    sche->columns = NULL;
    sche->ncolumns = 0;
    sche->bits = bytes * 8;
    if (enable_encoding) {
        sche->encoding_enabled = 1;
        sche->used = SCHEMA_ENCODING_BITS;
    } else {
        sche->encoding_enabled = 0;
        sche->used = 0;
    }
    return sche;
}

void schemaFree(schema *sche)
{
    int j;

    if (sche->ncolumns) {
        for (j = 0; j < sche->ncolumns; ++j) {
            sdsfree(sche->columns[j]->name);
            zfree(sche->columns[j]);
        }
        zfree(sche->columns);
    }
    zfree(sche);
}

int schemaAdd(schema *sche, sds name, int bits)
{
    column *col;

    // maximum column bits is 63
    if (bits > sche->bits - sche->used || bits > 63)
        return REDIS_ERR;

    if (schemaSearch(sche, name))
        return REDIS_ERR;

    col = zmalloc(sizeof(*col));
    col->name = sdsdup(name);
    col->bits = bits;
    col->max = (1UL << bits) - 1;
    col->index = sche->ncolumns;
    col->offset = sche->used;
    col->used = 0;
    col->option = COLUMN_OPTION_READABLE | COLUMN_OPTION_WRITABLE;
    memset(&(col->stat), 0, sizeof(col->stat));

    sche->ncolumns++;
    sche->columns = zrealloc(sche->columns, sizeof(column*)*sche->ncolumns);
    sche->columns[sche->ncolumns-1] = col;
    sche->used += bits;
    return REDIS_OK;
}

column *schemaSearch(schema *sche, sds name)
{
    int j;

    for (j = 0; j < sche->ncolumns; ++j)
        if (sdscmp(sche->columns[j]->name, name) == 0)
            return sche->columns[j];

    return NULL;
}

/* Only support deleting the last column */
int schemaDelete(schema *sche, sds name)
{
    column *col = schemaSearch(sche, name);
    if (!col)
        return REDIS_OK;

    if (col->index != sche->ncolumns-1)
        return REDIS_ERR;

    sche->ncolumns--;
    sche->columns = zrealloc(sche->columns, sizeof(column*)*sche->ncolumns);
    sche->used -= col->bits;
    sdsfree(col->name);
    zfree(col);
    return REDIS_OK;
}
        

static int stringSave(FILE *fp, char *s, size_t len) 
{
    int ret = 0;
    ret = fwrite_check(&len,sizeof(len),1,fp);
    if (ret <= 0 ) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(s,len,1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;

    return len + sizeof(len);
}

static sds stringLoad(FILE *fp)
{
    int ret = 0;
    size_t len=0;
    ret = fread_check(&len,sizeof(len),1,fp);
    if (ret <= 0 ) return sdsempty();
    if(len <= 0){
        return sdsempty();
    }
    
    sds val = sdsnewlen(NULL,len);
    if (len && fread_check(val,len,1,fp) == 0) {
        sdsfree(val);
        return sdsempty();
    }
    return val;
}

static int columnSave(FILE *fp, column *col)
{
    int ret = 0;
    ret = stringSave(fp,col->name,sdslen(col->name));
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP; 
    ret = fwrite_check(&col->index,sizeof(col->index),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(&col->bits,sizeof(col->bits),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(&col->offset,sizeof(col->offset),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(&col->option,sizeof(col->option),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(&col->max,sizeof(col->max),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    ret = fwrite_check(&col->used,sizeof(col->used),1,fp);
    if (ret <= 0) return REDIS_ERR_SCHEMA_DUMP;
    
    return REDIS_OK; 
}

static column* columnLoad(FILE *fp)
{
    int ret = 0;
    sds name = stringLoad(fp);
    if (sdslen(name)<=0) return NULL; 
    
    column* col = zmalloc(sizeof(*col));
    col->name = name; 
    ret = fread_check(&col->index,sizeof(col->index),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&col->bits,sizeof(col->bits),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&col->offset,sizeof(col->offset),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&col->option,sizeof(col->option),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&col->max,sizeof(col->max),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&col->used,sizeof(col->used),1,fp);
    if (ret <= 0) goto lerr;
    
    return col;
lerr:
    if(col) zfree(col);
    return NULL;
}

#define SCHEMA_HEAD "SCHEMA00000"

int schemaSave(FILE *fp, schema *sche)
{
    if(!fp || !sche) 
    {
        return REDIS_ERR_SCHEMA_DUMP;
    }

    int ret = 0;
    ret = fwrite_check(SCHEMA_HEAD,strlen(SCHEMA_HEAD),1,fp); 
    if (ret <=0 ) goto werr;
    
    ret = fwrite_check(&sche->encoding_enabled,sizeof(sche->encoding_enabled),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&sche->bits,sizeof(sche->bits),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&sche->used,sizeof(sche->used),1,fp);
    if (ret <= 0) goto werr;

    ret = fwrite_check(&sche->ncolumns,sizeof(sche->ncolumns),1,fp);
    if (ret <= 0) goto werr;
    
    int i, ncolumns = sche->ncolumns;
    for(i=0; i<ncolumns;i++) {
        if(columnSave(fp, sche->columns[i]) < 0) goto werr; 
    }
        
    return REDIS_OK;
werr:
    return REDIS_ERR_SCHEMA_DUMP;
}

schema* schemaLoad(FILE *fp)
{
    if(!fp) 
    {
        return NULL;
    }

    int ret = 0;
    int used = 0;
    int bytes = 0;
    int ncolumns = 0;
    int encoding_enabled= 0;
    char buf[1024];

    ret = fread_check(buf,strlen(SCHEMA_HEAD),1,fp); 
    if (ret <=0 || strncmp(buf, SCHEMA_HEAD, strlen(SCHEMA_HEAD))) goto lerr;
    
    ret = fread_check(&encoding_enabled,sizeof(encoding_enabled),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&bytes,sizeof(bytes),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&used,sizeof(used),1,fp);
    if (ret <= 0) goto lerr;
    
    if (bytes % 8 != 0) goto lerr;
    
    if(bytes != server->value_size * 8)
    {
        redisLog(REDIS_NOTICE,"value_size changed, need to relocate schema value_size from %d to %d",
                bytes, server->value_size * 8);
        if(used > (server->value_size * 8))
        {
            redisLog(REDIS_WARNING,"new value_size is too small, load schema fail. %d %d",
                    used, 8*server->value_size);
            return NULL; 
        }
        bytes = server->value_size << 3;
    }
    
    bytes = bytes >> 3; // bits => bytes;
    schema* sche = schemaCreate(bytes, encoding_enabled);
    if(!sche)
    {
        return NULL;
    }

    ret = fread_check(&ncolumns,sizeof(ncolumns),1,fp);
    if (ret <= 0) goto lerr;
    
    int i;
    column* col = NULL;
    column* col2 = NULL;
    int loaderr = 0;
    for(i=0; i<ncolumns;i++) {
        col = columnLoad(fp);
        if(!col) goto lerr; 
        schemaAdd(sche, col->name, col->bits);    
        col2 = schemaSearch(sche, col->name);
        //check data
        if(!col2 || col->index != col2->index ||
            col->bits != col2->bits || col->offset != col2->offset ||
            col->max != col2->max)
        {
            loaderr = 1;
        }
        
        sdsfree(col->name);
        zfree(col);
        col = NULL;

        if(loaderr){
            loaderr = 0;
            goto lerr;
        }
    }
    
    if(used != sche->used || ncolumns != sche->ncolumns)
    {
        goto lerr;
    }

    return sche;
lerr:
    schemaFree(sche);
    return NULL;
}

#ifdef SCHEMA_TEST

void schema_to_json(FILE* fp, char* name, schema* sche)
{
    fprintf(fp,"\n{\"%s\":{",name);
    
    fprintf(fp,"\"%s\": %d,","ncolumns",sche->ncolumns);
    fprintf(fp,"\"%s\": %d,","bits",sche->bits);
    fprintf(fp,"\"%s\": %d,","used",sche->used);
    fprintf(fp,"\"%s\": %d,","encoding_enabled",sche->encoding_enabled);
    fprintf(fp,"\"%s\": {","columns");
    int i;
    for(i=0;i<sche->ncolumns;i++)
    {
        fprintf(fp,"\"%d\": {",i);
        fprintf(fp,"\"%s\": %d,","index",sche->columns[i]->index);
        fprintf(fp,"\"%s\": %d,","bits",sche->columns[i]->bits);
        fprintf(fp,"\"%s\": %d","offset",sche->columns[i]->offset);
        if( (i+1) == sche->ncolumns ){
            fprintf(fp,"}");
        }else{
            fprintf(fp,"},");
        }
    }

    fprintf(fp,"} } }\n");
}

void assert_schema_cmp(schema* sche, schema* sche2)
{
    schema_to_json(stdout, "sche", sche);
    schema_to_json(stdout, "sche2", sche2);

    assert(sche->ncolumns == sche2->ncolumns);
    assert(sche->bits == sche2->bits );
    assert(sche->used == sche2->used );
    assert(sche->encoding_enabled == sche2->encoding_enabled);
    int i;
    for(i=0;i<sche->ncolumns;i++)
    {
        assert(sche->columns[i]->index == sche2->columns[i]->index);
        assert(sche->columns[i]->bits == sche2->columns[i]->bits);
        assert(sche->columns[i]->offset == sche2->columns[i]->offset);
        assert(sche->columns[i]->max == sche2->columns[i]->max);
        assert(!sdscmp(sche->columns[i]->name, sche2->columns[i]->name));
    }
}

void schema_dump_test()
{
    fprintf(stderr, "%s: ",__func__);

    schema *sche = schemaCreate(10, 0);
    column *col;
    
    assert(schemaAdd(sche, sdsnew("first"), 4) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("second"), 3) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("third"), 5) == REDIS_OK);

    FILE* fp = fopen("schema.rdb","w");
    schemaSave(fp, sche); 
    fclose(fp);
    fp = NULL;

    fp = fopen("schema.rdb","r");
    schema* sche2 = schemaLoad(fp);
    fclose(fp);
    fp = NULL;

    assert_schema_cmp(sche, sche2);
    schemaFree(sche);
    schemaFree(sche2);
    fprintf(stderr, " pass\n");
}

void schema_dump_test2()
{
    fprintf(stderr, "%s: ",__func__);
    schema *sche = schemaCreate(10, 0);
    column *col;
    
    FILE* fp = fopen("schema.rdb","w");
    schemaSave(fp, sche); 
    fclose(fp);
    fp = NULL;

    fp = fopen("schema.rdb","r");
    schema* sche2 = schemaLoad(fp);
    fclose(fp);
    fp = NULL;

    assert_schema_cmp(sche, sche2);
    schemaFree(sche);
    schemaFree(sche2);
    fprintf(stderr, " pass\n");
}

void schema_dump_test3()
{
    fprintf(stderr, "%s: ",__func__);
    schema *sche = schemaCreate(8, 1);
    column *col;
    
    assert(schemaAdd(sche, sdsnew("cntcmt"), 16) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("cntatt"), 16) == REDIS_OK);
    assert(schemaDelete(sche, sdsnew("cntatt")) == REDIS_OK);

    FILE* fp = fopen("schema.rdb","w");
    schemaSave(fp, sche); 
    fclose(fp);
    fp = NULL;

    fp = fopen("schema.rdb","r");
    schema* sche2 = schemaLoad(fp);
    fclose(fp);
    fp = NULL;

    assert_schema_cmp(sche, sche2);
    schemaFree(sche);
    schemaFree(sche2);
    fprintf(stderr, " pass\n");
}

int main(int argc, char **argv) {
    schema_dump_test();
    schema_dump_test2();
    schema_dump_test3();

    schema *sche = schemaCreate(8, 0);
    column *col;

    fprintf(stderr, "Testing schema Add: ");
    assert(schemaAdd(sche, sdsnew("first"), 4) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("second"), 3) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("third"), 5) == REDIS_OK);

    assert(schemaAdd(sche, sdsnew("first"), 3) == REDIS_ERR);
    assert(schemaAdd(sche, sdsnew("test"), 100) == REDIS_ERR);
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing schema Search: ");
    assert(schemaSearch(sche, sdsnew("First")) == NULL);

    col = schemaSearch(sche, sdsnew("first"));
    assert(col != NULL);
    assert(sdscmp(col->name, sdsnew("first")) == 0);
    assert(col->bits == 4);
    assert(col->max = 15);

    col = schemaSearch(sche, sdsnew("second"));
    assert(col != NULL);
    assert(sdscmp(col->name, sdsnew("second")) == 0);
    assert(col->bits == 3);
    assert(col->max = 7);

    col = schemaSearch(sche, sdsnew("third"));
    assert(col != NULL);
    assert(sdscmp(col->name, sdsnew("third")) == 0);
    assert(col->bits == 5);
    assert(col->max = 31);
    fprintf(stderr, "pass\n");

    assert(SCHEMA_SIZE(sche) == 64);
    assert(SCHEMA_USED(sche) == 12);
    assert(SCHEMA_FREE(sche) == 52);

    fprintf(stderr, "Testing schema Delete: ");
    assert(SCHEMA_COLUMNS(sche) == 3);
    assert(schemaDelete(sche, sdsnew("test")) == REDIS_OK);
    assert(schemaDelete(sche, sdsnew("first")) == REDIS_ERR);
    assert(schemaDelete(sche, sdsnew("second")) == REDIS_ERR);
    assert(schemaDelete(sche, sdsnew("third")) == REDIS_OK);
    assert(SCHEMA_USED(sche) == 7);
    assert(SCHEMA_FREE(sche) == 57);
    assert(SCHEMA_COLUMNS(sche) == 2);
    fprintf(stderr, "pass\n");

    schemaFree(sche);

    fprintf(stderr, "Testing enable encoding: ");
    sche = schemaCreate(8, 1);
    assert(sche->used == 2);
    assert(schemaAdd(sche, sdsnew("first"), 4) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("second"), 3) == REDIS_OK);
    assert(schemaAdd(sche, sdsnew("third"), 5) == REDIS_OK);
    assert(schemaSearch(sche, sdsnew("First")) == NULL);

    col = schemaSearch(sche, sdsnew("first"));
    assert(col != NULL);
    assert(col->offset == 2);

    col = schemaSearch(sche, sdsnew("second"));
    assert(col != NULL);
    assert(col->offset == 6);

    col = schemaSearch(sche, sdsnew("third"));
    assert(col != NULL);
    assert(col->offset == 9);
    fprintf(stderr, "pass\n");

    return 0;
}

#endif

