for i=7,10000 do
    redis.call('set', i..'.foo', i)
    local ret = redis.call('get', i..'.foo')
    assert(tonumber(ret) == i)
    for j=1,10000000 do
        local ret = 1
    end
end
return 'ok'
