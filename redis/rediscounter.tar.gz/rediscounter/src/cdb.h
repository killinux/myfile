#ifndef __CDB_H__
#define __CDB_H__

#include "array.h"
#include "schema.h"

#define cdbNeedsRotate(cdb) (cdb->base->locked)

typedef struct cdb {
    array *base;
    schema *sche;
} cdb;

#define CDB_TOTAL(db) (arraySize(db->base))
#define CDB_USED(db) (arrayUsed(db->base))
#define CDB_DELETED(db) (arrayDeleted(db->base))
#define CDB_FREE(db) (arrayFree(db->base))
#define CDB_TOTAL_TABLES(db) (arrayTotalTables(db->base))
#define CDB_TABLE_SIZE(db, index) (arrayTableSize(arrayTableSize(db->base, index))
#define CDB_CURRENT_TABLE(db) (arrayCurrentTable(db->base))
#define CDB_COLUMNS(db) (SCHEMA_COLUMNS(db->sche))
#define CDB_COLUMN(db, index) (SCHEMA_COLUMN(db->sche, index))
#define CDB_COLUMN_SIZE(db, index) (db->sche->columns[index]->bits)

cdb *cdbCreate(long table_num, long table_size, int key_size, int value_size,
    int sort, getScore gs, int enable_encoding);
void cdbSetConfig(cdb *db, arrayConfig conf);
void cdbFree(cdb *db);
int cdbAddColumn(cdb *db, sds name, int bits);
int cdbSetColumnOption(cdb *db, sds name, int option, int is_enable);
int cdbAdd(cdb *db, char *key, int klen, sds name, uint64_t val);
int cdbGet(cdb *db, char *key, int klen, sds name, uint64_t *val, int is_from_write);
int cdbReplace(cdb *db, char *key, int klen, sds name, uint64_t val);
int cdbDelete(cdb *db, char *key, int klen);

int cdbDumpTable(cdb *db, int index);
int cdbRotateBackground(void);
void backgroundRotateDoneHandler(int statloc);


#endif
