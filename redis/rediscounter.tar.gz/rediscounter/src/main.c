#include "main.h"
#include <getopt.h>
#include <pwd.h>
#include <dlfcn.h>
#include <string.h>

#ifdef HAVE_BACKTRACE
#include <execinfo.h>
#include <ucontext.h>
#endif /* HAVE_BACKTRACE */

int mkstemp(char *template);

int dd = 0;
GLOBAL *global;
char *dir;

char *zstrdup2(const char *s) {
    size_t l = strlen(s)+1;
    char *p = malloc(l);

    memcpy(p,s,l);
    return p;
}

void logWarning(int level, const char *fmt, ...) {
    const int syslogLevelMap[] = { LOG_DEBUG, LOG_INFO, LOG_NOTICE, LOG_WARNING };
    const char *c = ".-*#";
    time_t now = time(NULL);
    va_list ap;
    FILE *fp;
    char buf[64];
    char msg[4096];

    fp = (global->logfile == NULL) ? stdout : fopen(global->logfile,"a");
    if (!fp) return;

    va_start(ap, fmt);
    vsnprintf(msg, sizeof(msg), fmt, ap);
    va_end(ap);

    strftime(buf,sizeof(buf),"%d %b %H:%M:%S",localtime(&now));
    fprintf(fp,"[%d] %s %c %s\n",(int)getpid(),buf,c[level],msg);
    fflush(fp);

    if (global->logfile) fclose(fp);

    if (global->syslog_enabled) syslog(syslogLevelMap[level], "%s", msg);
}

char *strtrim(char *s, const char *cset) {
    char *start, *end, *sp, *ep;
    size_t len;
	char *result;

    sp = start = s;
    ep = end = s+strlen(s)-1;
    while(sp <= end && strchr(cset, *sp)) sp++;
    while(ep > start && strchr(cset, *ep)) ep--;
    len = (sp > ep) ? 0 : ((ep-sp)+1);
	if (len == 0)
		return NULL;
	result = malloc(len+1);
	memcpy(result, sp, len);
	result[len] = '\0';
    return result;
}

char **strsplitlen(char *s, int len, char *sep, int seplen, int *count) {
    int elements = 0, slots = 5, start = 0, j;
    char **tokens;

    if (seplen < 1 || len < 0) return NULL;

    tokens = malloc(sizeof(char *)*slots);
    if (tokens == NULL) return NULL;

    if (len == 0) {
        *count = 0;
        return tokens;
    }
    for (j = 0; j < (len-(seplen-1)); j++) {
        /* make sure there is room for the next element and the final one */
        if (slots < elements+2) {
            char **newtokens;

            slots *= 2;
            newtokens = realloc(tokens,sizeof(char *)*slots);
            if (newtokens == NULL) {
                goto cleanup;
            }
            tokens = newtokens;
        }
        /* search the separator */
        if ((seplen == 1 && *(s+j) == sep[0]) || (memcmp(s+j,sep,seplen) == 0)) {
			tokens[elements] = malloc(j-start+1);
            if (tokens[elements] == NULL) {
                goto cleanup;
            }
			memcpy(tokens[elements], s+start, j-start);
			tokens[elements][j-start] = '\0';
            elements++;
            start = j+seplen;
            j = j+seplen-1; /* skip the separator */
        }
    }
    /* Add the final element. We are sure there is room in the tokens array. */
	tokens[elements] = malloc(len-start+1);
	if (tokens[elements] == NULL) {
		goto cleanup;
	}
	memcpy(tokens[elements], s+start, len-start);
	tokens[elements][len-start] = '\0';
    elements++;
    *count = elements;
    return tokens;

cleanup:
    {
        int i;
        for (i = 0; i < elements; i++) free(tokens[i]);
        free(tokens);
        return NULL;
    }
}

void strtolower(char *s) {
    int len = strlen(s), j;

    for (j = 0; j < len; j++) s[j] = tolower(s[j]);
}

char *getSonameFromConfig(char *filename) {
    FILE *fp;
    char buf[256];
    int linenum = 0;
    char *line = NULL;
    char *result = NULL;

    if ((fp = fopen(filename,"r")) == NULL) {
        fprintf(stderr, "Fatal error, can't open config file '%s'\n", filename);
        return result;
    }

    while(fgets(buf,256,fp) != NULL) {
        char **argv;
        int argc, j;

        linenum++;
        line = strtrim(buf," \t\r\n");
		if (line == NULL)
			continue;

        /* Skip comments and blank lines*/
        if (line[0] == '#' || line[0] == '\0') {
            free(line);
            continue;
        }

        /* Split into arguments */
        argv = strsplitlen(line,strlen(line)," ",1,&argc);
        strtolower(argv[0]);

        if (!strcasecmp(argv[0],"libredis") && argc == 2) {
            result = zstrdup2(argv[1]);
        } else if (!strcasecmp(argv[0],"dir") && argc == 2) {
            int len = strlen(argv[1]);
            if (argv[1][len-1] == '/') {
                dir = zstrdup2(argv[1]);
            } else {
                dir = malloc(len+2);
                memcpy(dir, argv[1], len);
                dir[len] = '/';
                dir[len+1] = '\0';
            }
        } else if (!strcasecmp(argv[0],"daemonize") && argc == 2) {
            if (!strcasecmp(argv[1], "yes"))
                dd = 1;
        }

        for (j = 0; j < argc; j++)
            free(argv[j]);
        free(argv);
        free(line);
    }
    fclose(fp);
    return result;
}

/* =================================== Main! ================================ */
void daemonize(void) {
    int fd;
    FILE *fp;

    if (fork() != 0) {
        sleep(1);
        int status = 0;
        waitpid(-1, &status, WNOHANG);
        exit(WEXITSTATUS(status)); /* parent exits */
    }

    setsid(); /* create a new session */

    /* Every output goes to /dev/null. If Redis is daemonized but
     * the 'logfile' is set to 'stdout' in the configuration file
     * it will not log at all. */
    if ((fd = open("/dev/null", O_RDWR, 0)) != -1) {
        dup2(fd, STDIN_FILENO);
        dup2(fd, STDOUT_FILENO);
        dup2(fd, STDERR_FILENO);
        if (fd > STDERR_FILENO) close(fd);
    }
    /* Try to write the pid file */
    fp = fopen(global->pidfile,"w");
    if (fp) {
        fprintf(fp,"%d\n",getpid());
        fclose(fp);
    }
}

int copy(char *dst, char *src) {
    struct stat st;
    char *buf;
    int fd1, fd2 = -1; /* Just to avoid warnings */
    long len;

    if (!dst || !src)
        return -1;

    if (stat(src, &st) != 0)
        return -1;

    /* Set a 10MB upper limit to protect from mal-input */
    if (st.st_size == 0 || st.st_size > 10*1024*1024) {
        logWarning(3, "File %s too small or too large, size: %ld", src, st.st_size);
        return -1;
    }

    buf = malloc(st.st_size);
    if (!buf)
        return -1;

    fd1 = open(src, O_RDONLY);
    if (fd1 == -1)
        goto cleanup;
    fd2 = open(dst, O_RDWR|O_CREAT|O_TRUNC, 0600);
    if (fd2 == -1)
        goto cleanup;

    if ((len = read(fd1, buf, st.st_size)) != st.st_size)
        goto cleanup;
    if ((len = write(fd2, buf, st.st_size)) != st.st_size)
        goto cleanup;

    close(fd1);
    close(fd2);
    free(buf);
    return 0;
cleanup:
    close(fd1);
    close(fd2);
    free(buf);
    return 0;
}

void usage() {
    fprintf(stderr,"Usage: ./redis-server /path/to/redis.conf\n");
    fprintf(stderr,"       ./redis-server --test-memory <megabytes>\n\n");
    exit(1);
}

void memtest(size_t megabytes, int passes);

int main(int argc, char **argv) {
    char name[4096];
    char newname[4096];
    int tmpfd1, tmpfd2;
    char *soname;
    int ret;

    if (argc >= 2 && strcmp(argv[1], "--test-memory") == 0) {
        if (argc == 3) {
            memtest(atoi(argv[2]),50);
            exit(0);
        } else {
            fprintf(stderr,"Please specify the amount of memory to test in megabytes.\n");
            fprintf(stderr,"Example: ./redis-server --test-memory 4096\n\n");
            exit(1);
        }
    } else if (argc != 2) {
		usage();
    }

    if ((soname = getSonameFromConfig(argv[argc-1])) == NULL) {
        fprintf(stderr, "%s\n", "No libredis specified, exit now...");
		exit(1);
    }

    if (dir == NULL) {
        fprintf(stderr, "Working dir not specified, exit now...");
        exit(1);
    }

	global = malloc(sizeof(GLOBAL));
    global->libredis = zstrdup2(soname);
    global->curr_libredis = NULL;
    free(soname);

    /* make a temp copy of libredis */
    snprintf(name, 4096, "%slibredis.so.XXXXXX", dir);
    ret = mkstemp(name);
    if (ret == -1) {
        fprintf(stderr, "Error creating tmp file %s: %s\n", name, strerror(errno));
        exit(1);
    }
    close(ret);

    if (copy(name, global->libredis) == -1) {
        fprintf(stderr, "Error creating tmp file %s: %s\n", name, strerror(errno));
        unlink(name);
        exit(1);
    }
    if ((tmpfd1 = open(name, O_RDONLY)) == -1) {
        fprintf(stderr, "Error opening tmp file %s: %s\n", name, strerror(errno));
        unlink(name);
        exit(1);
    }

    global->redis_handle = dlopen(name, RTLD_NOW | RTLD_LOCAL);
    if (!global->redis_handle) {
        fprintf(stderr, "failed to load library %s: %s\n", global->libredis, dlerror());
        unlink(name);
        return 1;
    }
    dlerror();
    *(void **)&global->redismain = dlsym(global->redis_handle, "redismain");
    char *err = dlerror();
    if (err) {
        fprintf(stderr, "failed loading symbol redismain: %s\n", err);
        unlink(name);
        return 1;
    }

    /* remove dentry of temp file */
    if(global->curr_libredis)
    {
        unlink(global->curr_libredis);
        free(global->curr_libredis);
        global->curr_libredis = NULL;
    }
    global->curr_libredis = zstrdup2(name);

    if (dd) daemonize();

    int load = 1;
    while (1) {
        char *newso = (*global->redismain)(argv[argc-1], load);
        load = 0;
        if (newso == NULL)
            continue;

        /* make a temp copy for new libredis */
        snprintf(newname, 4096, "%slibredis.XXXXXX", dir);
        ret = mkstemp(newname);
        if (ret == -1) {
            logWarning(3, "Error creating tmp file %s: %s\n", newname, strerror(errno));
            unlink(newname);
            continue;
        }
        close(ret);

        if (copy(newname, newso) == -1) {
            logWarning(3, "Error creating tmp file, live update failed");
            unlink(newname);
            continue;
        }
        if ((tmpfd2 = open(newname, O_RDONLY)) == -1) {
            logWarning(3, "Error opening tmp file %s: %s", newname, strerror(errno));
            unlink(newname);
            continue;
        }

        dlerror();
        void *handle = dlopen(newname, RTLD_NOW | RTLD_LOCAL);
        if (!handle) {
            logWarning(3, "Error loading library %s: %s\n", newso, dlerror());
            close(tmpfd2);
            unlink(newname);
            continue;
        }
        dlerror();
        redis_main r;
        *(void **)&r = dlsym(handle, "redismain");
        char *err = dlerror();
        if (err) {
            logWarning(3, "Failed loading symbol redismain: %s\n", err);
            dlclose(handle);
            close(tmpfd2);
            unlink(newname);
            continue;
        }

        /* unload old library */
        int ret = dlclose(global->redis_handle);
        if (ret) {
            logWarning(3, "Error unloading library: %s\n", dlerror());
            dlclose(handle);
            close(tmpfd2);
            unlink(newname);
            continue;
        }

        /* remove dentry of the new copy */
        if(global->curr_libredis)
        {
            unlink(global->curr_libredis);
            free(global->curr_libredis);
            global->curr_libredis = NULL;
        }
        global->curr_libredis = zstrdup2(newname);
        /* remove old temp file */
        close(tmpfd1);
        tmpfd1 = tmpfd2;

        global->redis_handle = handle;
		if (global->libredis)
			free(global->libredis);
        global->libredis = zstrdup2(newso);
        global->redismain = r;
        continue;
    }

    /* never gets here */
    return 0;
}

/* The End */

