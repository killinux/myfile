#include "fmacros.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>

#include "array.h"
#include "zmalloc.h"
#include "redis.h"

uint32_t crc32(const void *buf, size_t size);
uint64_t crc64(uint64_t crc, const unsigned char *s, uint64_t l);
size_t fwrite_check(const void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fread_check(void *ptr, size_t size, size_t nmemb, FILE *stream);
int posix_fadvise64(int fd, uint64_t offset, uint64_t len, int advice);
long long getValue(char *buf, int len, int offset, int bits);

unsigned char g_empty_key[256] = {0};
unsigned char g_deleted_key[256] = "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF";
/* ----------------------------- API implementation ------------------------- */
static table *tableCreate(long size, int key_size, int value_size, int sort);
static void tableFree(table *t);
static void tableInit(table *t, long slots);
static int arrayInit(array *l, long table_num, long table_size);
static void arrayRotate(array *l);
static void arrayRotateIfNecessary(array *l, int index);
static int tableFindIndexForKey(table *t, char *key, int key_len, long *index);
static long tableFindKey(table *t, char *key, int key_len);

/* ----------------------------- Utilities ------------------------- */
/* check if value is prime, return 1 if it is, 0 otherwise */
static int isPrime(unsigned long value)
{
    unsigned long i;
    if (value <= 1)
        return 0;
    if (value == 2)
        return 1;
    if (value % 2 == 0)
        return 0;

    for (i = 3; i < sqrt(value) + 1; ++i)
        if (value % i == 0)
            return 0;

    return 1;
}

/* return the minimum prime bigger or equal than value */
unsigned long nextPrime(unsigned long value)
{
    int step = (value % 2 == 0) ? 1 : 2;
    unsigned long i;

    for (i = value; ; i+=step)
        if (isPrime(i))
            return i;
}

static unsigned long hashKey(char *key, int key_len) {
    unsigned long hash = 5381;

    while (key_len--) {
        hash = ((hash << 5) + hash) + *(key++);    /* hash * 33 + c */
    }
    return hash;
}

static unsigned long th1(table *t, char *key, int key_len) {
    return hashKey(key, key_len) % t->size;
}

static unsigned long th2(table *t, char *key, int key_len) {
    return hashKey(key, key_len) % (t->size-2) + 1;
}

/* Optimization: speed up search */
int getTableIdForScore(array *l, long score) {
    int i;
    table *t;

    if (l->current == 0)
        return 0;

    if (score >= l->tables[l->current]->min)
        return l->current;

    for (i = l->current-1; i >= 0; --i) {
        t = l->tables[i];
        if (score >= t->min && score <= t->max)
            return i;
    }

    /* score < l->tables[0]->min */
    return -1;
}

int getTableIdForKey(array *l, void *key, int len) {
    int i;
    long score;
    table *t;

    if (!l->sort)
        return abs(crc32(key, len) % l->ntables);

    score = l->gs(key, len);
    if (l->tables[l->current]->min == LONG_MAX ||
        score >= l->tables[l->current]->min)
    {
        return l->current;
    }

    for (i = l->current-1; i >= 0; --i) {
        t = l->tables[i];
        if (score >= t->min && score <= t->max)
            return i;
    }

    /* score < l->tables[0]->min */
    return -1;
}


/* ----------------------------- Table operations ------------------------- */
table *tableCreate(long size, int key_size, int value_size, int sort)
{
    table *t = zmalloc(sizeof(*t));
    t->sort = sort;
    t->locked = 0;
    t->key_size = key_size;
    t->value_size = value_size;
    t->entry_size = key_size + value_size;
    t->ht = zmalloc(size * t->entry_size);
    tableInit(t, size);
    return t;
}

void tableInit(table *t, long size)
{
    memset(t->ht, 0, size*t->entry_size);
    t->max = LONG_MIN;
    t->min = LONG_MAX;
    t->rmin = LONG_MAX;
    t->size = size;
    t->used = 0;
    t->deleted = 0;
    memset(&(t->stat), 0, sizeof(t->stat));     
}

void tableFree(table *t)
{
    if (t) {
        zfree(t->ht);
        zfree(t);
        t = NULL;
    }
}

void tableSetIndexKey(table *t, long index, void *key, int len) {
    char *p = t->ht+index*t->entry_size;
    memcpy(p, g_empty_key, t->key_size);
    memcpy(p, key, len);
}

void tableSetIndexVal(table *t, long index, void *val, int len) {
    (void)len;
    char *p = t->ht+index*t->entry_size+t->key_size;
    memcpy(p, g_empty_key, t->value_size);
    memcpy(p, val, len);
}

void *tableGetIndexKey(table *t, long index) {
    char *p = t->ht+index*t->entry_size;
    return p;
}

void *tableGetIndexVal(table *t, long index) {
    char *p = t->ht+index*t->entry_size+t->key_size;
    return p;
}

int tableIsEmpty(table *t, long index) {
    return !memcmp(t->ht+index*t->entry_size, g_empty_key, t->key_size);
}

int tableIsDeleted(table *t, long index) {
    return !memcmp(t->ht+index*t->entry_size, g_deleted_key, t->key_size);
}

int tableIndexEqualKey(table *t, long index, void *key, int len) {
    (void)len;
    char *p = t->ht+index*t->entry_size;
    return !memcmp(p, key, t->key_size);
}

void tableDeleteIndex(table *t, long index) {
    char *p = t->ht+index*t->entry_size;
    array *l = server->db2->db->base;
    schema *sche = server->db2->db->sche;
    int i;
    for (i = 0; i < sche->ncolumns; ++i) {
        int old_val = getValue(p+t->key_size, arrayValueSize(l), sche->columns[i]->offset, sche->columns[i]->bits); 
        if(old_val != 0) {
            sche->columns[i]->used--;
            sche->columns[i]->stat.setCount++;
        } 
    }

    memcpy(p, g_deleted_key, t->key_size);     
}

void tableDeleteEntry(table *t, long index) {
    tableDeleteIndex(t, index);
    t->used--;
    t->deleted++;
    ((array*)(t->l))->used--;
    ((array*)(t->l))->deleted++;
}

int tableFind(table *t , char *key, int key_len, char **result)
{
    long index;

    index = tableFindKey(t, key, key_len);
    if (index == -1)
        return REDIS_ERR_NOT_FOUND; 
    else if (index == -2)
        return REDIS_ERR_TOO_MANY_COLLISION;

    *result = t->ht+index*t->entry_size+t->key_size;
    return REDIS_OK;
}

/* return index to entry where @key resides, -1 if not exists. */
long tableFindKey(table *t, char *key, int key_len)
{
    long r, q, hs;
    long s;

    r = th1(t, key, key_len);
    if (tableIsEmpty(t, r))
        return -1;
    q = th2(t, key, key_len);

    for (s = 0; s < t->size; ++s) {
        if (s > ((array*)(t->l))->collision_threshold)
            return -2;
        hs = labs((r+s*q) % t->size);
        if (tableIsEmpty(t, hs)) {
            return -1;
        } else if (tableIndexEqualKey(t, hs, key, key_len)) {
            return hs;
        }
    }

    return -1;
}

/* find slot for @key, if @key exists, set *index to slot and return ARRAY_EXISTS,
 * otherwise set *index to the slot where it belongs and return REDIS_OK,
 * return REDIS_ERR_TOO_MANY_COLLISION when the collision exceeds limit,
 * return REDIS_ERR when dict is full and @key does not exists. */
int tableFindIndexForKey(table *t, char *key, int key_len, long *index)
{
    long r, q, hs;
    long s;
    int found = 0;
    long idx;

    r = th1(t, key, key_len);
    if (tableIsEmpty(t, r)) {
        *index = r;
        return REDIS_OK;
    }

    q = th2(t, key, key_len);
    for (s = 0; s < t->size; ++s) {
        if (s > ((array*)(t->l))->collision_threshold)
            return REDIS_ERR_TOO_MANY_COLLISION;
        hs = labs((r+s*q) % t->size);
        if (tableIsEmpty(t, hs)) {
            if (found)
                *index = idx;
            else 
                *index = hs;
            return REDIS_OK;
        } else if (tableIndexEqualKey(t, hs, key, key_len)) {
            *index = hs;
            return REDIS_ERR_KEY_EXISTS;
        } else if (!found && tableIsDeleted(t, hs)) {
            found = 1;
            idx = hs;
        }
    }

    /* dict has no empty slots, but we've found a deleted slot. */
    if (found) {
        *index = idx;
        return REDIS_OK;
    }

    /* dict is full and @key is not found. */
    return REDIS_ERR;
}

/* TODO: Incrementally expansion support */
table *tableExpand(table *t, long dsize) {
    long size;
    table *nt;
    long j, index;
    void *key;
    char *val;
    int ret;

    size = nextPrime(dsize);
    nt = tableCreate(size, t->key_size, t->value_size, t->sort);
    for (j = 0; j < t->size; ++j) {
        if (tableIsEmpty(t, j) || tableIsDeleted(t, j))
            continue;
        key = tableGetIndexKey(t, j);
        val = tableGetIndexVal(t, j);

        ret = tableFindIndexForKey(nt, key, t->key_size, &index);
        assert(ret == REDIS_OK);
        tableSetIndexKey(nt, index, key, t->key_size);
        tableSetIndexVal(nt, index, val, t->value_size);
    }
    nt->size = size;
    nt->key_size = t->key_size;
    nt->value_size = t->value_size;
    nt->entry_size = t->entry_size;
    nt->used = t->used;
    nt->deleted = 0;
    nt->min = t->min;
    nt->max = t->max;
    nt->index = t->index;
    nt->l = t->l;
    ((array*)(nt->l))->size -= t->size;
    ((array*)(nt->l))->size += nt->size;
    ((array*)(nt->l))->deleted -= t->deleted;
    tableFree(t);
    return nt;
}

/* Auto expansion is disabled, use manual expansion otherwise we could be
 * killed by OOM when trying to create a bigger table. */
table *expandTableIfNecessary(table *t) {
    return t;
    /*
    if (t->used+t->deleted <= t->size*ARRAY_TABLE_EXPAND_THRESHOLD/100)
        return t;
    return tableExpand(t, t->used*2);
    */
}

/* ----------------------------- ARRAY operations ------------------------- */
array *arrayCreate(long table_num, long table_size, int key_size, int value_size,
    int sort, getScore gs)
{
    if (sort && !gs)
        return NULL;
    array *l = zmalloc(sizeof(*l));
    l->sort = sort;
    l->locked = 0;
    l->gs = gs;
    l->key_size = key_size;
    l->value_size = value_size;
    l->entry_size = key_size + value_size;
    l->rotate_threshold = ARRAY_TABLE_DEFAULT_ROTATE_THRESHOLD;
    l->expand_threshold = ARRAY_TABLE_DEFAULT_EXPAND_THRESHOLD;    
    l->collision_threshold = ARRAY_TABLE_DEFAULT_COLLISION_THRESHOLD;  
    arrayInit(l, table_num, nextPrime(table_size));

    return l;
}

void arraySetConfig(array *l, arrayConfig conf)
{
    l->rotate_threshold = conf.rotate_threshold;
    l->expand_threshold = conf.expand_threshold;    
    l->collision_threshold = conf.collision_threshold;  
}

void arrayFree(array *l) {
    int j;

    for (j = 0; j < l->ntables; ++j) {
        if (l->tables[j]) {
            tableFree(l->tables[j]);
            l->tables[j] = NULL;
        }
    }

    zfree(l);
}

int arrayInit(array *l, long table_num, long table_size)
{
    int i;

    l->table_size = table_size;
    int ntables = table_num;
    l->tables = zmalloc(ntables * sizeof(table*));
    for (i = 0; i < ntables; ++i)
        l->tables[i] = NULL;

    for (i = 0; i < ntables; ++i) {
        l->tables[i] = tableCreate(l->table_size, l->key_size,
            l->value_size, l->sort);
        l->tables[i]->l = l;
        l->tables[i]->index = i;
        if (l->sort) {
            l->tables[0]->min = 0;
            break;
        }
    }

    l->min = LONG_MAX;
    l->max = LONG_MIN;
    l->size = l->table_size * ntables;
    l->ntables = ntables;
    l->used = 0;
    l->deleted = 0;
    l->current = 0;
    memset(&(l->stat), 0, sizeof(l->stat));

    return REDIS_OK;
}

int arrayAdd(array *l, char *key, int key_len, char *val, int val_len)
{
    long index, score;
    int ret, id;
    table *t;

    if (memcmp(key, g_empty_key, key_len) == 0 ||
        memcmp(key, g_deleted_key, key_len) == 0)
    {
        return REDIS_ERR_KEY_RESERVED;
    }

    if (l->sort)
        arrayRotateIfNecessary(l, l->current);

    id = getTableIdForKey(l, key, key_len);
    if (id == -1) {
        return REDIS_ERR_KEY_OUTOFRANGE;
    }

    t = l->tables[id];
    ret = tableFindIndexForKey(t, key, key_len, &index);
    if (ret == REDIS_OK && 
       (t->used * 100 / t->size >= ARRAY_TABLE_DEFAULT_FULL_THRESHOLD) ) {
        //Table is too full, refuse 
        return REDIS_ERR_TOO_MANY_COLLISION;
    }
    if (ret == REDIS_OK) {
        if (tableIsDeleted(t, index)) {
            t->deleted--;
            l->deleted--;
        }
        t->used++;
        l->used++;
        t->stat.setCount++;

        tableSetIndexKey(t, index, key, key_len);
        tableSetIndexVal(t, index, val, val_len);

        if (l->sort) {
            score = l->gs(key, key_len);
            /* table[0]'s min will be 0 at start */
#if 0
            if (id == 0 && t->used == 0) {
                t->max = score;
                /* reset table[0]'s min id, the rest equals table[i-1]->max+1 */
                t->min = score;
            }
#endif
            if (score > t->max)
                t->max = score;
            if (score < t->rmin)
                t->rmin = score;
            /* table's min should not be modified */
            /*
            if (score < t->min)
                t->min = score;
            */
        }

        return REDIS_OK;
    } else if (ret == REDIS_ERR_KEY_EXISTS) {
        return REDIS_ERR_KEY_EXISTS;
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        return ret;
    } else {
        l->stat.fullCount++;
        return REDIS_ERR;
    }
}

/* Not used for now */
#if 0
int arrayReplace(array *l, char *key, int key_len, char *val, int val_len)
{
    int ret, id;
    long index, score;
    table *t;

    if (memcmp(key, g_empty_key, key_len) == 0 ||
        memcmp(key, g_deleted_key, key_len) == 0)
    {
        return REDIS_ERR_KEY_RESERVED;
    }

    if (l->sort)
        arrayRotateIfNecessary(l, l->current);

    id = getTableIdForKey(l, key, key_len);
    if (id == -1)
        return REDIS_ERR_KEY_OUTOFRANGE;

    t = l->tables[id];
    ret = tableFindIndexForKey(t, key, key_len, &index);
    if (ret == REDIS_ERR_KEY_EXISTS) {
        t->stat.setCount++;
        tableSetIndexVal(t, index, val, val_len);
        return REDIS_OK;
    } else if (ret == REDIS_OK) {
        if (tableIsDeleted(t, index)) {
            t->deleted--;
            l->deleted--;
        }
        t->used++;
        l->used++;
        t->stat.setCount++;

        tableSetIndexKey(t, index, key, key_len);
        tableSetIndexVal(t, index, val, val_len);

        if (l->sort) {
            score = l->gs(key, key_len);
            if (id == 0 && t->max == LONG_MIN && t->min == LONG_MAX) {
                t->max = score;
                t->min = score;
            }
            if (score > t->max)
                t->max = score;
            if (score < t->min)
                t->min = score;
        }
        return REDIS_OK;
    } else if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        return ret;
    } else {
        return REDIS_ERR;
    }
}
#endif

int arrayGet(array *l, char *key, int key_len, char **result, int is_from_write) {
    int id, ret;
    table *t;
    char *entry = NULL;

    if (l->sort)
        arrayRotateIfNecessary(l, l->current);

    id = getTableIdForKey(l, key, key_len);
    if (id == -1) {  
        return REDIS_ERR_KEY_OUTOFRANGE;
    }

    t = l->tables[id];
    ret = tableFind(t, key, key_len, &entry);
    if(!is_from_write){
        t->stat.getCount++;
        if(ret != REDIS_OK){
            //array* l = (array*)(t->l);
            //l->stat.missCount++;
            //t->stat.missCount++;
        }         
    }
    if (ret == REDIS_ERR_NOT_FOUND && 
       (t->used * 100 / t->size >= ARRAY_TABLE_DEFAULT_FULL_THRESHOLD)) {
        ret = REDIS_ERR_TOO_MANY_COLLISION; 
    }
    if (ret == REDIS_ERR_TOO_MANY_COLLISION) {
        if (is_from_write && l->sort) {
            long score = l->gs(key, key_len);
            if (score > t->max) {
                t->max = score;
                if (id < l->ntables-1) {
                    table *nt = l->tables[id+1];
                    if (nt)
                        nt->min = score + 1;
                }
            }
        }
    }

    if (result)
        *result = entry;
    return ret;  
}

int arrayDel(array *l, char *key, int key_len)
 {    int id;
    long index;
    table *t;

    id = getTableIdForKey(l, key, key_len);
    if (id == -1)
        return REDIS_ERR;

    t = l->tables[id];
    index = tableFindKey(t, key, key_len);
    if (index == -1)
        return REDIS_ERR;
    else if (index == -2)
        return REDIS_ERR_TOO_MANY_COLLISION;

    tableDeleteEntry(t, index);
    return REDIS_OK;
}

void arrayEmpty(array *l) {
    int j;

    for (j = 0; j < l->ntables; ++j) {
        if (l->tables[j]) {
            tableFree(l->tables[j]);
            l->tables[j] = NULL;
        }
    }

    zfree(l->tables);
    arrayInit(l, l->ntables, l->table_size);

    // clear all column's used
    schema *sche = server->db2->db->sche;
    int i;
    for (i = 0; i < sche->ncolumns; ++i) {
        column *col = sche->columns[i];
        col->used = 0;
        memset(&(col->stat), 0, sizeof(col->stat));
    }    
}

void arrayRotate(array *l)
{
    table *t;

    if (l->current != l->ntables-1) {
        l->current++;
        t = l->tables[l->current];
        if (!t)
            t = tableCreate(l->table_size, l->key_size, l->value_size,
                l->sort);
        t->l = l;
        t->index = l->current;
        t->min = l->tables[l->current-1]->max+1;
        l->tables[l->current] = t;
    } else {
        if (!l->locked) {
            t = l->tables[0];
            t->locked = 1;
            l->locked = 1;
        }
    }
}

void arrayRotateTable(array *l)
{
    int j;
    table *t = l->tables[0];

    for (j = 1; j < l->ntables; ++j) {
        l->tables[j-1] = l->tables[j];
        l->tables[j-1]->index--;
    }
    l->used -= t->used;
    l->deleted -= t->deleted;
    tableInit(t, t->size);
    //t->min = l->tables[l->current-1]->max+1;
    t->index = l->current;
    l->tables[l->current] = t;
    if (l->current > 0)
        l->current--;

    t->locked = 0;
    l->locked = 0;
}

void arrayRotateIfNecessary(array *l, int index) {
    table *t = l->tables[index];
    if (index == l->ntables-1) {
        arrayRotate(l);
        return;
    }
    if (t->used <= t->size*l->rotate_threshold/100)
        return;
    else
        arrayRotate(l);
}

int arrayExpandTable(array *l, int index, long size) {
    if (index < 0 || index > l->ntables-1 || l->tables[index] == NULL)
        return REDIS_ERR;
    if (size < l->tables[index]->used)
        return REDIS_ERR;
    l->tables[index] = tableExpand(l->tables[index], size);
    return REDIS_OK;
}

#define TABLE_HEAD "TABLE000000"
// 32*1024*1024
#define TABLE_STEP 33554432

int tableSave(FILE *fp, table *t, int id)
{
    if(!fp || !t) 
    {
        return REDIS_ERR_SAVE_TABLE;
    }
    
    char buf[1024];
    snprintf(buf,sizeof(buf),"TABLE%6d", id);

    int ret = 0;
    ret = fwrite_check(buf,strlen(buf)+1,1,fp); 
    if (ret <=0 ) goto werr;
    
    ret = fwrite_check(&t->key_size,sizeof(t->key_size),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->value_size,sizeof(t->value_size),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->size,sizeof(t->size),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->sort,sizeof(t->sort),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->locked,sizeof(t->locked),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->rmin,sizeof(t->rmin),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->min,sizeof(t->min),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->max,sizeof(t->max),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->used,sizeof(t->used),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->deleted,sizeof(t->deleted),1,fp);
    if (ret <= 0) goto werr;
    
    ret = fwrite_check(&t->index,sizeof(t->index),1,fp);
    if (ret <= 0) goto werr;
 
    /* flush before we start */
    /* NOTE: This must be done when mixing fwrite and write on the same fp to
     *       get the correct file position for write. */
    fflush(fp);
    fsync(fileno(fp));
    posix_fadvise64(fileno(fp), 0, 0, POSIX_FADV_DONTNEED);

    long size = (t->key_size + t->value_size) * t->size;
    long i=0;
    long step = TABLE_STEP;
    for(;i<=size;i+=step)
    {
        step = (size-i) < step ? size-i : step;
        if(!step)
            break;
        server->dbfile_cksum = crc64(server->dbfile_cksum, (const unsigned char*)(t->ht+i), sizeof(char)*step);
        ret = write(fileno(fp), t->ht+i, sizeof(char)*step);
        if (ret <= 0) goto werr;
        fsync(fileno(fp));
        posix_fadvise64(fileno(fp), 0, 0, POSIX_FADV_DONTNEED);
    }
    
    fsync(fileno(fp));
    posix_fadvise64(fileno(fp), 0, 0, POSIX_FADV_DONTNEED);
    return 0;

werr:
    return -1;
}

table* tableLoad(FILE *fp, getScore gs)
{
    if(!fp) 
    {
        return NULL;
    }
    
    int ret = 0;
    long size; 
    int key_size, value_size, sort;
    char buf[1024];
    ret = fread_check(buf,strlen(TABLE_HEAD)+1,1,fp); 
    if (ret <=0 || strncmp(buf, TABLE_HEAD, strlen("TABLE"))) goto lerr;

    ret = fread_check(&key_size,sizeof(key_size),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&value_size,sizeof(value_size),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&size,sizeof(size),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&sort,sizeof(sort),1,fp);
    if (ret <= 0) goto lerr;
        
    table* t = tableCreate(size, key_size, value_size, sort);
    if (!t) goto lerr;
    
    ret = fread_check(&t->locked,sizeof(t->locked),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->rmin,sizeof(t->rmin),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->min,sizeof(t->min),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->max,sizeof(t->max),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->used,sizeof(t->used),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->deleted,sizeof(t->deleted),1,fp);
    if (ret <= 0) goto lerr;
    
    ret = fread_check(&t->index,sizeof(t->index),1,fp);
    if (ret <= 0) goto lerr;
    
    size = (t->key_size + t->value_size) * t->size;
    long i=0;
    long step = TABLE_STEP;
    for(;i<=size;i+=step)
    {
        step = (size-i) < step ? size-i : step;
        if(!step) 
            break;
        ret = fread_check(t->ht+i,sizeof(char),step,fp);
        if (ret <= 0) goto lerr;
    }

    t->gs = gs;
    return t;

lerr:
    if(t) tableFree(t);
    return NULL;
}

#define ARRAY_HEAD "ARRAY00000"

int arraySave(FILE *fp, array *l)
{
    if(!fp || !l) 
    {
        return REDIS_ERR;
    }

    int ret = 0, i;
    ret = fwrite_check(ARRAY_HEAD,strlen(ARRAY_HEAD),1,fp); 
    if (ret <=0 ) goto werr;
    
    ret = fwrite_check(&l->ntables,sizeof(l->ntables),1,fp);
    if (ret <= 0) goto werr;

    ret = fwrite_check(&l->current,sizeof(l->current),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->locked,sizeof(l->locked),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->sort,sizeof(l->sort),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->min,sizeof(l->min),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->max,sizeof(l->max),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->size,sizeof(l->size),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->used,sizeof(l->used),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->deleted,sizeof(l->deleted),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->rotate_threshold,sizeof(l->rotate_threshold),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->expand_threshold,sizeof(l->expand_threshold),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->collision_threshold,sizeof(l->collision_threshold),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->table_size,sizeof(l->table_size),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->key_size,sizeof(l->key_size),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->value_size,sizeof(l->value_size),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->entry_size,sizeof(l->entry_size),1,fp);
    if (ret <= 0) goto werr;
    ret = fwrite_check(&l->stat,sizeof(l->stat),1,fp);
    if (ret <= 0) goto werr;

    for(i=0;i<=l->current;++i) {
        ret = tableSave(fp, l->tables[i], i); 
        if (ret < 0) goto werr;
    }
    
    return 0;
werr:
    return -1;
}

long long getValue(char *buf, int len, int offset, int bits);
void dictSetHash(dict *d, robj *key, robj *field, robj *value);

int auxLoad(dict* aux, schema* sche, char* key, int key_size, char* value, int value_size)
{
    if(!sche) return REDIS_ERR_NO_SCHEMA;
    
    if(!aux || !key || !value) return REDIS_ERR_INVALID_PARAM;
    
    if(value_size < sche->used) return REDIS_ERR_INVALID_KEY;

    int i = 0;
    long long val = 0;
    column *col;
    robj *keyobj, *fieldobj, *valueobj;
    for(i=0; i<sche->ncolumns; ++i)
    {
        col = sche->columns[i];
        if(!col) return REDIS_ERR_INVALID_KEY;

        keyobj = createStringObject(key, key_size);
        fieldobj = createStringObject(col->name, sdslen(col->name));
        val = getValue(value, value_size, col->offset, col->bits);
        valueobj = createStringObjectFromLongLong(val);
        dictSetHash(aux, keyobj, fieldobj, valueobj);
        decrRefCount(keyobj);
        decrRefCount(fieldobj);
        decrRefCount(valueobj);
    }
    return REDIS_OK;
}

static int isDumpFile(const struct dirent *ent) {
    if (ent && ent->d_name && !strncmp(ent->d_name, "dump-", 5)) {
        return 1;
    }
    return 0;
}

static int sort_by_time(const void *a, const void *b) {
    const struct dirent** da = (const struct dirent**)(a);
    const struct dirent** db = (const struct dirent**)(b);
    const char* pa = strrchr((*da)->d_name, '-');
    const char* pb = strrchr((*db)->d_name, '-');
    while (*pa && *pa == *pb) {
        ++pa;
        ++pb;
    }
    if (*pa == *pb) {
        return 0;
    } else if (*pa < *pb) {
        return -1;
    } 
    return 1;
}

static int loadTableData(const char* filename, char* data, int size) {
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        redisLog(REDIS_WARNING, "Cann't open file %s:%s", filename, strerror(errno));
        return -1;
    }
    struct redis_stat st;
    if (redis_fstat(fd, &st) == -1) {
        redisLog(REDIS_WARNING, "Cann't stat file %s:%s", filename, strerror(errno));
        return -1;
    }

    if (size != st.st_size) {
        redisLog(REDIS_WARNING, "file %s stat size not equal %d != %d", 
                filename, st.st_size, size);
        return -1;
    }
    ssize_t ret = read(fd, data, size);
    if (size != ret) {
        redisLog(REDIS_WARNING, "file %s read size not equal %d != %d", 
                filename, size, ret);
        return -1;
    }
    close(fd);
    return 0;
}

static void fix_table_meta(table *t, array *l, int index) {
    redisLog(REDIS_WARNING, "size:%d used:%d key_size:%d value_size:%d index:%d",
            t->size, t->used, t->key_size, t->value_size, t->index);
    int entry_size = t->entry_size;
    t->max = LONG_MIN;
    t->min = LONG_MAX;
    t->rmin = LONG_MAX;
    t->used = 0;
    t->deleted = 0;
    for (int i = 0; i < t->size; ++i) {
        if (tableIsDeleted(t, i)) {
            ++t->deleted;
            continue;
        }
        if (tableIsEmpty(t, i)) {
            continue;
        }
        long key = *(long *)(t->ht + i * entry_size);
        if (key != 0) {
            if (key < t->rmin) {
                t->rmin = key;
            }
            if (key > t->max) {
                t->max = key;
            }
            ++t->used;
        }
    }
    if (index > 0) {
        t->min = 1 + l->tables[index - 1]->max;
    } else {
        t->min = t->rmin;
    }
    redisLog(REDIS_WARNING, "rmin:%lld min:%lld max:%lld used:%d deleted:%d",
            t->rmin, t->min, t->max, t->used, t->deleted);
}

static void fix_array_meta(array *l, int index) {
    l->max = LONG_MIN;
    l->min = LONG_MAX;
    l->used = 0;
    l->deleted = 0;
    for (int i = 0; i < index; ++i) {
        if (l->max < l->tables[i]->max) {
            l->max = l->tables[i]->max;
        } 
        if (l->min < l->tables[i]->min) {
            l->min = l->tables[i]->min;
        } 
        l->used += l->tables[i]->used;
        l->deleted += l->tables[i]->deleted;
    }
    l->current = index - 1;
}

array* arrayLoad(FILE *fp, schema* sche, getScore gs)
{
    if(!fp || !sche) 
    {
        return NULL;
    }
    
    if(server->value_size * 8 < sche->used) 
    {
        char tmpbuf[1024];
        snprintf(tmpbuf,sizeof(tmpbuf),"server->value_size too small %d < %d", server->value_size*8, sche->used);
        redisPanic(tmpbuf);
    }

    int ret = 0, i, ntables;
    char buf[1024];
    array* l = zmalloc(sizeof(array));
    ret = fread_check(buf,strlen(ARRAY_HEAD),1,fp); 
    if (ret <=0 || strncmp(buf, ARRAY_HEAD, strlen(ARRAY_HEAD))) goto lerr;
    
    ret = fread_check(&ntables,sizeof(ntables),1,fp);
    if (ret <= 0) goto lerr;
    
    l->ntables = server->table_num;
    l->gs = gs;
    l->tables = NULL;
    ret = fread_check(&l->current,sizeof(l->current),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->locked,sizeof(l->locked),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->sort,sizeof(l->sort),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->min,sizeof(l->min),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->max,sizeof(l->max),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->size,sizeof(l->size),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->used,sizeof(l->used),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->deleted,sizeof(l->deleted),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->rotate_threshold,sizeof(l->rotate_threshold),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->expand_threshold,sizeof(l->expand_threshold),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->collision_threshold,sizeof(l->collision_threshold),1,fp);
    if (ret <= 0) goto lerr;
    if (l->collision_threshold != server->collision_threshold) {
        redisLog(REDIS_WARNING, "Collision threshold does not match, conf: %ld, rdb: %ld",
            server->collision_threshold, l->collision_threshold);
        redisPanic("Invalid collision threshold number");
    }
    ret = fread_check(&l->table_size,sizeof(l->table_size),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->key_size,sizeof(l->key_size),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->value_size,sizeof(l->value_size),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->entry_size,sizeof(l->entry_size),1,fp);
    if (ret <= 0) goto lerr;
    ret = fread_check(&l->stat,sizeof(l->stat),1,fp);
    if (ret <= 0) goto lerr;
    
    if(l->table_size != server->table_size)
    {
        char tmpbuf[1024];
        snprintf(tmpbuf,sizeof(tmpbuf),"Error: table_size in conf:%ld != table_size in rdb:%ld", server->table_size, l->table_size);
        redisLog(REDIS_WARNING,"%s",tmpbuf);
        redisPanic(tmpbuf);
    }
    int start_table_num = 0;
    l->tables = zmalloc(l->ntables* sizeof(table*));
    for (i = 0; i < l->ntables; ++i)
        l->tables[i] = NULL;
    
    if(l->ntables != ntables) 
    {
        redisLog(REDIS_NOTICE, "Change table number from %d to %d", ntables, l->ntables);
        start_table_num = l->current - l->ntables;
        if(start_table_num < 0) 
        {
            start_table_num = 0;
        }
    }
        
    for(i=0;i<start_table_num;++i) {
        table* t = tableLoad(fp,gs); 
        if (!t) goto lerr;
        tableFree(t);
    }

    int index;
    if(l->value_size != server->value_size)
    {
        for(index = 0, i=start_table_num;i<=l->current;++i, ++index) {
            table* t = tableLoad(fp,gs); 
            if (!t) goto lerr;
            table* t2 = tableCreate(t->size,t->key_size,server->value_size,t->sort);

            char* start = t->ht;
            char* p = NULL;
            char* p2 = NULL;
            int step = t->key_size + t->value_size;
            int step2 = t->key_size + server->value_size;
            for(int j=0; j<t->size;j++)
            {
                p = start + j*step;
                p2 = t2->ht + j*step2;
                memcpy(p2,p,sche->used+t->key_size);
            }
            t2->used = t->used;
            t2->index = index;
            t2->l = l;
            t2->locked = t->locked;
            t2->min = t->min;
            t2->max = t->max;
            t2->used = t->used;
            t2->deleted = t->deleted;
            t2->gs = gs;
            
            tableFree(t);
            l->tables[index] = t2;
        }
        l->value_size = server->value_size;
    }else {
        //cydu: load data into memory normal
        index = 0;
        if (l->current + 1 < l->ntables) { //load dump table into memory again
            struct dirent **namelist;
            int n = scandir(".", &namelist, isDumpFile, sort_by_time);
            if (n <= 0) {                                                                                 
                redisLog(REDIS_WARNING, "No dumpfile need to load");
            }

            if (l->current + n < l->ntables) {                                                                                 
                for (index = 0; index < n; ++index) {
                    redisLog(REDIS_DEBUG, "Load dumpfile: %s", namelist[index]->d_name);
                    l->tables[index] = tableCreate(l->table_size, l->key_size,
                            l->value_size, l->sort);

                    int ret = loadTableData(namelist[index]->d_name, l->tables[index]->ht, 
                            l->table_size * (l->value_size + l->key_size));
                    if (ret < 0) {
                        redisLog(REDIS_WARNING, "load dump file Error");
                        goto lerr; 
                    }
                    table *t = l->tables[index];
                    l->tables[index]->l = l;
                    l->tables[index]->index = index;
                    fix_table_meta(t, l, index);
                }
                //while (n--)
                //    free(namelist[n]);
                //free(namelist);
            } else {
                redisLog(REDIS_WARNING, "table_num is not large enough, can't load dumpfile");
            }
        }
        for(i=start_table_num;i<=l->current;++i, ++index) {
            l->tables[index] = tableLoad(fp,gs); 
            if (!l->tables[index]) goto lerr;
            l->tables[index]->l = l;
            l->tables[index]->index = index;
        }
        fix_array_meta(l, index);
        l->size = l->table_size * l->ntables;
        l->gs = gs;
    }
    /* Update current */
    if (l->current >= l->ntables)
        l->current = l->ntables - 1;

    redisLog(REDIS_NOTICE,"load array succ offset %lld", ftell(fp));
    return l;
lerr:
    if(l) {
        arrayFree(l);
    }
    return NULL;
}

/* --------------------------- Test code --------------------------------- */
#ifdef ARRAY_TEST
long getScoreFromLong(void *key, int len) {
    return *(long*)key;
}

long getScoreFromInt(void *key, int len) {
    return *(int*)key;
}

long getScoreFromKey(char *key, int key_len) {
    unsigned long score;
    sscanf(key, "%ld", &score);
    return score;
}

void printLruStats(array *l) {
    int j;
    int max = l->sort ? l->current : (l->ntables-1);
    fprintf(stderr, "size: %ld, used: %ld, deleted: %ld\n",
        l->size, l->used, l->deleted);
    fprintf(stderr, "Max number of tables: %d, current table: %d\n",
        l->ntables, l->current);
    fprintf(stderr, "Table status:\n============================\n");
    for (j = 0; j <= max; ++j) {
        table *t = l->tables[j];
        fprintf(stderr, "Table %d: size - %ld, used - %ld, deleted - %ld, "
            "min - %ld, max - %ld\n",
            t->index, t->size, t->used, t->deleted, t->min, t->max);
    }
    fprintf(stderr, "\n\n");
}

void testAddReserved() {
    array *l;
    long i = 0;
    char buf[8];

    fprintf(stderr, "Testing add reserved EMPTY key: ");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_ERR_KEY_RESERVED);
    arrayFree(l);
    l = arrayCreate(100, 10, 8, 8, 0, NULL);
    memset(buf, 0, 8);
    assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_ERR_KEY_RESERVED);
    arrayFree(l);
    fprintf(stderr, "pass\n");
    
    fprintf(stderr, "Testing add reserved DELETED key: ");
    l = arrayCreate(100, 10, 8, 8, 0, NULL);
    memset(buf, 'F', 8);
    assert(arrayAdd(l, (void*)buf, 8, "abcd", 4) == REDIS_ERR_KEY_RESERVED);
    fprintf(stderr, "pass\n");
}

void testAdd() {
    array *l;
    long i;

    fprintf(stderr, "Testing ADD: ");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 50; ++i)
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testRotate() {
    array *l;
    long i;

    fprintf(stderr, "Testing Rotate: ");
    l = arrayCreate(1000, 10, 8, 8, 1, getScoreFromLong);
    arrayConfig conf = {90, 95, 800};
    arraySetConfig(l, conf);
    for (i = 1; i < 800; ++i)
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void assert_table_cmp(table* t1, table* t2)
{
    assert(t1->index == t2->index);
    assert(t1->sort == t2->sort);
    assert(t1->locked == t2->locked);
    assert(t1->min == t2->min);
    assert(t1->max == t2->max);
    assert(t1->size == t2->size);
    assert(t1->used == t2->used);
    assert(t1->deleted == t2->deleted);
    assert(t1->key_size == t2->key_size);
    assert(t1->value_size == t2->value_size);
    assert(t1->entry_size == t2->entry_size);
    assert(t1->entry_size == (t2->key_size + t1->value_size));
    
    assert(0 == memcmp(t1->ht, t2->ht, t1->size*(t1->key_size+t1->value_size)));
}

void assert_array_cmp(array* l1, array* l2)
{
    assert(l1->ntables == l2->ntables);
    assert(l1->current == l2->current);
    assert(l1->locked == l2->locked);
    assert(l1->sort == l2->sort);
    assert(l1->min == l2->min);
    assert(l1->max == l2->max);
    assert(l1->size == l2->size);
    assert(l1->used == l2->used);
    assert(l1->deleted == l2->deleted);
    assert(l1->rotate_threshold == l2->rotate_threshold);
    assert(l1->expand_threshold == l2->expand_threshold);
    assert(l1->table_size == l2->table_size);
    assert(l1->key_size == l2->key_size);
    assert(l1->value_size == l2->value_size);
    assert(l1->entry_size == l2->entry_size);
   
    int i=0;
    for(i=0;i<l1->current;i++)
    {
        assert_table_cmp(l1->tables[i], l2->tables[i]);
    }
}

array* testArraySaveLoad(array* l) 
{
    char* fn = "test_array.dump";
    FILE* fp=fopen(fn,"wb");
    arraySave(fp,l);
    fclose(fp);

    fp=fopen(fn,"rb");
    array* l2 = arrayLoad(fp,NULL,getScoreFromLong);
    fclose(fp);

    assert_array_cmp(l, l2);

    fprintf(stderr, " %s pass\n",__func__);
    return l2;
}


void testGet() {
    array *l;
    long i;

    fprintf(stderr, "Testing Get: ");
    l = arrayCreate(20000, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 10000; ++i) {
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void*)&i, 8, 0), "abcd", 4) == 0);
    }
    
    array* l2 = testArraySaveLoad(l);
    for (i = 1; i < 10000; ++i) {
        assert(memcmp(arrayGet(l2, (void*)&i, 8, 0), "abcd", 4) == 0);
    }
    arrayFree(l2);

    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testReplace() {
    array *l;
    long i;

    l = arrayCreate(20000, 10, 8, 8, 1, getScoreFromLong);

    fprintf(stderr, "Testing Replace with EMPTY key: ");
    i = 0;
    assert(arrayReplace(l, (void*)&i, 8, "abcd", 4) == REDIS_ERR_KEY_RESERVED);
    assert(arrayGet(l, (void*)&i, 8, 0) == NULL);
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing Replace with DELETED key: ");
    memset(&i, 'F', 8);
    assert(arrayReplace(l, (void*)&i, 8, "abcd", 4) == REDIS_ERR_KEY_RESERVED);
    assert(arrayGet(l, (void*)&i, 8, 0) == NULL);
    fprintf(stderr, "pass\n");

    fprintf(stderr, "Testing Replace: ");
    for (i = 1; i < 10000; ++i) {
        assert(arrayReplace(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void*)&i, 8, 0), "abcd", 4) == 0);
    }
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testReplaceAfterAdd() {
    array *l;
    long i;

    fprintf(stderr, "Testing Replace after Add: ");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 10; ++i) {
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(arrayReplace(l, (void*)&i, 8, "dcba", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void*)&i, 8, 0), "dcba", 4) == 0);
    }
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testDel() {
    array *l;
    long i;

    fprintf(stderr, "Testing Del: ");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 10000; ++i) {
        assert(arrayReplace(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(arrayDel(l, (void*)&i, 8) == REDIS_OK);
        assert(arrayDel(l, (void*)&i, 8) == REDIS_ERR);
        assert(arrayGet(l, (void*)&i, 8, 0) == NULL);
    }
    fprintf(stderr, "pass\n");
    //fprintf(stderr, "array status after Del:\n");
    //printLruStats(l);
    arrayFree(l);
}

void testEmpty() {
    array *l;
    long i;

    fprintf(stderr, "Testing Empty: ");
    l = arrayCreate(20000, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 10000; ++i) {
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
    }
    arrayEmpty(l);
    assert(arrayUsed(l) == 0);
    assert(arrayDeleted(l) == 0);
    assert(arrayCurrentTable(l) == 0);
    assert(arrayMin(l) == LONG_MAX);
    assert(arrayMax(l) == LONG_MIN);
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testKeyInt() {
    array *l;
    long i;

    fprintf(stderr, "Testing Int as key: ");
    l = arrayCreate(20000, 10, 4, 8, 1, getScoreFromInt);
    for (i = 1; i < 10000; ++i) {
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void*)&i, 8, 0), "abcd", 4) == 0);
    }
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testKeyLong() {
    array *l;
    long i;

    fprintf(stderr, "Testing Long as key: ");
    l = arrayCreate(12000, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 10000; ++i) {
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void*)&i, 8, 0), "abcd", 4) == 0);
    }
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testKeyString() {
    array *l;
    long i;
    char buf[12];

    fprintf(stderr, "Testing String as key: ");
    /* Note that when using un-sortable string as key, keys are stored in
     * N tables using 'crc32(key)%N'. So you need to have a little bit
     * big table otherwise it will be filled up and cause arrayAdd() to fail.
     * In real world, sys admin can manually expand a table when needed(shrink
     * is supported as well). */
    l = arrayCreate(1000, 10, 8, 8, 0, NULL);
    for (i = 1; i < 100; ++i) {
        snprintf(buf, 255, "key%ld", i);
        assert(arrayAdd(l, buf, strlen(buf), "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, buf, strlen(buf), 0), "abcd", 4) == 0);
    }
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testExpand() {
    array *l;
    long i;

    fprintf(stderr, "Testing Table Expansion: ");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    assert(arrayTableSize(l, 0) == 11);
    assert(arrayTableSize(l, 1) == 0);
    assert(arrayExpandTable(l, 0, 13) == REDIS_OK);
    assert(arrayTableSize(l, 0) == 13);
    assert(arrayExpandTable(l, 1, 13) == REDIS_ERR);
    arrayFree(l);
    fprintf(stderr, "pass\n");
}

void testSaveLoad() 
{
    array *l;
    long i;

    fprintf(stderr, "Testing %s: ",__func__);
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 50; ++i)
        assert(arrayAdd(l, (void*)&i, 8, "abcd", 4) == REDIS_OK);
    
    array *l2 = testArraySaveLoad(l);
    arrayFree(l2);

    fprintf(stderr, "%s pass\n", __func__);
}
    
int main(int argc, char **argv) {
    long end = 100;
    array *l;
    long i;
    char key[8];

    if (argc > 1)
        end = strtol(argv[1], NULL, 10);
    
    testSaveLoad();

    testAddReserved();
    testAdd();
    testRotate();
    testGet();
    testReplace();
    testReplaceAfterAdd();
    testDel();
    testEmpty();

    testKeyInt();
    testKeyLong();
    testKeyString();

    testExpand();

    /* Auto expansion is disabled by default. See expandTableIfNecessary(). */
    /*
    fprintf(stderr, "\n\n===================\nTesting table expansion\n");
    l = arrayCreate(100, 10, 8, 8, 1, getScoreFromLong);
    for (i = 1; i < 300; i+=4) {
        if (i % 100 == 0) {
            printLruStats(l);
        }
        assert(arrayAdd(l, (void *)&i, 8, "abcd", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void *)&i, 8, 0), "abcd", 4) == 0);
        assert(arrayReplace(l, (void *)&i, 8, "dcba", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void *)&i, 8, 0), "dcba", 4) == 0);
    }

    for (i = 1; i < 400; i+=1) {
        assert(arrayReplace(l, (void *)&i, 8, "dcba", 4) == REDIS_OK);
        assert(memcmp(arrayGet(l, (void *)&i, 8, 0), "dcba", 4) == 0);
    }
    arrayFree(l);
    */

    return 0;
}
#endif
