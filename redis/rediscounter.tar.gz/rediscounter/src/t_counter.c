#include "redis.h"

#include <signal.h>

/*-----------------------------------------------------------------------------
 * String Commands
 *----------------------------------------------------------------------------*/
/* TODO: remove setnx support? */
void set2GenericCommand(redisClient *c, int nx, robj *key, robj *val, robj *expire) {
    REDIS_NOTUSED(key);
    REDIS_NOTUSED(val);
    REDIS_NOTUSED(nx);
    REDIS_NOTUSED(expire);
    long long value;
    char *pkey;
    sds *argv;
    int argc, j, ret;
    long long lkey;

    UPDATE_WRITE_STAT(1);
    array *l = server->db2->db->base;
    l->stat.setCount++;
    if (getLongLongFromObjectOrReply(c,c->argv[2],&value,NULL) != REDIS_OK) {
        c->status = REDIS_ERR_GET_VALUE_FAILED;
        l->stat.errorCount++;
        return;
    }
    if (value < 0) {
        l->stat.errorCount++;
        addReplyError(c,"value is not an integer or out of range");
        c->status = REDIS_ERR_VALUE_UNDERFLOW;
        return;
    }

    /* TODO: no-schema support */
    pkey = c->argv[1]->ptr;
    argv = sdssplitlen(pkey, sdslen(pkey), ".", 1, &argc);
    if (argc != 2)
        goto invalid_key;
    if (string2ll(argv[0], sdslen(argv[0]), &lkey) == 0)
        goto invalid_key;

    if (GET_MAX_DIFF()) {
        long curr_max;
        if (arrayMax(l) != LONG_MIN) {
            curr_max = arrayMax(l);
        } else {
            /* table is empty */
            table *t = l->tables[l->current];
            curr_max = t->min - 1;
            /* fresh new instance don't check the first key */
            if (curr_max < 0)
                goto set;
        }
        if (lkey - GET_MAX_DIFF() > curr_max) {
            redisLog(REDIS_WARNING, "Too big key found: %ld, current max: %ld",
                lkey, curr_max);
            l->stat.errorCount++;
            addReplyError(c,"key too big");
            c->status = REDIS_ERR_KEY_TOO_BIG;
            for (j = 0; j < argc; ++j)
                sdsfree(argv[j]);
            zfree(argv);
            return;
        }
    }

set:
    ret = db2Set(server->db2, (void*)&lkey, 8, argv[1], value);
    for (j = 0; j < argc; ++j)
        sdsfree(argv[j]);
    zfree(argv);

    if(ret != REDIS_OK) {
        l->stat.errorCount++;
        switch (ret) {
            case REDIS_ERR_NO_SCHEMA :
                addReplyErrorFormat(c, "No schema");
                c->status = REDIS_ERR_NO_SCHEMA;
                return;
            case REDIS_ERR_VALUE_OVERFLOW :
                addReplyErrorFormat(c, "Value overflow");
                c->status = REDIS_ERR_VALUE_OVERFLOW;
                return;
            case REDIS_ERR_KEY_OUTOFRANGE :
                addReplyErrorFormat(c, "Key out of range");
                c->status = REDIS_ERR_KEY_OUTOFRANGE;
                return;              
            case REDIS_ERR_PERMISSION :
                addReplyErrorFormat(c, "Not enough permission for the column");
                c->status = REDIS_ERR_PERMISSION;
                return;            
            case REDIS_ERR_TABLE_FULL :
                addReplyErrorFormat(c, "Table full");
                c->status = REDIS_ERR_TABLE_FULL;
                return;
            default :
                addReplyErrorFormat(c, "Internal error");
                c->status = REDIS_ERR_DB2;
                return;
        }
    }

    server->dirty++;
    addReply(c, shared.ok);
    return;

invalid_key:
    if (argv) {
        for (j = 0; j < argc; ++j)
            sdsfree(argv[j]);
        zfree(argv);
    }
    l->stat.errorCount++;
    addReplyErrorFormat(c, "Invalid key");
    c->status = REDIS_ERR_INVALID_KEY;
    return;
}

void set2Command(redisClient *c) {
    set2GenericCommand(c,0,c->argv[1],c->argv[2],NULL);
}

int getAll(redisClient *c, void *key, int klen) {
    int ret;
    sds result;

    ret = db2GetAll(server->db2, key, klen, &result);
    if (ret == REDIS_OK) {
        addReplyBulkCBuffer(c, result, sdslen(result));
        sdsfree(result);
    } else {
        addReply(c, shared.nullbulk);
    }
    return ret;
}


int get2GenericCommand(redisClient *c) {
    char *pkey;
    int ret, j, argc;
    long long lkey, val;
    sds *argv;

    UPDATE_READ_STAT(1);
    array *l = server->db2->db->base;
    l->stat.getCount++;
    pkey = c->argv[1]->ptr;
    /* TODO: no-schema support */
    argv = sdssplitlen(pkey, sdslen(pkey), ".", 1, &argc);
    if (argc == 1) {
        if (string2ll(argv[0], sdslen(argv[0]), &lkey) == 0)
            goto err;

        ret = getAll(c, (void*)&lkey, 8);
        for (j = 0; j < argc; ++j)
            sdsfree(argv[j]);
        zfree(argv);
        return (ret == REDIS_OK) ? REDIS_OK : REDIS_ERR;
    }

    if (argc != 2)
        goto err;

    if (string2ll(argv[0], sdslen(argv[0]), &lkey) == 0)
        goto err;

    ret = db2Get(server->db2, (void*)&lkey, 8, argv[1], &val, 0);
    if (ret == REDIS_OK)
        addReplyBulkLongLong(c, val);
    else if (ret == REDIS_ERR_PERMISSION) {
        l->stat.missCount++;
        addReply(c, shared.nullbulk);
    } else {
        //l->stat.missCount++;
        addReply(c, shared.nullbulk);
    }

    for (j = 0; j < argc; ++j)
        sdsfree(argv[j]);
    zfree(argv);
    return (ret == REDIS_OK) ? REDIS_OK : REDIS_ERR;

err:
    if (argv) {
        for (j = 0; j < argc; ++j)
            sdsfree(argv[j]);
        zfree(argv);
    }
    l->stat.missCount++;
    addReply(c, shared.nullbulk);
    return REDIS_ERR;
}

void get2Command(redisClient *c) {
    get2GenericCommand(c);
}

void incrDecr2Command(redisClient *c, long long incr) {
    long long value, oldvalue = 0;
    int ret, j, argc;
    sds *argv;
    char *pkey;
    long long lkey;

    UPDATE_WRITE_STAT(1);
    array *l = server->db2->db->base;
    l->stat.setCount++;
    pkey = c->argv[1]->ptr;
    /* TODO: no-schema support */
    argv = sdssplitlen(pkey, sdslen(pkey), ".", 1, &argc);
    if (argc != 2)
        goto err;

    if (string2ll(argv[0], sdslen(argv[0]), &lkey) == 0)
        goto err;

    if (GET_MAX_DIFF()) {
        long curr_max;
        if (arrayMax(l) != LONG_MIN) {
            curr_max = arrayMax(l);
        } else {
            /* table is empty */
            table *t = l->tables[l->current];
            curr_max = t->min - 1;
            /* fresh new instance don't check the first key */
            if (curr_max < 0)
                goto get;
        }
        if (lkey - GET_MAX_DIFF() > curr_max) {
            redisLog(REDIS_WARNING, "Too big key found: %ld, current max: %ld",
                lkey, curr_max);
            l->stat.errorCount++;
            addReplyError(c,"key too big");
            c->status = REDIS_ERR_KEY_TOO_BIG;
            for (j = 0; j < argc; ++j)
                sdsfree(argv[j]);
            zfree(argv);
            return;
        }
    }

get:
    ret = db2Get(server->db2, (void*)&lkey, 8, argv[1], &oldvalue, 1);
    if (ret != REDIS_OK && ret != REDIS_ERR_NOT_FOUND) {
        l->stat.errorCount++;
        if (argv) {
            for (j = 0; j < argc; ++j)
                sdsfree(argv[j]);
            zfree(argv);
        }
        switch (ret) {
            case REDIS_ERR_PERMISSION :
                addReplyErrorFormat(c, "Not enough permission for the column");
                c->status = REDIS_ERR_PERMISSION;
                return;
            case REDIS_ERR_NO_SCHEMA :
                addReplyErrorFormat(c, "No schema");
                c->status = REDIS_ERR_NO_SCHEMA;
                return;
            case REDIS_ERR_KEY_OUTOFRANGE :
                addReplyErrorFormat(c, "Key out of range");
                c->status = REDIS_ERR_KEY_OUTOFRANGE;
                return;
            case REDIS_ERR_TABLE_FULL :
                addReplyErrorFormat(c, "Table full");
                c->status = REDIS_ERR_TABLE_FULL;
                return;
            default :
                addReplyErrorFormat(c, "Internal error");
                c->status = REDIS_ERR_DB2;
                return;
        }
    }

    if (ret == REDIS_ERR_NOT_FOUND)
        oldvalue = 0;

    if ((incr < 0 && (incr+oldvalue) < 0) ||
        (incr > 0 && incr > (LLONG_MAX-oldvalue)))
    {
        l->stat.errorCount++;
        addReplyError(c,"value is not an integer or out of range");
        c->status = REDIS_ERR_VALUE_OVERFLOW;
        return;
    }

    value = oldvalue + incr;
    ret = db2Set(server->db2, (void*)&lkey, 8, argv[1], value);
    if (argv) {
        for (j = 0; j < argc; ++j)
            sdsfree(argv[j]);
        zfree(argv);
    }
    if(ret != REDIS_OK) {
        l->stat.errorCount++;
        switch (ret) {
            case REDIS_ERR_NO_SCHEMA :
                addReplyErrorFormat(c, "No schema");
                c->status = REDIS_ERR_NO_SCHEMA;
                return;
            case REDIS_ERR_VALUE_OVERFLOW :
                addReplyErrorFormat(c, "Value overflow");
                c->status = REDIS_ERR_VALUE_OVERFLOW;
                return;
            case REDIS_ERR_PERMISSION :
                addReplyErrorFormat(c, "Not enough permission for the column");
                c->status = REDIS_ERR_PERMISSION;
                return;              
            case REDIS_ERR_KEY_OUTOFRANGE :
                addReplyErrorFormat(c, "Key out of range");
                c->status = REDIS_ERR_KEY_OUTOFRANGE;
                return;              
            case REDIS_ERR_TABLE_FULL :
                addReplyErrorFormat(c, "Table full");
                c->status = REDIS_ERR_TABLE_FULL;
                return;
            default :
                addReplyErrorFormat(c, "Internal error");
                c->status = REDIS_ERR_DB2;
                return;
        }
    }

    server->dirty++;
    addReplyLongLong(c,value);
    return;

err:
    if (argv) {
        for (j = 0; j < argc; ++j)
            sdsfree(argv[j]);
        zfree(argv);
    }
    l->stat.errorCount++;
    addReplyErrorFormat(c, "Invalid key");
    c->status = REDIS_ERR_INVALID_KEY;
    return;
}

void incr2Command(redisClient *c) {
    incrDecr2Command(c,1);
}

void decr2Command(redisClient *c) {
    incrDecr2Command(c,-1);
}

void incrby2Command(redisClient *c) {
    long long incr;

    if (getLongLongFromObjectOrReply(c, c->argv[2], &incr, NULL) != REDIS_OK) return;
    incrDecr2Command(c,incr);
}

void decrby2Command(redisClient *c) {
    long long incr;

    if (getLongLongFromObjectOrReply(c, c->argv[2], &incr, NULL) != REDIS_OK) return;
    if (incr == LLONG_MIN) {
        /* Passing '-incr' to incrDecr2Command leads to LLONG_MIN, which is not
         * the real value. Since array can only save non-negative values, decrby
         * with LLONG_MIN will always overflow. */
        addReplyError(c,"value is not an integer or out of range");
        return;
    }
    incrDecr2Command(c,-incr);
}

void del2Command(redisClient *c) {
    int deleted = 0, i, j, argc, ret;
    sds *argv;
    char *pkey;
    long long lkey;

    UPDATE_WRITE_STAT(c->argc-1);
    array *l = server->db2->db->base;
    l->stat.setCount += c->argc-1;
    for (j = 1; j < c->argc; j++) {
        pkey = c->argv[j]->ptr;
        /* DEL without suffix will remove all columns */
        if (string2ll(pkey, sdslen(pkey), &lkey) == 1) {
            ret = db2Delete(server->db2, (void*)&lkey, 8);
            if(ret == REDIS_OK) {
                server->dirty++;
                deleted++;  
            } else if(ret == REDIS_ERR_PERMISSION) {
                l->stat.errorCount++;
                addReplyErrorFormat(c, "Not enough permission for the column");
                return;                    
            }

            continue;
        }

        argv = sdssplitlen(pkey, sdslen(pkey), ".", 1, &argc);
        if (argc != 2 || string2ll(argv[0], sdslen(argv[0]), &lkey) == 0) {
            if (argv) {
                for (i = 0; i < argc; ++i)
                    sdsfree(argv[i]);
                zfree(argv);
            }
            continue;
        }
        ret = db2DeleteColumn(server->db2,(void*)&lkey, 8, argv[1]);
        if (argv) {
            for (i = 0; i < argc; ++i)
                sdsfree(argv[i]);
            zfree(argv);
        }

        if(ret == REDIS_OK) {
            server->dirty++;
            deleted++;  
        } else if(ret == REDIS_ERR_PERMISSION) {
            l->stat.errorCount++;
            addReplyErrorFormat(c, "Not enough permission for the column");
            return;                 
        } else if(ret == REDIS_ERR_NO_SCHEMA) {
            l->stat.errorCount++;
        }
    }
    addReplyLongLong(c,deleted);
}

void mget2Command(redisClient *c) {
    int i, j, ret, argc;
    long long lkey, val;
    sds *argv;
    char *pkey;

    UPDATE_READ_STAT(c->argc-1);
    array *l = server->db2->db->base;
    l->stat.getCount += c->argc-1;
    addReplyMultiBulkLen(c,c->argc-1);
    for (j = 1; j < c->argc; j++) {
        pkey = c->argv[j]->ptr;
        argv = sdssplitlen(pkey, sdslen(pkey), ".", 1, &argc);
        if ((string2ll(argv[0], sdslen(argv[0]), &lkey) == 0) ||
            (argc != 1 && argc != 2))
        {
            if (argv) {
                for (i = 0; i < argc; ++i)
                    sdsfree(argv[i]);
                zfree(argv);
            }
            l->stat.missCount++;
            addReply(c, shared.nullbulk);
            continue;
        }

        if (argc == 1) {
            getAll(c, (void*)&lkey, 8);
            if (argv) {
                for (i = 0; i < argc; ++i)
                    sdsfree(argv[i]);
                zfree(argv);
            }
            continue;
        }

        ret = db2Get(server->db2, (void*)&lkey, 8, argv[1], &val, 0);
        if (ret == REDIS_OK)
            addReplyBulkLongLong(c, val);
        else
            addReply(c,shared.nullbulk);
        if (argv) {
            for (i = 0; i < argc; ++i)
                sdsfree(argv[i]);
            zfree(argv);
        }
    }
}

void flushall2Command(redisClient *c) {
    logQuery(c);
    server->dirty += emptyDb2();
    addReply(c,shared.ok);
    if (server->bgsavechildpid != -1) {
        kill(server->bgsavechildpid,SIGKILL);
        rdbRemoveTempFile(server->bgsavechildpid);
    }
    server->dirty++;
}

void dbsize2Command(redisClient *c) {
    addReplyLongLong(c,CDB_USED(server->db2->db)+dictSize(server->db2->aux));
}

void randomkey2Command(redisClient *c) {
    robj *key = db2RandomKey(server->db2);

    if (key == NULL) {
        addReply(c,shared.nullbulk);
        return;
    }

    addReplyBulk(c,key);
    decrRefCount(key);
}

void logQuery(redisClient *c) {
    char ip[32], buf[255];
    sds result = sdsempty();
    int j, port;

    /* No logging during AOF loading */
    if (c->fd == -1) {
        sdsfree(result);
        return;
    }

    if (anetPeerToString(c->fd,ip,&port) == -1) {
        ip[0] = '?'; 
        ip[1] = '\0';
        port = 0; 
    }

    for (j = 0; j < c->argc; ++j) {
        snprintf(buf, 255, "%s", (char*)c->argv[j]->ptr);
        result = sdscatprintf(result, "%s ", buf);
    }

    redisLog(REDIS_WARNING, "Client %s:%d send '%s'", ip, port, result);
    sdsfree(result);
}

#if 0
void msetGenericCommand(redisClient *c, int nx) {
    int j, busykeys = 0;

    if ((c->argc % 2) == 0) {
        addReplyError(c,"wrong number of arguments for MSET");
        return;
    }
    UPDATE_WRITE_STAT(c->argc/2);
    /* Handle the NX flag. The MSETNX semantic is to return zero and don't
     * set nothing at all if at least one already key exists. */
    if (nx) {
        for (j = 1; j < c->argc; j += 2) {
            if (lookupKeyWrite(c->db,c->argv[j]) != NULL) {
                busykeys++;
            }
        }
        if (busykeys) {
            addReply(c, shared.czero);
            return;
        }
    }

    for (j = 1; j < c->argc; j += 2) {
        c->argv[j+1] = tryObjectEncoding(c->argv[j+1]);
        setKey(c->db,c->argv[j],c->argv[j+1]);
    }
    server->dirty += (c->argc-1)/2;
    addReply(c, nx ? shared.cone : shared.ok);
}

void msetCommand(redisClient *c) {
    msetGenericCommand(c,0);
}

void msetnxCommand(redisClient *c) {
    msetGenericCommand(c,1);
}

#endif

#if 0
void getsetCommand(redisClient *c) {
    if (getGenericCommand(c) == REDIS_ERR) return;
    c->argv[2] = tryObjectEncoding(c->argv[2]);
    setKey(c->db,c->argv[1],c->argv[2]);
    server->dirty++;
    UPDATE_WRITE_STAT(1);
}

static int getBitOffsetFromArgument(redisClient *c, robj *o, size_t *offset) {
    long long loffset;
    char *err = "bit offset is not an integer or out of range";

    if (getLongLongFromObjectOrReply(c,o,&loffset,err) != REDIS_OK)
        return REDIS_ERR;

    /* Limit offset to 512MB in bytes */
    if ((loffset < 0) || ((unsigned long long)loffset >> 3) >= (512*1024*1024))
    {
        addReplyError(c,err);
        return REDIS_ERR;
    }

    *offset = (size_t)loffset;
    return REDIS_OK;
}

void setbitCommand(redisClient *c) {
    robj *o;
    char *err = "bit is not an integer or out of range";
    size_t bitoffset;
    int byte, bit;
    int byteval, bitval;
    long on;

    UPDATE_WRITE_STAT(1);
    if (getBitOffsetFromArgument(c,c->argv[2],&bitoffset) != REDIS_OK)
        return;

    if (getLongFromObjectOrReply(c,c->argv[3],&on,err) != REDIS_OK)
        return;

    /* Bits can only be set or cleared... */
    if (on & ~1) {
        addReplyError(c,err);
        return;
    }

    o = lookupKeyWrite(c->db,c->argv[1]);
    if (o == NULL) {
        o = createObject(REDIS_STRING,sdsempty());
        dbAdd(c->db,c->argv[1],o);
    } else {
        if (checkType(c,o,REDIS_STRING)) return;

        /* Create a copy when the object is shared or encoded. */
        if (o->refcount != 1 || o->encoding != REDIS_ENCODING_RAW) {
            robj *decoded = getDecodedObject(o);
            o = createStringObject(decoded->ptr, sdslen(decoded->ptr));
            decrRefCount(decoded);
            dbOverwrite(c->db,c->argv[1],o);
        }
    }

    /* Grow sds value to the right length if necessary */
    byte = bitoffset >> 3;
    o->ptr = sdsgrowzero(o->ptr,byte+1);

    /* Get current values */
    byteval = ((char*)o->ptr)[byte];
    bit = 7 - (bitoffset & 0x7);
    bitval = byteval & (1 << bit);

    /* Update byte with new bit value and return original value */
    byteval &= ~(1 << bit);
    byteval |= ((on & 0x1) << bit);
    ((char*)o->ptr)[byte] = byteval;
    signalModifiedKey(c->db,c->argv[1]);
    server->dirty++;
    addReply(c, bitval ? shared.cone : shared.czero);
}

void getbitCommand(redisClient *c) {
    robj *o;
    char llbuf[32];
    size_t bitoffset;
    size_t byte, bit;
    size_t bitval = 0;

    UPDATE_READ_STAT(1);
    if (getBitOffsetFromArgument(c,c->argv[2],&bitoffset) != REDIS_OK)
        return;

    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.czero)) == NULL ||
        checkType(c,o,REDIS_STRING)) return;

    byte = bitoffset >> 3;
    bit = 7 - (bitoffset & 0x7);
    if (o->encoding != REDIS_ENCODING_RAW) {
        if (byte < (size_t)ll2string(llbuf,sizeof(llbuf),(long)o->ptr))
            bitval = llbuf[byte] & (1 << bit);
    } else {
        if (byte < sdslen(o->ptr))
            bitval = ((char*)o->ptr)[byte] & (1 << bit);
    }

    addReply(c, bitval ? shared.cone : shared.czero);
}

void setrangeCommand(redisClient *c) {
    robj *o;
    long offset;
    sds value = c->argv[3]->ptr;

    UPDATE_WRITE_STAT(1);
    if (getLongFromObjectOrReply(c,c->argv[2],&offset,NULL) != REDIS_OK)
        return;

    if (offset < 0) {
        addReplyError(c,"offset is out of range");
        return;
    }

    o = lookupKeyWrite(c->db,c->argv[1]);
    if (o == NULL) {
        /* Return 0 when setting nothing on a non-existing string */
        if (sdslen(value) == 0) {
            addReply(c,shared.czero);
            return;
        }

        /* Return when the resulting string exceeds allowed size */
        if (checkStringLength(c,offset+sdslen(value)) != REDIS_OK)
            return;

        o = createObject(REDIS_STRING,sdsempty());
        dbAdd(c->db,c->argv[1],o);
    } else {
        size_t olen;

        /* Key exists, check type */
        if (checkType(c,o,REDIS_STRING))
            return;

        /* Return existing string length when setting nothing */
        olen = stringObjectLen(o);
        if (sdslen(value) == 0) {
            addReplyLongLong(c,olen);
            return;
        }

        /* Return when the resulting string exceeds allowed size */
        if (checkStringLength(c,offset+sdslen(value)) != REDIS_OK)
            return;

        /* Create a copy when the object is shared or encoded. */
        if (o->refcount != 1 || o->encoding != REDIS_ENCODING_RAW) {
            robj *decoded = getDecodedObject(o);
            o = createStringObject(decoded->ptr, sdslen(decoded->ptr));
            decrRefCount(decoded);
            dbOverwrite(c->db,c->argv[1],o);
        }
    }

    if (sdslen(value) > 0) {
        o->ptr = sdsgrowzero(o->ptr,offset+sdslen(value));
        memcpy((char*)o->ptr+offset,value,sdslen(value));
        signalModifiedKey(c->db,c->argv[1]);
        server->dirty++;
    }
    addReplyLongLong(c,sdslen(o->ptr));
}

void getrangeCommand(redisClient *c) {
    robj *o;
    long start, end;
    char *str, llbuf[32];
    size_t strlen;

    UPDATE_READ_STAT(1);
    if (getLongFromObjectOrReply(c,c->argv[2],&start,NULL) != REDIS_OK)
        return;
    if (getLongFromObjectOrReply(c,c->argv[3],&end,NULL) != REDIS_OK)
        return;
    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.emptybulk)) == NULL ||
        checkType(c,o,REDIS_STRING)) return;

    if (o->encoding == REDIS_ENCODING_INT) {
        str = llbuf;
        strlen = ll2string(llbuf,sizeof(llbuf),(long)o->ptr);
    } else {
        str = o->ptr;
        strlen = sdslen(str);
    }

    /* Convert negative indexes */
    if (start < 0) start = strlen+start;
    if (end < 0) end = strlen+end;
    if (start < 0) start = 0;
    if (end < 0) end = 0;
    if ((unsigned)end >= strlen) end = strlen-1;

    /* Precondition: end >= 0 && end < strlen, so the only condition where
     * nothing can be returned is: start > end. */
    if (start > end) {
        addReply(c,shared.emptybulk);
    } else {
        addReplyBulkCBuffer(c,(char*)str+start,end-start+1);
    }
}

void appendCommand(redisClient *c) {
    size_t totlen;
    robj *o, *append;

    UPDATE_WRITE_STAT(1);
    o = lookupKeyWrite(c->db,c->argv[1]);
    if (o == NULL) {
        /* Create the key */
        c->argv[2] = tryObjectEncoding(c->argv[2]);
        dbAdd(c->db,c->argv[1],c->argv[2]);
        incrRefCount(c->argv[2]);
        totlen = stringObjectLen(c->argv[2]);
    } else {
        /* Key exists, check type */
        if (checkType(c,o,REDIS_STRING))
            return;

        /* "append" is an argument, so always an sds */
        append = c->argv[2];
        totlen = stringObjectLen(o)+sdslen(append->ptr);
        if (checkStringLength(c,totlen) != REDIS_OK)
            return;

        /* If the object is shared or encoded, we have to make a copy */
        if (o->refcount != 1 || o->encoding != REDIS_ENCODING_RAW) {
            robj *decoded = getDecodedObject(o);
            o = createStringObject(decoded->ptr, sdslen(decoded->ptr));
            decrRefCount(decoded);
            dbOverwrite(c->db,c->argv[1],o);
        }

        /* Append the value */
        o->ptr = sdscatlen(o->ptr,append->ptr,sdslen(append->ptr));
        totlen = sdslen(o->ptr);
    }
    signalModifiedKey(c->db,c->argv[1]);
    server->dirty++;
    addReplyLongLong(c,totlen);
}

void strlenCommand(redisClient *c) {
    robj *o;
    UPDATE_READ_STAT(1);
    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.czero)) == NULL ||
        checkType(c,o,REDIS_STRING)) return;
    addReplyLongLong(c,stringObjectLen(o));
}
#endif
