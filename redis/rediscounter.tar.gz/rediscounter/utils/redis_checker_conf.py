# time to sleep before checking next key(in seconds)
interval = 0.001

# server list
servers1 = [
	'rm7902.eos.grid.sina.com.cn:7902',
	'rm7904.eos.grid.sina.com.cn:7904',
	'rm7906.eos.grid.sina.com.cn:7906',
	'rm7908.eos.grid.sina.com.cn:7908',
	'rm7910.eos.grid.sina.com.cn:7910',
	'rm7912.eos.grid.sina.com.cn:7912',
	'rm7914.eos.grid.sina.com.cn:7914',
	'rm7916.eos.grid.sina.com.cn:7916',
]
servers2 = [
	'rm8010.eos.grid.sina.com.cn:8010',
	'rm8012.eos.grid.sina.com.cn:8011',
	'rm8012.eos.grid.sina.com.cn:8012',
	'rm8013.eos.grid.sina.com.cn:8013',
	'rm8014.eos.grid.sina.com.cn:8014',
	'rm8015.eos.grid.sina.com.cn:8015',
	'rm8016.eos.grid.sina.com.cn:8016',
	'rm8017.eos.grid.sina.com.cn:8017',
]


