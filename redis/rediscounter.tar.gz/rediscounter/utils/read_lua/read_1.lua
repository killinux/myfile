local server_num = 5
local relax = 1
local reply = {}
local random = tonumber(redis.call('random'))
for j = 1, #KEYS do
    local value = tonumber(redis.call('get', KEYS[j]))
    if value == nil or value < 1 then
    	value = 0
    end
    
    if value > 20000 then 
        relax = relax+7
    elseif value > 1000 then 
        relax = relax+3
    elseif value > 25 then 
        relax = relax+1
    end
     
    local r1 = random % relax
    if r1 ~= 0 then
        reply[j] = value + 1
    else
        local incrby = server_num * relax
        if relax > 2 then
            if value < 100 then 
                incrby = incrby * 1.25 + 1
            elseif value < 100000 then
                incrby = incrby * (1.5 - math.log10(value)/10) + 1
            else 
                incrby = incrby * 1.1 + 1
            end
        else 
            if 1 == random % 10  then
                incrby = incrby + 1 
            end
        end
        reply[j] = value + math.ceil(incrby)
        redis.call('set', KEYS[j], reply[j])
    end
end
return reply
