#!/usr/bin/env python

# Check the consistency of redis servers

import redis
import sys
import os
import random
import time
import binascii

# server list
servers1 = [
        'rm7902.eos.grid.sina.com.cn:7902',
        'rm7904.eos.grid.sina.com.cn:7904',
        'rm7906.eos.grid.sina.com.cn:7906',
        'rm7908.eos.grid.sina.com.cn:7908',
        'rm7910.eos.grid.sina.com.cn:7910',
        'rm7912.eos.grid.sina.com.cn:7912',
        'rm7914.eos.grid.sina.com.cn:7914',
        'rm7916.eos.grid.sina.com.cn:7916',
]
servers2 = [
        'rm8010.eos.grid.sina.com.cn:8010',
        'rm8012.eos.grid.sina.com.cn:8011',
        'rm8012.eos.grid.sina.com.cn:8012',
        'rm8013.eos.grid.sina.com.cn:8013',
        'rm8014.eos.grid.sina.com.cn:8014',
        'rm8015.eos.grid.sina.com.cn:8015',
        'rm8016.eos.grid.sina.com.cn:8016',
        'rm8017.eos.grid.sina.com.cn:8017',
]

interval = 0.01
connections_rs = []
connections_cs = []
match_count = 0
mismatch_set = set()

def connect_all(servers) :
    connections = []
    for server in servers :
        tmp = server.partition(':')
        ip = tmp[0]
        port = int(tmp[2])
        r = redis.Redis(ip, port, 0)
        r.ping()
        connections.append(r)
    return connections

def getkeytime(key) :
	if key:
		mid=key[:-6]
		t = (int(mid)>>22)+515483463
		#print "time",t
		return t
	else:
		#print "time2",1033238400
		return 1033238400

def randomkey() :
    shard_index = random.randint(0, 7)
    r = connections_rs[shard_index]
    key = r.randomkey() 
    t = getkeytime(key)
    while not key or key[0]!='3' or (len(key)<16) or (t < 1333238400):
        key = r.randomkey()
    	t = getkeytime(key)
    return r,key

def get_rs_value(r, key) :
    mid = key
    repost = r.get(mid+".cntsr")
    comment = r.get(mid+".cntsc")
    if not repost or int(repost) < 0:
        repost = '0'
    if not comment or int(comment) < 0:
        comment = '0'
    return "repost:%s,comment:%s" % (repost, comment)

def get_cs_value(key) :
    mid = key
    shardindex =  ((binascii.crc32(mid) & 0xFFFFFFFF) / 256 % 256) / 32 
    r = connections_cs[shardindex]
    ret = r.get(mid)
    if not ret:
        ret = "repost:0,comment:0"
    ret2 = ret.split(',')
    return ','.join(ret2[0:2])

def uuid2time(key) :
    key = (int(key)>>22)+515483463
    t= time.localtime(key)
    return time.strftime("%Y%m%d", t)

def check() :
    global match_count
    r,key = randomkey()
    key,col = key.split('.')
    rs_value = get_rs_value(r,key)
    cs_value = get_cs_value(key)

    if cs_value != rs_value > 0 :
        mismatch_set.add(key)
        t = uuid2time(key)
        shardindex =  ((binascii.crc32(key) & 0xFFFFFFFF) / 256 % 256) / 32 
        print "match:%ld mismatch:%ld[time:%s, %d][key:%s][rs:%s][cs:%s][index:%d]" %  \
             (match_count, len(mismatch_set), t, (int(key)>>22) + 515483463, key, rs_value, cs_value, shardindex)
        sys.stdout.flush()
    else:
        match_count += 1

def main() :
    global connections_rs
    global connections_cs
    connections_rs = connect_all(servers1)
    connections_cs = connect_all(servers2)
    if len(sys.argv) > 1:
        print get_cs_value(sys.argv[1])
        quit()
    while 1 :
        time.sleep(interval)

        if match_count % 1000 == 0 :
            print "%ld keys match, %ld mismatch" % (match_count, len(mismatch_set))
        
        check()

if __name__ == '__main__' :
    main()
