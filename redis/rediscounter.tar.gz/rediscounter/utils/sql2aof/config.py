#coding:utf8
HOSTIDX=0
PORTIDX=1
servers=[
	["s4951i.eos.grid.sina.com.cn",4951],
	["s4952i.eos.grid.sina.com.cn",4952],
	["s4953i.eos.grid.sina.com.cn",4953],
	["s4954i.eos.grid.sina.com.cn",4954],
	["s4955i.eos.grid.sina.com.cn",4955],
	["s4956i.eos.grid.sina.com.cn",4956],
	["s4957i.eos.grid.sina.com.cn",4957],
	["s4958i.eos.grid.sina.com.cn",4958]
		]
postfix='comment'
POSTFLAG=0
if __name__ ==  '__main__':
	for server in servers:
		print server[HOSTIDX],server[PORTIDX]
