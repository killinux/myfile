#coding:utf8

import MySQLdb,sys
import sql2aof,config
if __name__ == '__main__':
	db = sql2aof.DbProxy(config.servers)
	for line in sys.stdin:
		lst = line.split()
		if not len(lst):continue
		mid = lst[0]
		idx = sql2aof.hashmidMySQL(mid)
		result = db.query(map(int,idx),[mid])
		if len(result):
			print result,idx,line.strip()
