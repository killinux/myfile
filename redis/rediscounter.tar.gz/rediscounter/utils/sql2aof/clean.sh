#!/bin/bash
rm [0-9][0-9] -rvf
rm aof.err -rvf
