#coding:utf8

import sys,os
import MySQLdb
import time
from binascii import crc32
from config import *
bufferlen=8192
dirsnum = 8
filesperdir=20000
MIN_ID=3000000000000000
MAX_ID=4500000000000000

class Parser:
	def __init__(self,fname):
		self.buf=''
		self.stack=[]
		self.fin = open(fname)
	def parse(self):
		start=end=mid=last=-1
		while True:
			line = self.fin.read(bufferlen)
			if not line:
				raise StopIteration()
			self.buf +=line
			cnts={}
			#print self.buf
			#print '****',self.stack
			for i in xrange(len(self.buf)):
				if self.buf[i] == '(':
					self.stack.append('(')
					start = i
				elif self.buf[i]==',':
					if len(self.stack)==1:
						mid = i
				elif self.buf[i]==')':
					assert(self.stack.pop()=='(')
					end = i
				last = max(start,end)
				if end > mid > start and end!=0 and len(self.stack)==0:
					# start can be zero when read to next buffer
					#
					key = self.buf[start+1:mid]
					val = self.buf[mid+1:end]
					if key and val and key.isdigit() and val.isdigit:
						cnts[key] = val
					start = end = mid = -1 
			#print start,end
			if start != -1 and end < start:
				self.buf = self.buf[last:]
				self.stack.pop()
			else:
				self.buf = ''
			start = end = mid = -1 
			yield cnts
def hashmidRedis(key):
	didx = (((crc32(key)&0xFFFFFFFF)/256)%256)/(256/dirsnum)
	fidx = (long(key)-MIN_ID)/((MAX_ID-MIN_ID+1)/filesperdir)
	return didx,fidx

def hashmidMySQL(key):
	idx = ((crc32(key)&0xFFFFFFFF)/256)%256
	portidx = idx/32
	dbidx = idx/8
	tblidx = idx % 8
	return map(str,(portidx,dbidx,tblidx))

class DbProxy:
	def __init__(self,servers):
		self.dbs=[]
		for s in servers:
			host = s[HOSTIDX]
			port = int(s[PORTIDX])
			db = MySQLdb.connect(host=host,port=port,user='openapi',passwd='im1400uc')
			self.dbs.append(db)

		self.sql='SELECT mid,id FROM %s WHERE mid IN(%s)'

	def query(self,idx,mids):
		if not len(mids):
			return {}
		table = "status_si_%d.mid_id_%d"%(idx[1],idx[2])
		sql = self.sql%(table,','.join(mids))
		res={}
		cur = self.dbs[idx[0]].cursor()
		cur.execute(sql)
		for row in cur:
			res[str(row[0])]=str(row[1])
		return res

class DbBuffer:
	def __init__(self,ntables):
		self.db = DbProxy(servers)
		self.sqlbuf={}
	
	def addmid(self,mid):
		key = '.'.join(hashmidMySQL(mid))

		val = self.sqlbuf.setdefault(key,[])
		val.append(mid)
	
	def refresh(self):
		for k,v in self.sqlbuf.items():
			idx = [int(i) for i in k.split('.')]
			assert len(idx)==3
			yield self.db.query(idx,v)
                self.sqlbuf={}

class Aof:
	def __init__(self,parser):
		self.parser = parser
		self.reset()
		self.mkdirs()
		self.db = DbBuffer(256)
		self.errlog = open("aof.err","a")
	
	def mkdirs(self):
		for i in xrange(dirsnum):
			path = '%02d'%i
			if not os.path.exists(path):
				os.mkdir(path)
	
	def reset(self):
		self.buffer=[]
		for i in xrange(dirsnum):
			lst=[]
			for j in xrange(filesperdir):
				lst.append([])
			self.buffer.append(lst)

	def toaof(self,key,val):
		didx,fidx = hashmidRedis(key)
		key = "%s.%s"%(key,postfix)
		lines="*3\r\n$3\r\nset\r\n$%d\r\n%s\r\n$%d\r\n%s\r\n"%(len(key),key,len(val),val)
		#print didx,fidx,key
		(self.buffer[didx][fidx]).append(lines)
	
	def save(self):
		for didx,dirs in enumerate(self.buffer):
			path = '%02d'%didx
			for fidx,files in enumerate(dirs):
				fname = 'aof.1%07d%d'%(fidx,POSTFLAG)
				if len(files)==0:
					continue
				#print path,fname,files
				#with open("%s/%s"%(path,fname),"a") as fout:
				fout = open("%s/%s"%(path,fname),"a")
				try:
					fout.writelines(files)
				finally:
					fout.close()
				dirs[fidx]=[]
	def mapandtoaof(self,ids):
		for newmids in self.db.refresh():
			for key,val in newmids.items():
				ids[val] = ids[key]
				del ids[key]
		nwrites = 0
		for k,v  in ids.items():
			if not ((MIN_ID<=long(k)<= MAX_ID) and (1<=int(v)<=2147483647)):
				#TODO write to invaliad aof?
				self.errlog.write("%s %s\n"%(k,v))
				continue
			self.toaof(k,v)
			nwrites +=1
		return nwrites

	def transfer(self):
		total = 0
		nwrites = 0
		nold = 0
		sql = 'SELECT * FROM ...'

		ids={}
		idmap={}
		t1 = time.time()
		for cnts in self.parser.parse():
			for k,v in cnts.items():
				total += 1
				if long(k)<3342818919841793 or long(k)>MAX_ID:
					self.db.addmid(k)
					nold += 1
				ids[k] = v

				if total % 50000==0:
					nwrites += self.mapandtoaof(ids)
					self.save()
					ids={}
					t2 = time.time()
					print 'total:%d writes:%d old:%s time:%f'%(total,nwrites,nold,t2-t1)
		t2 = time.time()
		nwrites += self.mapandtoaof(ids)
		self.save()
		ids={}
		print 'total:%d writes:%d old:%s time:%f'%(total,nwrites,nold,t2-t1)
			
if __name__== '__main__':
	if(len(sys.argv)<2):
		print '%s <file>'%(sys.argv[0])
		sys.exit(1)
	fname=sys.argv[1]
	parser = Parser(fname)
	aof = Aof(parser)
	aof.transfer()

