#!/usr/bin/env python

# Check the consistency of redis servers

import redis
import sys
import os
import time
from redis_checker_conf import *

connections = []
mismatch_set = set()

def connect_all() :
	for server in servers :
		tmp = server.partition(':')
		ip = tmp[0]
		port = int(tmp[2])
		r = redis.Redis(ip, port, 0)
		r.ping()
		connections.append(r)

def check(key, type) :
	first = None
	for r in connections :
		if type == 'string' :
			value = r.get(key)
			if first == None :
				first = value   
			else :      
				if value != first and long(first) > 0 :
					mismatch_set.add(key)
					print "total %ld, %s, %s, %s" % (len(mismatch_set), key, first, value)
					sys.stdout.flush()
					return
		elif type == 'list' :
			value = r.lrange(key, 0, -1)
			if first == None :
				first = value
			else :
				if value != first :
					mismatch_set.add(key)
					return
		elif type == 'hash' :
			value = r.hgetall(key)
			if first == None :
				first = value
			else :
				if value != first :
					mismatch_set.add(key)
					return
		elif type == 'set' :
			value = r.smembers(key)
			if first == None :
				first = value
			else :
				if value != first :
					mismatch_set.add(key)
					return
		elif type == 'zset' :
			value = r.zrange(key, 0, -1)
			if first == None :
				first = value
			else :
				if value != first :
					mismatch_set.add(key)
					return
		elif type == 'none' :
			pass

def main() :
	connect_all()
	r = connections[0]
	if len(sys.argv) == 1 :
		count = 1000000
	else :
		count = long(sys.argv[1])
	
	for i in xrange(0, count) :
		time.sleep(interval)

		if i % 10000 == 0 :
			print "%ld keys checked, %ld mismatch" % (i, len(mismatch_set))

		key = r.randomkey()
		if key :
			if key[0] != '3' or len(key) < 17 :
				count = count + 1
				continue
			#type = r.type(key)
			type = 'string'
			check(key, type)
		else :
			count = count + 1
		continue

	print '\n\nTotal mismatches', len(mismatch_set)
	for x in mismatch_set :
		print x

if __name__ == '__main__' :
	main()
