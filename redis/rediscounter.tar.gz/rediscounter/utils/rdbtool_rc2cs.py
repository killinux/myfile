# Convert old format rdb file to new format aof file
# Created:2012-11-06
# Author: Xiang Xue Song(xuesong3@staff.sina.com.cn)
import struct
import time
import os,errno
import binascii
from optparse import OptionParser,OptionGroup

RDB_INVALID_LEN = 252
REDIS_RDB_6BITLEN = 0
REDIS_RDB_14BITLEN = 1
REDIS_RDB_32BITLEN = 2
REDIS_RDB_ENCVAL = 3

REDIS_RDB_ENC_INT8 = 0
REDIS_RDB_ENC_INT16 = 1
REDIS_RDB_ENC_INT32 = 2
REDIS_RDB_ENC_LZF = 3

REDISCOUNTER_RDB_BLOCK  = 10 * 1024 * 1024
AOF_BUFFER_SIZE = 1024

empty_key = '\0' * 25
deleted_key = 'F' * 25

usage = '''usage: %prog [options] arg\n\t-h or --help for help\n\n'''\
        '''This program is used to convert old rdb file to new format aof file for rediscounter.\n'''

_time_counter = time.time()
_time_bigin = _time_counter

def time_used(msg = "") :
    global _time_counter
    now = time.time()
    print "now=%d, time_used=%dms, time_total=%dms, msg=%s" % (now, (now - _time_counter)*1000, (now - _time_bigin)*1000, msg)
    _time_counter = now

class Aof :
    def __init__(self, index, filename) :
        self.index = index
        if index == 0:
            self.filename = "invalid-aof.0000"
        else:
            self.filename = filename
        self.buffer = []

    def add_schema(self):
        # config column add cntsr 16
        # config column add cntsc 16
        self.buffer.append("*5\r\n$6\r\nconfig\r\n$6\r\ncolumn\r\n$3\r\nadd\r\n$5\r\ncntsr\r\n$2\r\n14\r\n")
        self.buffer.append("*5\r\n$6\r\nconfig\r\n$6\r\ncolumn\r\n$3\r\nadd\r\n$5\r\ncntsc\r\n$2\r\n14\r\n")

    def save(self):
        if len(self.buffer) == 0:
            return
        time_used("save buffer, filename=%s, len=%d" % (self.filename, len(self.buffer)))        
        with open(self.filename, "ab+") as f:
            f.writelines(self.buffer)
        self.buffer = []
        time_used("save buffer done, filename=%s" % self.filename)

    def add(self, key, value):
        self.buffer.append("*3\r\n$3\r\nset\r\n$%d\r\n%s\r\n$%d\r\n%d\r\n" % (len(key), key, len(str(value)), value))
        if(len(self.buffer) > AOF_BUFFER_SIZE):
            self.save()

class RdbParser :
    def __init__(self, aof_number) :
        self._f = None
        self.aof_number = int(aof_number)
        self.aof_obj = []
        self.deleted_key = 0
        self.saved_key = 0
        self.other_key = 0
        
        # init aof objects and add schema to the first one
        for j in xrange(8):
            try:	
                path = "aof_801%d" % j
                os.makedirs(path)
            except OSError as exc: # Python >2.5
                if exc.errno == errno.EEXIST and os.path.isdir(path):
                    pass
                else: raise
            tmp_aof_obj = []
            for i in xrange(self.aof_number):
                tmp_aof_obj.append(Aof(i, "%s/%s.%09d" % (path, options.aof_filename, i)))
            self.aof_obj.append(tmp_aof_obj)
        
        #self.aof_obj[1].add_schema()

    def check_magic(self) :
        s = self._f.read(5)
        if s != 'REDIS' :
            raise Exception('check_magic', 'Invalid File Format')

    def check_version(self) :
        s = self._f.read(4)
        ver = int(s)
        if ver != 3 : 
            raise Exception('check_version', 'Invalid RDB version %d, should be "3"' % version)
  
    def read_byte(self) :
        return struct.unpack('B', self._f.read(1))[0]

    def read_unsigned_short(self) :
        return struct.unpack('H', self._f.read(2))[0]

    def read_unsigned_int(self) :
        return struct.unpack('I', seld._f.read(4))[0]
        
    def read_unsigned_long(self) :
        return struct.unpack('L', self._f.read(8))[0]

    def parse_fail(self, reason) :
        raise Exception('parse', 'Parse failed at position %d, fail=%s' % (self._f.tell(), reason))

    def rdb_get_long(self) :
        L = self.read_byte()
        if L > RDB_INVALID_LEN:
            parse_fail("Invalid number")

        return long(self._f.read(L))

    def read_length_with_encoding(self) :
        length = 0
        is_encoded = False
        bytes = []
        bytes.append(self.read_byte())
        enc_type = (bytes[0] & 0xC0) >> 6
        if enc_type == REDIS_RDB_ENCVAL :
            is_encoded = True
            length = bytes[0] & 0x3F
        elif enc_type == REDIS_RDB_6BITLEN :
            length = bytes[0] & 0x3F
        elif enc_type == REDIS_RDB_14BITLEN :
            bytes.append(self.read_byte())
            length = ((bytes[0]&0x3F)<<8)|bytes[1]
        else :
            parse_fail("Encode not support")  # 32bit len, not implemented
        
        return (length, is_encoded)

    def read_length(self) :
        return self.read_length_with_encoding()[0]

    def rdb_get_string(self) :
        tup = self.read_length_with_encoding()
        length = tup[0]
        is_encoded = tup[1]
        val = None

        if is_encoded :
            if length == REDIS_RDB_ENC_INT8 :
                val = self.read_unsigned_char()
            elif length == REDIS_RDB_ENC_INT16 :
                val = self.read_unsigned_char()
            elif length == REDIS_RDB_ENC_INT32 :
                val = self.read_unsigned_char()
            elif length == REDIS_RDB_ENC_LZF :
                parse_fail("Encode not support")  # not implemented
        else :
            val = self._f.read(length)

        return val

    def adjust_block_size(self, entry_size) :
        global REDISCOUNTER_RDB_BLOCK
        self.info("REDISCOUNTER_RDB_BLOCK=%d" % REDISCOUNTER_RDB_BLOCK)
        # adjust REDISCOUNTER_RDB_BLOCK to the times of entry_size
        REDISCOUNTER_RDB_BLOCK = entry_size * ((REDISCOUNTER_RDB_BLOCK+entry_size-1) / entry_size)
        self.info("REDISCOUNTER_RDB_BLOCK=%d" % REDISCOUNTER_RDB_BLOCK)

    def aof_add(self, key, value) :
        mid, col = key.split(".")
        if len(mid) > 16:
            mid = "1000"  # force write to aof file 0000

        col = col.strip()
        if not col in ["cntsr", "cntsc", "cntsa"]:
            print "key not matched, mid=%s col=%s" % (mid, col)
            self.other_key = self.other_key + 1
            return
	sufix = 'repost'
	if col == 'cntsc':
  	    sufix = 'comment'
	if col == 'cntsa':
	    sufix = 'like'
        first = -15
        last = -11
        prefix = mid[first:last]
        if not prefix:
            prefix = "0"
        shardindex =  ((binascii.crc32(mid) & 0xFFFFFFFF) / 256 % 256) / 32 # cydu
        index = int(prefix) % self.aof_number   
        self.aof_obj[shardindex][index].add(mid+"."+sufix, value)
        self.saved_key = self.saved_key + 1

    def rdb_get_dict(self) :
        self.adjust_block_size(self.entry_size)
        total = self.size * self.entry_size
        count = total / REDISCOUNTER_RDB_BLOCK
        rest = total % REDISCOUNTER_RDB_BLOCK
        print "total=%d, count=%d, rest=%d" % (total, count, rest)

        for i in xrange(count+1) :
            if i < count:
                key_count = REDISCOUNTER_RDB_BLOCK / self.entry_size
                buf = self._f.read(REDISCOUNTER_RDB_BLOCK)
            else:
                key_count = rest / self.entry_size
                buf = self._f.read(rest)

            time_used("get dict, block_id=%d block_size=%dM key_count=%d" % 
                (i, REDISCOUNTER_RDB_BLOCK/1024/1024, key_count))                
            
            struct_fmt = "".join(["=", "I%ds"%self.key_size * key_count])
            entries = struct.unpack(struct_fmt, buf)

            for j in xrange(key_count): 
                try:
                    value = entries[j*2]
                    key = entries[j*2+1]

                    if not cmp(key, empty_key):
                        continue

                    if not cmp(key, deleted_key):
                        self.deleted_key = self.deleted_key + 1
                        value = 0

                    if value < 1 or value > 100000000:
                        self.other_key = self.other_key + 1
                        value = 0

                    self.aof_add(key.rstrip("\0"), value)
                except Exception,e:
                    print "Exception:", e, ", key:", key, ", value", value
            
            time_used("block_id=%d block_size=%dM key_count=%d saved_key=%d deleted_key=%d other_key=%d %%%d finished" % 
                (i, REDISCOUNTER_RDB_BLOCK/1024/1024, key_count, self.saved_key, self.deleted_key, self.other_key, i*100/count))  
        for j in xrange(8):
	        for i in xrange(self.aof_number):
	            self.aof_obj[j][i].save()

    def info(self, msg) :
        print(msg)

    def parse(self, filename):
        time_used("parse begin...")
        with open(filename, "rb") as self._f:
            self.check_magic()
            self.check_version()
            self.rdb_filename = self.rdb_get_string()
            self.offset = self.rdb_get_long()
            self.size = self.rdb_get_long()
            self.used = self.rdb_get_long()
            self.deleted = self.rdb_get_long()
            self.key_size = self.rdb_get_long()
            self.entry_size = self.rdb_get_long()
            self.value_size = self.entry_size - self.key_size
            self.array = {}
            self.info("rdb_filename=%s, offset=%d, size=%d, used=%d, deleted=%d, key_size=%d, entry_size=%d" % 
                (self.rdb_filename, self.offset, self.size, self.used, self.deleted, self.key_size, self.entry_size))

            self.rdb_get_dict()

if __name__ == '__main__':
    arg_parser = OptionParser(usage)
    arg_parser.add_option("-i", "--input", type="string", dest="rdb_filename", help="Input rdb filename. [default: %default]", default="../../key_rediscounter/dump.rdb")
    arg_parser.add_option("-o", "--output", type="string", dest="aof_filename", help="Output aof filename. [default: %default]", default="output.aof")
    arg_parser.add_option("-r", "--report", action="store_true", dest="report_mode", help="Report mode, don't save aof file. [default: %default]", default=False)
    arg_parser.add_option("-c", "--aof_number", type="int", dest="aof_number", help="AOF file number. [default: %default]", default=10000)

    options, args = arg_parser.parse_args()

    rdb = RdbParser(options.aof_number)
    rdb.parse(options.rdb_filename)

    time_used("all done: saved_key=%d deleted_key=%d other_key=%d" % 
        (rdb.saved_key, rdb.deleted_key, rdb.other_key))
