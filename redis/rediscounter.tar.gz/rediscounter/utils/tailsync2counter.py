import struct
import sys,traceback
import os,errno
import pprint
import time
import redis
import binascii
from rdbtool_like import Aof

from redis_checker_conf import *
connections = []
def connect_all(servers) :
        connections = []
        for server in servers :
                tmp = server.partition(':')
                ip = tmp[0]
                port = int(tmp[2])
                r = redis.Redis(ip, port, 0)
                r.ping()
                connections.append(r)
        return connections
connections = connect_all(servers2)

class AofParser :
    MAX_READ_LENGTH = 1000000
    def __init__(self, port, num) :
        self._f = None
        self.saved_key = 0
        self.aof_obj = []
        self.port = port
        self.num = num
        self.format = "/data2/work/counterservice/%d/data/appendonly.aof.000000%3d"
        #self.format = "%d.tmp.%d"
        self.filename = ""

    def tonewaof(self, line) :
        if len(line[4]) < 2: 
                return
        mid,col = line[4].split(".")
        if col not in ('cntsc','cntsr','cntsa'):
            raise Exception('Error %s' % col)
        if col == 'cntsr':
            line[4] = "%s.repost" % mid
        if col == 'cntsc':
            line[4] = "%s.comment" % mid
        if col == 'cntsa':
            line[4] = "%s.like" % mid

        line[3] = "$%d" % len(line[4])
        first = -15
        last = -11
        prefix = mid[first:last]
        if not prefix:
            prefix = "0"
        shardindex =  ((binascii.crc32(mid) & 0xFFFFFFFF) / 256 % 256) / 32 # cydu
        print "set %s %s %d %d" % (line[4],line[6], shardindex, self._f.tell() )        
        r = connections[shardindex]
        r.set(line[4],line[6])
    
    def fix_read_pos(self):
        self.rotate_file()
        pos = self._f.tell()
        if pos < 100000 : 
                self._f.seek(0)
        else: 
                time.sleep(3)
                self._f.seek(pos-10000)
                while 1:
                        tmp = self._f.readline()[:-2]
                        col = tmp[-5:]
                        if col in ('cntsc','cntsr','cntsa'):
                                tmp = self._f.readline()[:-2]
                                tmp = self._f.readline()[:-2]
                                break
        print "fix pos of %s from %d to %d" % (self.filename,pos,self._f.tell())
    
    def filesize(self, filename):
        size = 0
        try:
            st = os.stat(filename)
            size = st.st_size        
        except Exception, e:
            print "Exception: filesize ",e, filename
        return size
 
    def rotate_file(self):
        newfilename = self.format % (self.port, self.num+1)
        if self._f.tell() + 10 >= self.filesize(self.filename) and  \
           self.filesize(newfilename) > 0 :
            print "%s rotate from %s:%d to newfile %s " % \
              (time.time(),self.filename, self._f.tell(),newfilename)
            self.num = self.num + 1
            self.filename = self.format % (self.port, self.num)
            self._f.close()
            self._f = open(self.filename, "rb");
            if not self._f : 
                raise Exception('Error open file', self.filename)
 
    def read_onekey(self):
            line = []
            try:
                for i in xrange(7):
                        tmp = self._f.readline()[:-2]
                        #print "tmp",tmp
                        line.append(tmp)
                return line
            except Exception,e:
                print "Exception: read_onekey error ",e,self.filename,self._f.tell()

    def parse(self):
        self.filename = self.format % (self.port, self.num)
        print self.filename
        self._f = open(self.filename, "rb");
        #tmp use seek
        #self._f.seek(973730052) 
        last_err = False
        while self._f :
              try:
                        if last_err : 
                                self.fix_read_pos()
                                time.sleep(0.5)
                                last_err = False
                        response = self.read_onekey()                
                        #pprint.pprint(response)
                        if len(response) >= 7 and response[0] == "*3" and len(response[6]) > 0:
                                self.tonewaof(response)
                        else :
                                  time.sleep(0.5)
                                  raise Exception('Error response %s' % response)
              except Exception,e:
                  print "Exception: parse error ",e,self.filename,self._f.tell()
                  traceback.print_exc(file=sys.stdout)
                  last_err = True

if __name__ == '__main__':
        if len(sys.argv) < 3:
                quit()
        aof = AofParser(int(sys.argv[1]),int(sys.argv[2]))
        aof.parse()
