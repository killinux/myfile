import time
import redis
import logging
import MySQLdb
import sys
from binascii import crc32

MIN_ID=3000000000000000
MAX_ID=4500000000000000

DBREPOST=4803
DBCOMMENT=4804

HOSTIDX=0
PORTIDX=1
#id mapping dbs 
id_map_servers=[
	["s4951i.eos.grid.sina.com.cn",4951],
	["s4952i.eos.grid.sina.com.cn",4952],
	["s4953i.eos.grid.sina.com.cn",4953],
	["s4954i.eos.grid.sina.com.cn",4954],
	["s4955i.eos.grid.sina.com.cn",4955],
	["s4956i.eos.grid.sina.com.cn",4956],
	["s4957i.eos.grid.sina.com.cn",4957],
	["s4958i.eos.grid.sina.com.cn",4958]
		]
#counterservice redis
rdses=[
    '10.75.19.88 8010',
    '10.75.19.88 8011',
    '10.75.19.88 8012',
    '10.75.19.88 8013',
    '10.75.19.89 8014',
    '10.75.19.89 8015',
    '10.75.19.89 8016',
    '10.75.19.89 8017'
       ]

class DbProxy:
	def __init__(self,servers):
		self.dbs=[]
		for s in servers:
			host = s[HOSTIDX]
			port = int(s[PORTIDX])
			db = MySQLdb.connect(host=host,port=port,user='openapi',passwd='im1400uc')
			self.dbs.append(db)

		self.sql='SELECT mid,id FROM %s WHERE mid IN(%s)'

	def query(self,idx,mids):
		if not len(mids):
			return {}
		table = "status_si_%d.mid_id_%d"%(idx[1],idx[2])
		sql = self.sql%(table,','.join(mids))
		res={}
		cur = self.dbs[idx[0]].cursor()
		cur.execute(sql)
		for row in cur:
			res[str(row[0])]=str(row[1])
		return res

class Processor:
    def __init__(self,conf):
        #ConfParser split multipul values by '\n'
        self.dbs = [redis.Redis(host,int(port)) for (host,port) in (s.split() for s in rdses)]
        host = "m%di.eos.grid.sina.com.cn" % DBREPOST
        self.dbr = MySQLdb.connect(host=host,port=DBREPOST,user='openapi_r',passwd='im1400uc')
        host = "m%di.eos.grid.sina.com.cn" % DBCOMMENT
        self.dbc = MySQLdb.connect(host=host,port=DBCOMMENT,user='openapi_r',passwd='im1400uc')
        self.sql ='SELECT count FROM %s WHERE id = %s'
        self.proxy = DbProxy(id_map_servers)

    def hash(self,key):
        return (((crc32(key)&0xFFFFFFFF)/256)%256)/(256/len(self.dbs))

    def hashmysql(self,id):
        yymmdd=None
        ts = 0
        if(len(id)==16 and id.startswith('3') or id.startswith('4')):
            #id v4
            ts = (long(id)>>22)+515483463
        elif len(id)==19 and id.startswith('5'):
            #id v3
            ts = long(id)>>32
        elif id.startswith('1'):
            yymmdd = id[1:7]
        else:
            yymmdd = id[3:9]

        if ts!=0:
            tm = time.localtime(ts)
            year = str(tm.tm_year)[-2:]
            mon = tm.tm_mon
            flag=1
            if tm.tm_mday> 15:
                flag=2
            return ("%s%02d"%(year,mon),flag)
        if yymmdd!=None:
            yymm = yymmdd[0:4]
            dd = yymmdd[-2:]
            flag = 1
            if int(dd)>15:
                flag = 2
            return (yymm,flag)

    def getvalbyid(self,id, type):
        yymm,flag=self.hashmysql(id)
	cur = self.dbr.cursor()
        if "repost" == type:
            table = "counter.count_3_%s_15_%d"%(yymm,flag)
            cur = self.dbr.cursor()
        else:
            table = "counter.count_4_%s_15_%d"%(yymm,flag)
            cur = self.dbc.cursor()
        sql = self.sql%(table,id)
        cur.execute(sql)
	ans = 0
        for row in cur:
            ans = row[0]
	if ans is None:
            logging.warn("%s value not found",key)
            ans = 0
	return ans

    def hashmidMySQL(key):
        idx = ((crc32(key)&0xFFFFFFFF)/256)%256
        portidx = idx/32
        dbidx = idx/8
        tblidx = idx % 8
        return map(str,(portidx,dbidx,tblidx))

    def getmapid(self,key):
        if long(key)<3342818919841793 or long(key)>MAX_ID:
            idx = self.hashmidMySQL(key)
            try:
                mids = self.proxy.query(map(int,idx),[key])
            except Exception,e:
                logging.error(str(e))
                self.proxy = DbProxy(id_map_servers)
                mids = self.proxy.query(map(int,idx),[key])
             
            if not len(mids):
                logging.warn("%s mapping not found",key)
                return
            key = mids[key]
	return key
 
    def process_stdin(self,key, type):
        val = self.getvalbyid(key,type)
        if val==0:
            return
	key = self.getmapid(key)
        idx = self.hash(key)
        db = self.dbs[idx]
        try:
            print idx,key,type,val
            db.set("%s.%s"%(key,type),val)
        except Exception,e:
            logging.error("Error write to redis:%s",str(e))
if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG,format='[%(filename)s:%(lineno)d] %(process)d %(asctime)s %(levelname)s:%(message)s',filename='repair_cs_by_id.log')
    proc = Processor(None)
    if len(sys.argv) < 2:
	print "cat data | ",sys.argv[0]," [repost|comment|all]"
	sys.exit(-1)
    type = sys.argv[1]
    if type not in ["repost","comment","all"]:
	print "cat data | ",sys.argv[0]," [repost|comment|all]"
	sys.exit(-2)
    for key in sys.stdin:
        key=key.strip()
	if not key.isdigit():
            continue
 	if type == "all":
            proc.process_stdin(key,"repost")
            proc.process_stdin(key,"comment")
	else :	
            proc.process_stdin(key,type)
