# Ganglia plugin for counterservice.
# Date: 2012-11-26
# Author: Xiang Xuesong ( xuesong3@staff.sina.com.cn)
#
import socket
import time
import os
import sys
import pprint
sys.path.append("/usr/local/ganglia/lib64/python_modules")
from cs_ganglia_conf import *

def Log(msg):
    msg = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    #print msg
    f = open(LOF_FILE_NAME, "ab+")
    f.write(msg + "\n")
    f.close

def send_mail(mail_to_list, msg):
    # TODO: add to buffer and send together later
    if not len(mail_to_list):
        return

    url = SEND_MAIL_URL % (msg, ",".join(mail_to_list))
    result = os.popen(url)
    Log("send mobile:%s [result=%s]" % (url, result))

def send_mobile(mobile_to_list, msg):
    # TODO: add to buffer and send together later
    if not len(mobile_to_list):
        return

    url = SEND_MOBILE_URL % (msg, ",".join(mobile_to_list))
    result = os.popen(url)
    Log("send mobile:%s [result=%s]" % (url, result))

# metric_name, value
def send_alert(n, v):
    condition_msg = {
        ">":"exceed",
        "<":"below",
        "=":"=",
        "!":"!="
    }
    try:
        m = counterservice_config["metrics"].get(metric_basename(n), None)
        increment = m["alert"].get("increment", 0)
        value_suffix = ""
        if increment:
            value_suffix = "/s"
        condition = m["alert"]["threshold"][0]
        msg = "%s %s's value [%s%s] %s its threshold [%s%s]" % \
            (counterservice_config["alert_prefix"], n, str(v), value_suffix, condition_msg[condition], m["alert"]["threshold"], value_suffix)
        mail_to_list = []
        mobile_to_list = []
        for notice_type, notice_list in m["alert"]["notice_list"].iteritems():
            try:
                if notice_type == "mail":
                    for to in notice_list:
                        mail_to_list.append(to)
                        Log("+ mail to %s: %s" % (to, msg))
                elif notice_type == "mobile":    
                    for to in notice_list.values():
                        mobile_to_list.append(to)
                        Log("+ mobile to %s: %s" % (to, msg))              
            except Exception,e1:
                Log("Got exception when send alert:" + str(e1))

        send_mail(mail_to_list, msg)
        send_mobile(mobile_to_list, msg)
    except Exception,e:
        Log("Got exception in send_alert:" + str(e))

def check_threshold(v, threshold):
    if len(threshold) < 2:
        return False

    condition = threshold[0]
    if threshold[1] == 's':
        if len(threshold) < 3:
            return False        
        value = threshold[2:]
    elif threshold[1] == '%':
        if len(threshold) < 3:
            return False        
        value = threshold[2:]
        v = v[:-1]
    else:
        value = int(threshold[1:])

    #print("%s:condition=%s\n" % (threshold, condition))
    if condition == '>':
        return v > value
    elif condition == '<':
        return v < value
    elif condition == '=':
        return v == value
    elif condition == '!':
        return v != value
    else:
        return False

# metric_name, values
def check_alert(n, values):
    global counterservice_config
    m = counterservice_config["metrics"].get(metric_basename(n), None)
    if not m or not  m["alert"]:
        return
    
    a = m["alert"]
    increment = a.get("increment", 0)

    if increment:
        v = values["qps"]
    else:
        v = values["last"]
    
    if check_threshold(v, a["threshold"]): 
        send_alert(n, v)

# metric_name, value
def update_metric(n, v):
    global counterservice_config
    values = {}
    last = get_metric_last(n)
    try:
        v = int(v) # TODO Use value_type.
        if not last:
            last = v
        values["delta"] = v - last
        values["qps"] = values["delta"] / INFO_CHECK_INTVAL
    except ValueError, e:
        values["delta"] = 0
        values["qps"] = 0
    values["last"] = v
    counterservice_config["info"][n] = values
    check_alert(n, values)

def get_metric_last(n):
    global counterservice_config
    values = counterservice_config["info"].get(n, None)
    if not values:
        return 0
    else:
        return values["last"]

def get_metric_delta(n):
    global counterservice_config
    if len(n) > 4 and n[-4:] == "_qps":
        n = n[:-4]
    values = counterservice_config["info"].get(n, None)
    if not values:
        return 0
    else:
        return values["qps"]

def metric_basename(n):
    try:
        base, port = n.split('-')
        return base
    except:
        return n

def get_metric_value(n):
    global counterservice_config
    m = counterservice_config["metrics"].get(metric_basename(n), None)
    if not m or not m.get("qps", None):
        return get_metric_last(n)
    else:
        return get_metric_delta(n)

def info_handler(name):
    global counterservice_config

    if INFO_CHECK_INTVAL < time.time() - counterservice_config["timestamp"]:
        Log("info_handler: check info...")
        for port in counterservice_config["ports"]:
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.connect((counterservice_config["host"], port))

                s.settimeout(5) # set socket timeout as to not block gmond

                s.send("INFO\r\n")
                info = s.recv(4096)
                if "$" != info[0]:
                    Log("Error: No info!")
                    return 0

                len = int(info[1:info.find("\n")])
                if 4096 < len:
                    info += s.recv(len - 4096)

                for line in info.splitlines()[1:]:
                    if "" == line:
                        continue
                    try:
                        n, v = line.split(":")
                    except Exception,e:
                        Log("[port:%s]bad info (%s):%s" % (port, str(e), line))
                        continue
                    n = "%s-%s" % (n, port)
                    if n in counterservice_config["descriptors"]:
                        update_metric(n, v)
                s.close()
            except Exception,e1:
                Log("[port:%s] Got exception while send info command:%s" % (port, str(e1)))      

        counterservice_config["timestamp"] = time.time()

    return get_metric_value(name)

def stat_handler(name):
    print "**** STAT: ", name
    return 0

def log_handler(name):
    print "**** LOG: ", name
    return 0

def metric_init(params={}):
    global descriptors, counterservice_config, info_handler
    handler_list = {
        "log" : log_handler,
        "stat" : stat_handler,
        "info": info_handler,    
    }    

    Log("metric_init")

    counterservice_config["descriptors"] = {}
    for port in counterservice_config["ports"]:
        for name, m in counterservice_config["metrics"].iteritems():
            descriptor = {
                "name": "%s-%s" % (name, port),
                "call_back": handler_list[m["type"]],
                "time_max": 90,
                "value_type": "uint",
                "units": "",
                "slope": "both",
                "format": "%d",
                "description": "http://code.google.com/p/redis/wiki/InfoCommand",
                "groups": "counterservice",
            }
            descriptor.update(m.get("updates", {}))
            counterservice_config["descriptors"][descriptor["name"]] = descriptor
            if m.get("qps", None):
                descriptor_qps = descriptor
                descriptor_qps["name"] = "%s-%s_qps" % (name, port)
                counterservice_config["descriptors"][descriptor["name"]] = descriptor_qps

    return counterservice_config["descriptors"].values()

def metric_cleanup():
    pass

# For testing
if __name__ == "__main__":
    desc = metric_init({"host": "127.0.0.1","port":6383})
    for d in desc:
        v = d['call_back'](d['name'])
        print '%s => %s' % (d['name'], str(v))

    INFO_CHECK_INTVAL = 1
    time.sleep(3)

    for d in desc:
        v = d['call_back'](d['name'])
        print '%s => %s' % (d['name'], str(v))
