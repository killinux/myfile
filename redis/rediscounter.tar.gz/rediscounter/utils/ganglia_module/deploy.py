import os
import sys

servers = {
	"10.75.29.35" : [7902, 7904, 7906, 7908, ],
	"10.75.29.36" : [7902, 7904, 7906, 7908, ],
	"10.75.29.37" : [7902, 7904, 7906, 7908, ],
	"10.75.29.38" : [7902, 7904, 7906, 7908, ],
	"10.79.40.79" : [7910, 7912, 7914, 7916, ],
	"10.79.40.80" : [7910, 7912, 7914, 7916, ],
	"10.79.40.81" : [7910, 7912, 7914, 7916, ],
	"10.79.40.82" : [7910, 7912, 7914, 7916, ],		
}

metrics = {
	"db_total_keys" : {"qps" : 1,},
	"db_key_write" : {"qps" : 1,},
	"db_key_read" : {"qps" : 1,},
	"used_memory" : {},
	"db_extends_size" : {},
	"db_auxdb_size" : {},
	"db_free" : {},
	"danger_command" : {},
	"max_key" : {},
	"current_table" : {},
	"connected_slaves" : {},
	"db_free_percentage" : {},
}


pyconf_tmpl = """
# module config file for %s
modules {
  module {
    name = "cs_ganglia"
    language = "python"
  }
}

collection_group {
  collect_every = 60
  time_threshold = 60

  %s

 } 
"""

metric_tmpl = """
  metric {
    name = "%s-%s"
    title = "%s-%s"
  } 
"""

module_conf_tmpl_file = "./cs_ganglia_conf.tmpl"
module_file = "./cs_ganglia.py"
module_file_remote = "/usr/local/ganglia/lib64/python_modules/cs_ganglia.py"
module_conf_file = "cs_ganglia_conf.py"
module_conf_file_remote = "/usr/local/ganglia/lib64/python_modules/cs_ganglia_conf.py"
ganglia_conf_file = "cs_ganglia.pyconf"
ganglia_conf_file_remote = "/usr/local/ganglia/etc/conf.d/cs_ganglia.pyconf"

def save(filename, content):
	print("save file %s..." % filename)
	f = open(filename, "wb+")
	f.write(content)
	f.close()

def get_module_conf_tmpl():
	f = open(module_conf_tmpl_file)
	content = f.read()
	f.close()
	return content

def run(cmd):
	print("+ %s" % cmd)
	f = os.popen(cmd)
	print f.read()
	f.close()

def deploy_file(host, local, remote):
	deploy_cmd = "scp %s %s:%s" % (local, host, remote)
	run(deploy_cmd)

def run_remote(host, cmd):
	remote_cmd = "ssh %s %s" % (host, cmd)
	run(remote_cmd)

for ip, ports in servers.iteritems():
	metrics_str = ""
	for m, prop in metrics.iteritems():
		metrics_str = metrics_str + "\n########## %s ##########" % (m, )
		for p in ports:
			metrics_str = metrics_str + metric_tmpl % (m, str(p), m, str(p))
		if prop.get("qps", None):
			metrics_str = metrics_str + "\n########## %s ##########" % (m+"_qps", )
			for p in ports:
				metrics_str = metrics_str + metric_tmpl % (m, str(p)+"_qps", m, str(p)+"_qps")

	pyconf_str = pyconf_tmpl % (ip, metrics_str, )
	if not os.path.exists(ip):
		os.mkdir(ip)
	ganglia_conf_file_local = ip + "/" + ganglia_conf_file
	save(ganglia_conf_file_local, pyconf_str)

	module_conf_tmpl = get_module_conf_tmpl()
	module_conf_str = module_conf_tmpl % (str(ports), ip)
	module_conf_file_local = ip + "/" + module_conf_file
	save(module_conf_file_local, module_conf_str)

	deploy_file(ip, ganglia_conf_file_local, ganglia_conf_file_remote)
	deploy_file(ip, module_conf_file_local, module_conf_file_remote)
	deploy_file(ip, module_file, module_file_remote)

	run_remote(ip, "service gmond restart")
