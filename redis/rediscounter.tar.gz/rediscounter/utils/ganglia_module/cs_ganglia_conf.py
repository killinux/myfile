INFO_CHECK_INTVAL = 15
LOF_FILE_NAME = "/usr/local/ganglia/lib64/python_modules/cs_ganglia.log"
SEND_MOBILE_URL = "curl 'http://monitor.intra.weibo.com/interface/send_mobile_message.php' -d\"object=counterservice&content=%s&mobile=%s\"" 
SEND_MAIL_URL = "curl 'http://monitor.intra.weibo.com/interface/send_mobile_message.php' -d\"object=counterservice&content=%s&mobile=%s\""

mail_list = {
    "counterservice_notice" : [
        "xuesong3@staff.sina.com.cn",
    ],
    "test_notice" : [
        "xuesong3@staff.sina.com.cn",
    ],
}

mobile_list = {
    "counterservice_notice" : {
        "xuesong3" : "13693373372",
        "chuanying" : "15010259186",
        "jianguo" : "13911590476",
        "fengjun" : "13466588485",        
    },
}

default_both_notice_list = {
    "mail" : mail_list["counterservice_notice"], 
    "mobile" : mobile_list["counterservice_notice"],
}

default_mail_notice_list = {
    "mail" : mail_list["counterservice_notice"], 
}

default_mobile_notice_list = {
    "mobile" : mobile_list["counterservice_notice"],
}

# metric example
# "danger_command" : {       <- metric name
#     "type" : "log",        <- log, info or stat, related callback will be called
#     "updates" : {          <- will update the default properties for metric, such as unit, etc.
#     },
#     "alert" : {           
#         "threshold" : "=1",   <- the first character is '=', '>', '!' or '<'
#         "increment" : 1,      <- if 1, the threshold is the delta in one second, that is 'QPS'
#         "pattern" : "",       <- not used
#         "notice_list" : default_mail_notice_list,    <- see default_mail_notice_list for example
#     }
# }, 

counterservice_config = {
    "ports" : [7902, 7904, 7906, 7908,],
    "alert_prefix" : "[10.79.40.80]",
    "host" : "127.0.0.1",
    "descriptors" : {},
    "info" : {},
    "timestamp" : 0,
    "basedir" : "/home/work/platcode/rediscounter/truck/src",
    "metrics" : {
        "danger_command" : {
            "type" : "log",
            "updates" : {
            },
            "alert" : {
                "threshold" : "=1", 
                "pattern" : "send 'flushall",
                "notice_list" : default_mail_notice_list, 
            }
        }, 
        "max_key" : {
            "type" : "info",
            "alert" : {
                "threshold" : ">s3616394899896327", 
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        },          
        "db_key_read" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : ">1000", 
                "increment" : 1,
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        },         
        "db_key_write" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : ">1000", 
                "increment" : 1,
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        }, 
        "db_auxdb_size" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : ">100", 
                "increment" : 1,
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        }, 
        "db_extends_size" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : ">100", 
                "increment" : 1,
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        }, 
        "used_memory" : {
            "type" : "info",
            "updates" : {
                "unit" : "M",
            },
            "alert" : {
                "threshold" : ">8074000000", 
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        },      
        "db_free" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : "<100000000", 
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        },   
        "db_total_keys" : {
            "type" : "info",
            "updates" : {
                "unit" : "keys",
            },
            "alert" : {
                "threshold" : ">100000", 
                "increment" : 1,
                "pattern" : "",
                "notice_list" : default_mail_notice_list, 
            }
        },   
        "current_table" : {   # send mail if current table changed
            "type" : "info",
            "updates" : {
            },
            "alert" : {
                "threshold" : "!0", 
                "increment" : 1,
                "notice_list" : default_mail_notice_list, 
            }
        },   
        "connected_slaves" : {
            "type" : "info",
            "updates" : {
            },
            "alert" : {
                "threshold" : ">1000",  #disabled
                "increment" : 0,
                "notice_list" : default_mail_notice_list, 
            }
        },   
        "db_free_percentage" : {
            "type" : "info",
            "updates" : {
            },
            "alert" : {
                "threshold" : ">%70", 
                "increment" : 0,
                "notice_list" : default_mail_notice_list, 
            }
        }
    }
}