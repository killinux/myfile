#!/bin/sh

if [ $# -lt 3 ]; then
    echo "usage: $0 <pkg-name> <version> <release>"
    exit 1
fi

if [ $1 == "counter" ]; then
    tmpdir=/tmp/counter-for-rpm
    rm -rf $tmpdir
    svn export https://svn1.intra.sina.com.cn/weibo/basepackage/rediscounter/tags/tag_release_$2.$3 $tmpdir
    source=$tmpdir
    dest=counterservice-$2
    tar=counterservice-$2.tar.gz
    rpm=/usr/src/redhat/RPMS/x86_64/counterservice-$2-$3.x86_64.rpm
else
    echo "invalid parameter, should be 'counter'"
    exit 1
fi

spec=rpm-$1.spec
sed -i "/%define version/c\%define version ${2}" $spec
sed -i "/%define release/c\%define release ${3}" $spec
sed -i "/Release:/c\Release: ${3}" $spec
rm -rf /tmp/$dest
rm -rf /usr/src/redhat/BUILD/*
rm -rf /usr/src/redhat/SOURCES/*
mkdir /tmp/$dest
cp -af $source/* /tmp/$dest
cd /tmp && tar -czf $tar $dest && cd -
cp -f /tmp/$tar /usr/src/redhat/SOURCES &&
export PATH=".:$PATH" && echo $PATH && rpmbuild -bb $spec &&
cp -f $rpm . &&
echo "Password: 123qwe"
scp $rpm weibopkg@10.210.210.67:/data1/www/rpm/weibo/rpms/
