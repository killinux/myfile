#include "redis.h"

static int jenkinsHash(long key) {
	key = (~key) + (key << 21); // key = (key << 21) - key - 1;
	key = key ^ (key >> 24);
	key = (key + (key << 3)) + (key << 8); // key * 265
	key = key ^ (key >> 14);
	key = (key + (key << 2)) + (key << 4); // key * 21
	key = key ^ (key >> 28);
	key = key + (key << 31);
	return ((int) key) & 0x7fffffff;
}

/*
 * find v from longset *is
 * return
 *     "-1", if v == 0 or has not empty position
 * 	   "0" , if (v==0) or v not in set
 * 	   "1" , if v in set
 * and set *pos at the same time
 *     when return "0" , pos is the right position should be in longset's content field
 *     when return "1" , pos is the right position in longset's content field
 */
static int _longsetLookup(longset* is, int64_t v , uint32_t *pos) {
	if (v == 0) {
		return -1;
	}
    if (is->bucketCount <= 0)
        return -1;
	int64_t k;
	*pos = jenkinsHash(v) & (is->bucketCount - 1);
    if (*pos >= is->bucketCount) 
        return -1;
	k = is->contents[*pos];
//printf("lookup %"PRId64 " , and first pos:%d , got value:%"PRId64 ".\n",v,pos,k);
	if (k == 0) {
		return 0;
	} else if (k == v) {
		return 1;
	}
//printf("lookup %"PRId64 " , has conflict and got next, bucketCount:%d!\n",v,is->bucketCount);
	uint32_t i = 0;
	while (i <= is->bucketCount) {
		(*pos)++;
		i++;
		if (*pos >= is->bucketCount) {
			*pos = 0;
		}
		k = is->contents[*pos];
//printf("lookup %"PRId64 ", and got next pos:%d , got value:%"PRId64 ".\n",v,pos,k);
		if (k == 0) {
			return 0;
		} else if (k == v) {
			return 1;
		}
	}
    return -1;
}
static int _longsetPut(longset* is, int64_t v) {
	if (v == 0) {
		return 1;
	}
	//如果填充率达到75%，则不再进行填充
	uint8_t canPutNew = (is->bucketCount < ((is->length >> 1) + is->length)) ? 0 : 1;
	uint32_t pos = 0;
	int r = _longsetLookup(is , v , &pos);
	if (r == -1) {
		return 0;
	} else if (r == 1) {
		return 1;
	} else if (r == 0 && canPutNew) {
		is->contents[pos] = v;
		is->length ++;
		return 1;
	}
	return 0;
}
static void _shiftSameHashNum4Del(longset* is , int64_t v , uint32_t pos) {
	uint32_t i = 0;
	int64_t k;
	while (i <= is->bucketCount) {
		pos++;
		i++;
		if (pos >= is->bucketCount) {
			pos = 0;
		}
		k = is->contents[pos];
		if (k == 0) {
			return;
		}
		is->contents[pos] = 0;
		is->length --;
		_longsetPut(is,k);
	}
}
static int _longsetDel(longset* is, int64_t v) {
	if (v == 0) {
		return 1;
	}
	uint32_t pos = 0;
	if (_longsetLookup(is , v , &pos) == 1) {
		is->contents[pos] = 0;
		is->length--;
		_shiftSameHashNum4Del(is,v,pos);
		return 1;
	}
	return 0;
}

robj *longsetTypeLookupWriteAlwaysCreate(redisClient *c, robj *key, int bucketCount) {
    robj *newo = createLongsetObject(bucketCount);
    robj *o = lookupKeyWrite(c->db,key);
    if (o != NULL) {
    	dbOverwrite(c->db,key,newo);
    } else {
    	dbAdd(c->db,key,newo);
    } 
    return newo;
}

void lsmallocCommand(redisClient *c) {
    UPDATE_WRITE_STAT(1);
    long bucketCount;
    if (getLongFromObjectOrReply(c, c->argv[2], &bucketCount, NULL) != REDIS_OK) return;
    if (bucketCount <=0 ) {
        addReplyErrorFormat(c,"value's length must be greater then 0");
        return;
    }
    if ((bucketCount&(bucketCount-1))) {
        addReplyErrorFormat(c,"value's length must be 2^n");
        return;
    }
    if ((longsetTypeLookupWriteAlwaysCreate(c,c->argv[1],bucketCount)) == NULL) return;
    addReply(c, shared.ok);
    signalModifiedKey(c->db,c->argv[1]);
    server->dirty++;
}
void lssetCommand(redisClient *c) {
    long elelen;
    robj *o;
    int valuelen = sdslen(c->argv[3]->ptr);
    int bucketCount;
    UPDATE_WRITE_STAT(1);
    if ((valuelen&(valuelen-1)) || (valuelen&7)) {
        addReplyErrorFormat(c,"value's length must be 2^n and n>3");
        return;
    }
    bucketCount = valuelen>>3;
//printf("bucketCount:%d\n",bucketCount);
    if (getLongFromObjectOrReply(c, c->argv[2], &elelen, NULL) != REDIS_OK) return;
    if ((o = longsetTypeLookupWriteAlwaysCreate(c,c->argv[1],bucketCount)) == NULL) return;
    longset *is = (longset*)o->ptr;
    is->length = elelen;
    memcpy(is->contents, c->argv[3]->ptr, valuelen);
//    printf("got length:%d\n",ls->length);
//    printf("---%s\n",(char*)(ls->contents));
    addReply(c, shared.ok);
    signalModifiedKey(c->db,c->argv[1]);
    server->dirty++;
}
void lsputCommand(redisClient *c) {
	robj *o;
	int i;
	UPDATE_WRITE_STAT(1);
	o = lookupKeyWrite(c->db,c->argv[1]);
	if (o == NULL) {
		addReply(c, shared.cnegone);
		return;
	}
	if (checkType(c,o,REDIS_LSET)) return;
	long values[c->argc - 2];
	for (i = 2; i < c->argc; i++) {
//printf("%s\n",c->argv[i]->ptr);
		if (getLongFromObjectOrReply(c, c->argv[i], &(values[i-2]),	NULL) != REDIS_OK) return;
	}
	for (i = 2; i < c->argc; i++) {
//printf("%ld\n",values[i-2]);
		if (_longsetPut(o->ptr, values[i - 2]) != 1) {
			//虽然只有部分加入进去了，但是还是通知modified，能够放到主从中
			addReply(c, shared.czero);
			signalModifiedKey(c->db,c->argv[1]);
			server->dirty++;
			return;
		}
	}
	addReply(c, shared.cone);
	signalModifiedKey(c->db,c->argv[1]);
	server->dirty++;
}
void lsdelCommand(redisClient *c) {
	robj *o;
	int i;
	UPDATE_WRITE_STAT(1);
	o = lookupKeyWrite(c->db,c->argv[1]);
	if (o == NULL) {
		addReply(c, shared.cnegone);
		return;
	}
	if (checkType(c,o,REDIS_LSET)) return;
	long values[c->argc - 2];
	for (i = 2; i < c->argc; i++) {
		if (getLongFromObjectOrReply(c, c->argv[i], &(values[i-2]), NULL) != REDIS_OK) return;
	}
	for (i = 2; i < c->argc; i++) {
		_longsetDel(o->ptr,values[i-2]);
	}
	addReply(c, shared.cone);
	signalModifiedKey(c->db,c->argv[1]);
	server->dirty++;
}
void lsexistsCommand(redisClient *c) {
    int i;
    robj *o;
    longset *is;
    long long value;
    uint32_t pos;

    UPDATE_READ_STAT(1);
    o = lookupKeyRead(c->db,c->argv[1]);
    if (o == NULL) {
    	addReply(c,shared.nullbulk);
    	return;
    }
    if (checkType(c,o,REDIS_LSET)) return;
    is = (longset*)o->ptr;
    char result[c->argc-2];
    for (i = 2; i < c->argc; i++) {
    	if (getLongLongFromObject(c->argv[i], &value) != REDIS_OK) {
    		result[i-2] = '0';
    	} else {
    		if (_longsetLookup(is,value,&pos) == 1) {
    			result[i-2]='1';
    		} else {
    			result[i-2]='0';
    		}
    	}
    }
    addReplyBulkCBuffer(c,result,c->argc-2);
}
void lsgetallCommand(redisClient *c) {
    robj* o;
    uint32_t pos;
    UPDATE_READ_STAT(1);
    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.nullmultibulk)) == NULL
        || checkType(c,o,REDIS_LSET)) return;
    longset *is = (longset*)o->ptr;
    addReplyMultiBulkLen(c,is->length);
printf("length:%d , bucket:%d \n",is->length, is->bucketCount);
    for (pos=0; pos<is->bucketCount; pos++) {
    	int64_t v = is->contents[pos];
printf("%d:%"PRId64 "\n",pos,v);
    	if (v > 0) {
    		addReplyBulkLongLong(c,v);
    	}
    }
}
void lslenCommand(redisClient *c) {
    robj* o;
    UPDATE_READ_STAT(1);
    if ((o = lookupKeyReadOrReply(c,c->argv[1],shared.cnegone)) == NULL
        || checkType(c,o,REDIS_LSET)) return;
    longset *is = (longset*)o->ptr;
    addReplyLongLong(c,is->length);
}
