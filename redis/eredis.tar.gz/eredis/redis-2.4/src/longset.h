#ifndef __LONGSET_H
#define __LONGSET_H
#include <stdint.h>

typedef struct longset {
    uint32_t bucketCount;
    uint32_t length;
    int64_t contents[];
} longset;

longset *longsetNew(uint32_t len);
size_t longsetBlobLen(longset *is);

#endif // __LONGSET_H
