#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <unistd.h>
#include <errno.h>
#include <inttypes.h>
#include <pthread.h>
#include <syslog.h>
#include <time.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <assert.h>
#include <ctype.h>
#include <stdarg.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/uio.h>
#include <limits.h>
#include <float.h>
#include <math.h>
#include <pthread.h>
#include <sys/resource.h>
#include <pwd.h>
#include <lua.h>

#define malloc(size) je_malloc(size)
#define calloc(count,size) je_calloc(count,size)
#define realloc(ptr,size) je_realloc(ptr,size)
#define free(ptr) je_free(ptr)

typedef char* (*redis_main)();
typedef struct _global {
	pthread_t mainthread;
	int port;
    char *bindaddr;
    char *unixsocket;
    mode_t unixsocketperm;
    int ipfd;
    int sofd;
    void *db;
    long long dirty;            /* changes to DB from the last save */
    long long dirty_before_bgsave; /* used to restore dirty on failed BGSAVE */
    void *clients;
    void *commands;             /* Command table hahs table */
    /* RDB / AOF loading information */
    int loading;
    off_t loading_total_bytes;
    off_t loading_loaded_bytes;
    time_t loading_start_time;
    /* Fast pointers to often looked up command */
    void *delCommand, *multiCommand;
    void *slaves, *monitors;
    char neterr[256];
    void *el;
    int cronloops;              /* number of times the cron function run */
    time_t lastsave;                /* Unix time of last save succeeede */
    /* Fields used only for stats */
    time_t stat_starttime;          /* server start time */
    long long stat_numcommands;     /* number of processed commands */
    long long stat_numconnections;  /* number of connections received */
    long long stat_expiredkeys;     /* number of expired keys */
    long long stat_evictedkeys;     /* number of evicted keys (maxmemory) */
    long long stat_keyspace_hits;   /* number of successful lookups of keys */
    long long stat_keyspace_misses; /* number of failed lookups of keys */
    size_t stat_peak_memory;        /* max used memory record */
    size_t stat_used_memory;        /* copy of used memory for live update */
    int zmalloc_thread_safty;       /* set to 1 if zmalloc working in thread safe mode */
    long long stat_fork_time;       /* time needed to perform latets fork() */
    void *slowlog;
    long long slowlog_entry_id;
    long long slowlog_log_slower_than;
    unsigned long slowlog_max_len;
    /* Configuration */
    int verbosity;
    int maxidletime;
    size_t client_max_querybuf_len;
    int dbnum;
    int daemonize;
    int appendonly;
    int appendfsync;
    int no_appendfsync_on_rewrite;
    int auto_aofrewrite_perc;       /* Rewrite AOF if % growth is > M and... */
    off_t auto_aofrewrite_min_size; /* the AOF file is at least N bytes. */
    off_t auto_aofrewrite_base_size;/* AOF size on latest startup or rewrite. */
    off_t appendonly_current_size;  /* AOF current size. */
    int aofrewrite_scheduled;       /* Rewrite once BGSAVE terminates. */
    int shutdown_asap;
    time_t lastfsync;
    int appendfd;
    int appendseldb;
    time_t aof_flush_postponed_start;
    char *pidfile;
    pid_t bgsavechildpid;
    pid_t bgrewritechildpid;
    char *bgrewritebuf; /* buffer taken by parent during oppend only rewrite */
    char *aofbuf;       /* AOF buffer, written before entering the event loop */
    void *saveparams;
    int saveparamslen;
    void *cronsaveparams;
    int cronsaveparamslen;
    void *cronbgrewriteparams;
    int cronbgrewriteparamslen;
    char *logfile;
    int syslog_enabled;
    char *syslog_ident;
    int syslog_facility;
    char *dbfilename;
    char *appendfilename;
    char *requirepass;
    int rdbcompression;
    int activerehashing;
    /* Replication related */
    int isslave;
    /* Slave specific fields */
    char *masterauth;
    char *masterhost;
    int masterport;
    int repl_ping_slave_period;
    int repl_timeout;
    void *master;    /* client that is master for this slave */
    int repl_syncio_timeout; /* timeout for synchronous I/O calls */
    int replstate;          /* replication status if the instance is a slave */
    off_t repl_transfer_left;  /* bytes left reading .rdb  */
    int repl_transfer_s;    /* slave -> master SYNC socket */
    int repl_transfer_fd;   /* slave -> master SYNC temp file descriptor */
    char *repl_transfer_tmpfile; /* slave-> master SYNC temp file name */
    time_t repl_transfer_lastio; /* unix time of the latest read, for timeout */
    int repl_serve_stale_data; /* Serve stale data when link is down? */
    time_t repl_down_since; /* unix time at which link with master went down */
    /* Limits */
    unsigned int maxclients;
    unsigned long long maxmemory;
    int maxmemory_policy;
    int maxmemory_samples;
    /* Blocked clients */
    unsigned int bpop_blocked_clients;
    unsigned int vm_blocked_clients;
    void *unblocked_clients;
    /* Sort parameters - qsort_r() is only available under BSD so we
     * have to take this state global, in order to pass it to sortCompare() */
    int sort_desc;
    int sort_alpha;
    int sort_bypattern;
    /* Virtual memory configuration */
    int vm_enabled;
    char *vm_swap_file;
    off_t vm_page_size;
    off_t vm_pages;
    unsigned long long vm_max_memory;
    /* Zip structure config */
    size_t hash_max_zipmap_entries;
    size_t hash_max_zipmap_value;
    size_t list_max_ziplist_entries;
    size_t list_max_ziplist_value;
    size_t set_max_intset_entries;
    size_t zset_max_ziplist_entries;
    size_t zset_max_ziplist_value;
    /* Virtual memory state */
    FILE *vm_fp;
    int vm_fd;
    off_t vm_next_page; /* Next probably empty page */
    off_t vm_near_pages; /* Number of pages allocated sequentially */
    unsigned char *vm_bitmap; /* Bitmap of free/used pages */
    time_t unixtime;    /* Unix time sampled every second. */
    /* Virtual memory I/O threads stuff */
    /* An I/O thread process an element taken from the io_jobs queue and
     * put the result of the operation in the io_done list. While the
     * job is being processed, it's put on io_processing queue. */
    void *io_newjobs; /* List of VM I/O jobs yet to be processed */
    void *io_processing; /* List of VM I/O jobs being processed */
    void *io_processed; /* List of VM I/O jobs already processed */
    void *io_ready_clients; /* Clients ready to be unblocked. All keys loaded */
    pthread_mutex_t io_mutex; /* lock to access io_jobs/io_done/io_thread_job */
    pthread_mutex_t io_swapfile_mutex; /* So we can lseek + write */
    pthread_attr_t io_threads_attr; /* attributes for threads creation */
    int io_active_threads; /* Number of running I/O threads */
    int vm_max_threads; /* Max number of I/O threads running at the same time */
    /* Our main thread is blocked on the event loop, locking for sockets ready
     * to be read or written, so when a threaded I/O operation is ready to be
     * processed by the main thread, the I/O thread will use a unix pipe to
     * awake the main thread. The followings are the two pipe FDs. */
    int io_ready_pipe_read;
    int io_ready_pipe_write;
    /* Virtual memory stats */
    unsigned long long vm_stats_used_pages;
    unsigned long long vm_stats_swapped_objects;
    unsigned long long vm_stats_swapouts;
    unsigned long long vm_stats_swapins;
    /* Pubsub */
    void *pubsub_channels; /* Map channels to list of subscribed clients */
    void *pubsub_patterns; /* A list of pubsub_patterns */
    /* Misc */
    unsigned lruclock:22;        /* clock incrementing every minute, for LRU */
    unsigned lruclock_padding:10;

    /* Scripting */
    void *lua; /* The Lua interpreter. We use just one for all clients */
    void *lua_client; /* The "fake client" to query Redis from Lua */
    void *lua_caller; /* The client running EVAL right now, or NULL */
    void *lua_scripts; /* A dictionary of SHA1 -> Lua scripts */
    long long lua_time_limit;
    long long lua_time_start;
    int lua_write_dirty;  /* True if a write command was called during the
                             execution of the current script. */
    int lua_random_dirty; /* True if a random command was called during the
                             execution of the current script. */
    int lua_timedout;     /* True if we reached the time limit for script
                             execution. */
    int lua_kill;         /* Kill the script if true. */

    /* Assert & bug reportign */
    char *assert_failed;
    char *assert_file;
    int assert_line;
    int bug_report_start; /* True if bug report header already logged. */

	long max_open_files;
	char *user;

	long long refuse_conn_loops;	/* # of serverCron loops to refuse connection */
	int block_conn;		/* whether to block connection */

	long long id;	/* id of this instance */
	long long slave_max_memory;		/* maximum memory for a slave when it's disconnected */
	long long slave_max_seconds;	/* maximum seconds to accumulate changes for slaves */

	int sync_old_redis;	/* set to 1 when user request to sync from old redis */
	int affinity;	/* cpu affinity */

	char *libredis;
	void *redis_handle;
	redis_main redismain;
	char *newlib;

    int syncio_timeout_ms;  /* syncio timeout for master in milliseconds */

    long long digest;  /* digest for server data */
    time_t lasterr; /* last time when digest does not synced with master */

    int readonly;

    long pending_aof_buffer_length; /* pending aofbuf to be written to disk */

    /* reserved fields for later use */
    long reserved_long[32];
    void *reserved_ptr[32];
} GLOBAL;
