#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "longset.h"
#include "zmalloc.h"

/* Note that these encodings are ordered, so:
 * INTSET_ENC_INT16 < INTSET_ENC_INT32 < INTSET_ENC_INT64. */
#define LONGSET_ENC_INT64 (sizeof(int64_t))


/* Create an empty longset. */
longset *longsetNew(uint32_t len) {
    longset *is = zmalloc(sizeof(longset)+LONGSET_ENC_INT64*len);
    is->length = 0;
    is->bucketCount = len;
    memset(is->contents , 0 , LONGSET_ENC_INT64*len);
    return is;
}


/* Return intset blob size in bytes. */
size_t longsetBlobLen(longset *is) {
    return sizeof(longset)+is->bucketCount*LONGSET_ENC_INT64;
}

