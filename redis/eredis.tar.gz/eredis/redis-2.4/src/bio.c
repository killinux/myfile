/* Background I/O service for Redis.
 *
 * This file implements operations that we need to perform in the background.
 * Currently there is only a single operation, that is a background close(2)
 * system call. This is needed as when the process is the last owner of a
 * reference to a file closing it means unlinking it, and the deletion of the
 * file is slow, blocking the server->
 *
 * In the future we'll either continue implementing new things we need or
 * we'll switch to libeio. However there are probably long term uses for this
 * file as we may want to put here Redis specific background tasks (for instance
 * it is not impossible that we'll need a non blocking FLUSHDB/FLUSHALL
 * implementation).
 *
 * DESIGN
 * ------
 *
 * The design is trivial, we have a structure representing a job to perform
 * and a different thread and job queue for every job type.
 * Every thread wait for new jobs in its queue, and process every job
 * sequentially.
 *
 * Jobs of the same type are guaranteed to be processed from the least
 * recently inserted to the most recently inserted (older jobs processed
 * first).
 *
 * Currently there is no way for the creator of the job to be notified about
 * the completion of the operation, this will only be added when/if needed.
 */

#include "redis.h"
#include "bio.h"
#include <fcntl.h>

static pthread_mutex_t bio_mutex[REDIS_BIO_NUM_OPS];
static pthread_cond_t bio_condvar[REDIS_BIO_NUM_OPS];
static list *bio_jobs[REDIS_BIO_NUM_OPS];
/* The following array is used to hold the number of pending jobs for every
 * OP type. This allows us to export the bioPendingJobsOfType() API that is
 * useful when the main thread wants to perform some operation that may involve
 * objects shared with the background thread. The main thread will just wait
 * that there are no longer jobs of this type to be executed before performing
 * the sensible operation. This data is also useful for reporting. */
static unsigned long long bio_pending[REDIS_BIO_NUM_OPS];

pthread_t tids[REDIS_BIO_NUM_OPS];
int quit = 0;

/* This structure represents a background Job. It is only used locally to this
 * file as the API deos not expose the internals at all. */
struct bio_job {
    time_t time; /* Time at which the job was created. */
    /* Job specific arguments pointers. If we need to pass more than three
     * arguments we can just pass a pointer to a structure or alike. */
    void *arg1, *arg2, *arg3;
};

void *bioProcessBackgroundJobs(void *arg);

/* Make sure we have enough stack to perform all the things we do in the
 * main thread. */
#define REDIS_THREAD_STACK_SIZE (1024*1024*4)

/* Initialize the background system, spawning the thread. */
void bioInit(void) {
    pthread_attr_t attr;
    pthread_t thread;
    size_t stacksize;
    int j;

    quit = 0;
    /* Initialization of state vars and objects */
    for (j = 0; j < REDIS_BIO_NUM_OPS; j++) {
        pthread_mutex_init(&bio_mutex[j],NULL);
        pthread_cond_init(&bio_condvar[j],NULL);
        bio_jobs[j] = listCreate();
        bio_pending[j] = 0;
    }

    /* Set the stack size as by default it may be small in some system */
    pthread_attr_init(&attr);
    pthread_attr_getstacksize(&attr,&stacksize);
    if (!stacksize) stacksize = 1; /* The world is full of Solaris Fixes */
    while (stacksize < REDIS_THREAD_STACK_SIZE) stacksize *= 2;
    pthread_attr_setstacksize(&attr, stacksize);

    /* Ready to spawn our threads. We use the single argument the thread
     * function accepts in order to pass the job ID the thread is
     * responsible of. */
    for (j = 0; j < REDIS_BIO_NUM_OPS; j++) {
        void *arg = (void*)(unsigned long) j;
        if (pthread_create(&thread,&attr,bioProcessBackgroundJobs,arg) != 0) {
            redisLog(REDIS_WARNING,"Fatal: Can't initialize Background Jobs.");
            exit(1);
        }
        tids[j] = thread;
    }
}

void bioCreateBackgroundJob(int type, void *arg1, void *arg2, void *arg3) {
    struct bio_job *job = zmalloc(sizeof(*job));

    job->time = time(NULL);
    job->arg1 = arg1;
    job->arg2 = arg2;
    job->arg3 = arg3;
    pthread_mutex_lock(&bio_mutex[type]);
    listAddNodeTail(bio_jobs[type],job);
    bio_pending[type]++;
    if (type == REDIS_BIO_AOF_WRITE)
        server->pending_aof_buffer_length += (long)arg3;
    pthread_cond_signal(&bio_condvar[type]);
    pthread_mutex_unlock(&bio_mutex[type]);
}

void bioQuit(int type) {
    pthread_mutex_lock(&bio_mutex[type]);
    quit = 999;
    pthread_cond_signal(&bio_condvar[type]);
    pthread_mutex_unlock(&bio_mutex[type]);
}

void *bioProcessBackgroundJobs(void *arg) {
    struct bio_job *job;
    unsigned long type = (unsigned long) arg;
    int oldfd, newfd;
    int nwritten = 0;
    char tmpfile[256];

    pthread_mutex_lock(&bio_mutex[type]);
    while(1) {
        listNode *ln;

        /* The loop always starts with the lock hold. */
        if (listLength(bio_jobs[type]) == 0) {
            if (quit) {
                redisLog(REDIS_NOTICE, "Thread %ld exit", pthread_self());
                pthread_mutex_unlock(&bio_mutex[type]);
                listRelease(bio_jobs[type]);
                return NULL;
            }
            pthread_cond_wait(&bio_condvar[type],&bio_mutex[type]);
            continue;
        }
        /* Pop the job from the queue. */
        ln = listFirst(bio_jobs[type]);
        job = ln->value;
        if (type == REDIS_BIO_AOF_WRITE)
            server->pending_aof_buffer_length -= (long)job->arg3;
        /* It is now possible to unlock the background system as we know have
         * a stand alone job structure to process.*/
        pthread_mutex_unlock(&bio_mutex[type]);

        /* Process the job accordingly to its type. */
        if (type == REDIS_BIO_CLOSE_FILE) {
            close((long)job->arg1);
        } else if (type == REDIS_BIO_AOF_FSYNC) {
            if (bioPendingJobsOfType(REDIS_BIO_AOF_WRITE) < 3) {
                aof_fsync((long)job->arg1);
                server->lastfsync = server->unixtime;
                /* clear page cache */
                posix_fadvise64((long)job->arg1, 0, 0, POSIX_FADV_DONTNEED);
            }
        } else if (type == REDIS_BIO_AOF_WRITE) {
            long len = (long)job->arg3;
            if (len == 1) {
                sdsfree(job->arg2);
                zfree(job);
                pthread_mutex_lock(&bio_mutex[type]);
                listDelNode(bio_jobs[type],ln);
                bio_pending[type]--;
                pthread_mutex_unlock(&bio_mutex[type]);

                /* wait for the bgrewritebuf */
                while (bioPendingJobsOfType(REDIS_BIO_AOF_WRITE) <= 0)
                    usleep(10);

                /* get the bgrewritebuf */
                pthread_mutex_lock(&bio_mutex[type]);
                ln = listFirst(bio_jobs[type]);
                job = ln->value;
                server->pending_aof_buffer_length -= (long)job->arg3;
                pthread_mutex_unlock(&bio_mutex[type]);

                redisAssert((long)job->arg1 == -1);
                snprintf(tmpfile,256,"temp-rewriteaof-bg-%d.aof",
                        (int)server->bgrewritechildpid);
                newfd = open(tmpfile,O_WRONLY|O_APPEND);
                if (newfd == -1) {
                    redisLog(REDIS_WARNING,
                            "Unable to open the temporary AOF "
                            "produced by the child: %s", strerror(errno));
                    goto cleanup;
                }

                if ((long)job->arg3 > 0) {
                    nwritten = write(newfd, (char *)job->arg2, (long)job->arg3);
                    if (nwritten != (long)job->arg3) {
                        if (nwritten == -1) {
                            redisLog(REDIS_WARNING,
                                    "Error trying to flush the parent diff "
                                    "to the rewritten AOF: %s", strerror(errno));
                        } else {
                            redisLog(REDIS_WARNING,
                                    "Short write trying to flush the parent diff "
                                    "to the rewritten AOF: %s", strerror(errno));
                        }
                        close(newfd);
                        goto cleanup;
                    }
                }
                redisLog(REDIS_NOTICE,
                        "Parent diff successfully flushed to the "
                        "rewritten AOF (%lu bytes)", nwritten);
                if (server->appendfd == -1) {
                    oldfd = open(server->appendfilename,O_RDONLY|O_NONBLOCK);
                } else {
                    oldfd = -1; /* We'll set this to the current AOF filedes later. */
                }

                /* Rename the temporary file. This will not unlink the target file if
                 * it exists, because we reference it with "oldfd". */
                if (rename(tmpfile,server->appendfilename) == -1) {
                    redisLog(REDIS_WARNING,
                            "Error trying to rename the temporary AOF: %s",
                            strerror(errno));
                    close(newfd);
                    if (oldfd != -1)
                        close(oldfd);
                    goto cleanup;
                }

                if (server->appendfd == -1) {
                    /* AOF disabled, we don't need to set the AOF file descriptor
                     * to this new file, so we can close it. */
                    close(newfd);
                } else {
                    /* AOF enabled, replace the old fd with the new one. */
                    oldfd = server->appendfd;
                    server->appendfd = newfd;
                    aofUpdateCurrentSize();
                    server->auto_aofrewrite_base_size = server->appendonly_current_size;
                }

                redisLog(REDIS_NOTICE, "Background AOF rewrite successful");
                /* Asynchronously close the overwritten AOF. */
                if (oldfd != -1)
                    bioCreateBackgroundJob(REDIS_BIO_CLOSE_FILE,
                        (void*)(long)oldfd,NULL,NULL);

cleanup:
                sdsfree(job->arg2);
                aofRemoveTempFile(server->bgrewritechildpid);
                server->bgrewritechildpid = -1;
            } else {
                nwritten = write(server->appendfd, (char *)job->arg2, (long)job->arg3);
                if (nwritten != (long)job->arg3) {
                    /* Ooops, we are in troubles. The best thing to do for now is
                     * aborting instead of giving the illusion that everything is
                     * working as expected. */
                    if (nwritten == -1) {
                        redisLog(REDIS_WARNING,"Exiting on error writing to the append-only file: %s",strerror(errno));
                    } else {
                        redisLog(REDIS_WARNING,"Exiting on short write while writing to the append-only file: %s",strerror(errno));
                    }
                    exit(1);
                }
                server->appendonly_current_size += nwritten;
                sdsfree(job->arg2);
            }
        } else {
            redisPanic("Wrong job type in bioProcessBackgroundJobs().");
        }
        zfree(job);

        /* Lock again before reiterating the loop, if there are no longer
         * jobs to process we'll block again in pthread_cond_wait(). */
        pthread_mutex_lock(&bio_mutex[type]);
        listDelNode(bio_jobs[type],ln);
        bio_pending[type]--;
    }
}

/* Return the number of pending jobs of the specified type. */
unsigned long long bioPendingJobsOfType(int type) {
    unsigned long long val;
    pthread_mutex_lock(&bio_mutex[type]);
    val = bio_pending[type];
    pthread_mutex_unlock(&bio_mutex[type]);
    return val;
}

/* Return the number of pending jobs of any type. */
unsigned long long bioPendingJobs() {
    unsigned long long val = 0;
    int j;

    for (j = 0; j < REDIS_BIO_NUM_OPS; ++j)
        val += bioPendingJobsOfType(j);
    return val;
}

#if 0 /* We don't use the following code for now, and bioWaitPendingJobsLE
         probably needs a rewrite using conditional variables instead of the
         current implementation. */


/* Wait until the number of pending jobs of the specified type are
 * less or equal to the specified number.
 *
 * This function may block for long time, it should only be used to perform
 * the following tasks:
 *
 * 1) To avoid that the main thread is pushing jobs of a given time so fast
 *    that the background thread can't process them at the same speed.
 *    So before creating a new job of a given type the main thread should
 *    call something like: bioWaitPendingJobsLE(job_type,10000);
 * 2) In order to perform special operations that make it necessary to be sure
 *    no one is touching shared resourced in the background.
 */
void bioWaitPendingJobsLE(int type, unsigned long long num) {
    unsigned long long iteration = 0;

    /* We poll the jobs queue aggressively to start, and gradually relax
     * the polling speed if it is going to take too much time. */
    while(1) {
        iteration++;
        if (iteration > 1000 && iteration <= 10000) {
            usleep(100);
        } else if (iteration > 10000) {
            usleep(1000);
        }
        if (bioPendingJobsOfType(type) <= num) break;
    }
}

/* Return the older job of the specified type. */
time_t bioOlderJobOfType(int type) {
    time_t time;
    listNode *ln;
    struct bio_job *job;

    pthread_mutex_lock(&bio_mutex[type]);
    ln = listFirst(bio_jobs[type]);
    if (ln == NULL) {
        pthread_mutex_unlock(&bio_mutex[type]);
        return 0;
    }
    job = ln->value;
    time = job->time;
    pthread_mutex_unlock(&bio_mutex[type]);
    return time;
}

#endif
